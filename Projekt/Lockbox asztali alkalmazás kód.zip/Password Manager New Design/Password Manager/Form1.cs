﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using PasswordManager;
using Password_Manager.UserControls;
using System.Data.SQLite;
using System.Linq;
using System.Diagnostics;

namespace Password_Manager
{
    public partial class Form1 : Form
    {
        LoginForm loginForm = new LoginForm();
        RegisterForm registerForm = new RegisterForm();
        UC_Backup backupControl = new UC_Backup();

        public static Form1 instance;

        private string dbPath = "Data Source=pwdmanager.db";

        private bool isExiting = false;

        private NotifyIcon trayIcon;
        public Form1()
        {
            InitializeComponent();
            InitializeTrayIcon();
            instance = this;
            this.Visible = false;
            this.Opacity = 0;
            //Task.Run(() => LoadData());
            this.Shown += (sender, e) => FadeIn();

            this.Icon = new Icon("../../Resources/favicon2.ico");

            GlobalEvents.ProfilePictureUpdated += MainForm_ProfilePictureUpdated;
            GlobalEvents.UsernameUpdated += GlobalEvents_UsernameUpdated;
            GlobalEvents.BackupSuccessful += GlobalEvents_BackupSuccessful;
            GlobalEvents.BackupFailed += GlobalEvents_BackupFailed;
        }
        private void LoadData()
        {
            this.Invoke((MethodInvoker)(() =>
            {
                pnlNav.Height = btnDashboard.Height;
                pnlNav.Top = btnDashboard.Top;
                pnlNav.Left = btnDashboard.Left;
                btnDashboard.BackColor = Color.FromArgb(46, 51, 73);

                LoadUsername();
                GetProfilePictureFromDatabase(LoginForm.currentUserId);

                backupControl.CheckBackupOnStartup();

                this.Visible = true;
            }));
        }

    private void FadeIn()
        {
            Timer fadeTimer = new Timer();
            fadeTimer.Interval = 10; 
            fadeTimer.Tick += (sender, e) =>
            {
                if (this.Opacity < 1)
                {
                    this.Opacity += 0.1; 
                }
                else
                {
                    fadeTimer.Stop();
                }
            };
            fadeTimer.Start();
        }


        public void InitializeTrayIcon()
        {
            string iconPath = "../../Resources/favicon2.ico";

            if (File.Exists(iconPath))
            {
                if (trayIcon == null)
                {
                    trayIcon = new NotifyIcon
                    {
                        Icon = new Icon(iconPath),
                        Text = "LockBox",
                        Visible = true
                    };

                    // Opciók a jobb kattintásos menüben
                    var trayMenu = new ContextMenuStrip();
                    trayMenu.Items.Add("Megnyitás", null, OnOpenClicked);
                    trayMenu.Items.Add("Bezárás", null, OnExitClicked);

                    trayIcon.ContextMenuStrip = trayMenu;
                    trayIcon.DoubleClick += (s, e) => OnOpenClicked(s, e);

                }
            }
            else
            {
                MessageBox.Show("Nem található az ikon fájl: " + iconPath, "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadData();
            UC_Main uc = new UC_Main();
            AddUserControl(uc);
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btnDashboard.Height;
            pnlNav.Top = btnDashboard.Top;
            pnlNav.Left = btnDashboard.Left;
            btnDashboard.BackColor = Color.FromArgb(40,40,40);
            UC_Main uc = new UC_Main();
            AddUserControl(uc);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btnAccount.Height;
            pnlNav.Top = btnAccount.Top;
            btnAccount.BackColor = Color.FromArgb(40,40,40);
            UC_Profile uc = new UC_Profile();
            AddUserControl(uc);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btnContact.Height;
            pnlNav.Top = btnContact.Top;
            btnContact.BackColor = Color.FromArgb(40, 40, 40);

            Process.Start(new ProcessStartInfo
            {
                FileName = "https://www.lockbox.hu/contact.php",
                UseShellExecute = true // Ez kell ahhoz, hogy a modern böngészők megnyíljanak
            });
        }

        private void btnBackup_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btnBackup.Height;
            pnlNav.Top = btnBackup.Top;
            btnBackup.BackColor = Color.FromArgb(40, 40, 40);
            UC_Backup uc = new UC_Backup();
            AddUserControl(uc);
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            pnlNav.Height = btnSettings.Height;
            pnlNav.Top = btnSettings.Top;
            btnSettings.BackColor = Color.FromArgb(40, 40, 40);

            UC_Settings uc = new UC_Settings();
            AddUserControl(uc);
        }

        private void btnDashboard_Leave(object sender, EventArgs e)
        {
            btnDashboard.BackColor = Color.FromArgb(11,7,17);
        }

        private void button1_Leave(object sender, EventArgs e)
        {
            btnAccount.BackColor = Color.FromArgb(11, 7, 17);
        }

        private void button2_Leave(object sender, EventArgs e)
        {
            btnContact.BackColor = Color.FromArgb(11, 7, 17);
        }

        private void btnBackup_Leave(object sender, EventArgs e)
        {
            btnBackup.BackColor = Color.FromArgb(11, 7, 17);
        }

        private void btnSettings_Leave(object sender, EventArgs e)
        {
            btnSettings.BackColor = Color.FromArgb(11, 7, 17);
        }
        private void btnLogout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
            "Biztosan ki szeretnél jelentkezni?", // Az üzenet szövege
            "Kijelentkezés megerősítése",        // Az ablak címe
            MessageBoxButtons.YesNo,            // Gombok (Yes és No)
            MessageBoxIcon.Question             // Ikon típusa
            );

            if (result == DialogResult.Yes)
            {
                UserSettings settings = SettingsManager.LoadSettings();
                if (loginForm == null)
                {
                    Application.Run(new LoginForm());
                }
                else
                {
                    loginForm.Show();
                }
                loginForm.isAutoLogin = false;
                settings.AutoLoginEnabled = false;
                SettingsManager.SaveSettings(settings);
                this.Hide();
            }
            else
            {

            }
        }
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (isExiting)
            {
                return;
            }
            else
            {
                UserSettings settings = SettingsManager.LoadSettings();
                if (settings.MinimizeToTrayOnClose)
                {
                    e.Cancel = true;
                    this.Hide();   
                    this.ShowInTaskbar = false;
                    trayIcon.Visible = true;
                }
                else
                {
                    if(trayIcon != null)
                    {
                        trayIcon.Visible = false;
                        trayIcon.Dispose();
                        trayIcon = null;
                    }
                    instance = null;
                    Application.Exit();
                }
            } 
        }
        private void OnOpenClicked(object sender, EventArgs e)
        {
            Show();
            WindowState = FormWindowState.Normal;
            this.ShowInTaskbar = true;
        }

        private void OnExitClicked(object sender, EventArgs e)
        {
            isExiting = true;
            trayIcon.Visible = false;
            trayIcon.Dispose();
            Application.Exit();
        }

        private void AddUserControl(UserControl userControl)
        {
            userControl.Dock = DockStyle.Fill;
            pnlMain.Controls.Clear();
            pnlMain.Controls.Add(userControl);
            userControl.BringToFront();
        }

        public  void LoadUsername()
        {
            if (LoginForm.currentUserId != -1)
            {
                string username = GetUsernameFromDatabase(LoginForm.currentUserId);

                if (!string.IsNullOrEmpty(username))
                {
                    lblUsername.Text = username;
                }
                else
                {
                    lblUsername.Text = "Error";
                }
            }
            else
            {
                UserSettings settings = SettingsManager.LoadSettings();
                lblUsername.Text = settings.Username;
                lblUsername.TextAlign = ContentAlignment.MiddleCenter;
            }
        }

        private string GetUsernameFromDatabase(int userId)
        {
            string username = null;

            try
            {
                using (var connection = new SQLiteConnection(dbPath))
                {
                    connection.Open();
                    string query = "SELECT username FROM user WHERE id = @userId";
                    using (var command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        var result = command.ExecuteScalar();

                        if (result != null)
                        {
                            username = result.ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a felhasználónév lekérésekor: " + ex.Message);
            }

            return username;
        }

        public void GetProfilePictureFromDatabase(int userId)
        {
            try
            {
                using (var connection = new SQLiteConnection(dbPath))
                {
                    connection.Open();
                    string query = "SELECT profile_picture FROM user WHERE id = @userId";
                    using (var command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        var result = command.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            byte[] profilePictureBytes = (byte[])result;
                            using (MemoryStream ms = new MemoryStream(profilePictureBytes))
                            {
                                roundPictureBox1.Image = Image.FromStream(ms);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Nincs beállítva profilkép.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a profilkép betöltésekor: " + ex.Message);
            }
        }

        private void MainForm_ProfilePictureUpdated(object sender, EventArgs e)
        {
            GetProfilePictureFromDatabase(LoginForm.currentUserId);
        }
        private void GlobalEvents_UsernameUpdated(object sender, EventArgs e)
        {
            LoadUsername();
        }
        private void GlobalEvents_BackupSuccessful(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();
            if (settings.BackupNotificationsEnabled)
            {
                notifyIcon1.Icon = SystemIcons.Information;
                notifyIcon1.BalloonTipTitle = "Biztonsági mentés";
                notifyIcon1.BalloonTipText = "A biztonsági mentés sikeresen megtörtént.";
                notifyIcon1.ShowBalloonTip(3000);
            } 
        }
        private void GlobalEvents_BackupFailed(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();
            if (settings.BackupNotificationsEnabled)
            {
                notifyIcon1.Icon = SystemIcons.Information;
                notifyIcon1.BalloonTipTitle = "Biztonsági mentés";
                notifyIcon1.BalloonTipText = "Hiba történt a biztonsági mentés során!";
                notifyIcon1.ShowBalloonTip(3000);
            }
        }
    }
}
