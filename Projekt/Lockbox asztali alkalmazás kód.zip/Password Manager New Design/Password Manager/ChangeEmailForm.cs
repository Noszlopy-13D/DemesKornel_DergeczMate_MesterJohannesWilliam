﻿using PasswordManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Password_Manager
{
    public partial class ChangeEmailForm : Form
    {
        private string dbPath = "Data Source=pwdmanager.db";

        public event EventHandler EmailUpdated;

        private bool dragging = false;
        private int dragCursorX;
        private int dragCursorY;
        private int dragFormX;
        private int dragFormY;
        public ChangeEmailForm()
        {
            InitializeComponent();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            string email1 = txtEmail1.Texts;
            string email2 = txtEmail2.Texts;
            if (string.IsNullOrWhiteSpace(email1) || string.IsNullOrWhiteSpace(email2))
            {
                MessageBox.Show("Kérlek, töltsd ki az összes mezőt.");
                return;
            }
            if (!IsValidEmail(email1))
            {
                MessageBox.Show("Kérlek, adj meg egy érvényes e-mail címet!");
                return;
            }
            if (!IsValidEmail(email2))
            {
                MessageBox.Show("Kérlek, adj meg egy érvényes e-mail címet!");
                return;
            }

            if (email1 == email2)
            {
                txtEmail1.BackColor = System.Drawing.Color.LightGreen;
                txtEmail2.BackColor = System.Drawing.Color.LightGreen;

                try
                {
                    lblMessage.Visible = false;
                    int currentUserId = LoginForm.currentUserId;

                    string verificationCode = GenerateVerificationCode();
                    string email = GetUserEmail(currentUserId);
                    SendVerificationEmail(email, verificationCode);


                    EmailChangeVerificationForm verificationForm = new EmailChangeVerificationForm(email, verificationCode, email1);
                    if (verificationForm.ShowDialog() == DialogResult.OK)
                    {
                        this.Close();
                    }
                    
                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Hiba történt: " + ex.Message;
                }
            }
            else
            {
                txtEmail1.BackColor = System.Drawing.Color.LightCoral;
                txtEmail2.BackColor = System.Drawing.Color.LightCoral;
                lblMessage.Visible = true;
            }
        }

        

        public async void SendVerificationEmail(string email, string code)
        {
            try
            {
                EmailService emailService = new EmailService();
                await emailService.SendEmail(email, "Hitelesítő Kód", code);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba az email küldésekor: {ex.Message}");
            }
        }
        public string GenerateVerificationCode()
        {
            Random random = new Random();
            return random.Next(100000, 999999).ToString();
        }
        public string GetUserEmail(int userId)
        {
            using (var connection = new SQLiteConnection(dbPath))
            {
                connection.Open();
                string query = "SELECT email FROM user WHERE id = @id";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", userId);
                    var result = command.ExecuteScalar();
                    return result?.ToString();
                }
            }
        }
        public bool IsValidEmail(string email)
        {
            try
            {
                MailAddress mail = new MailAddress(email);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }
        private void panelTitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            dragCursorX = Cursor.Position.X;
            dragCursorY = Cursor.Position.Y;
            dragFormX = this.Left;
            dragFormY = this.Top;
        }

        private void panelTitleBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                this.Left = dragFormX + (Cursor.Position.X - dragCursorX);
                this.Top = dragFormY + (Cursor.Position.Y - dragCursorY);
            }
        }

        private void panelTitleBar_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }
    }
}
