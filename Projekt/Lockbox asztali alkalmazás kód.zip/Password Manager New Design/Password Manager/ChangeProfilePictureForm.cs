﻿using Password_Manager.UserControls;
using PasswordManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Manager
{
    public partial class ChangeProfilePictureForm : Form
    {
        private string dbPath = "Data Source=pwdmanager.db";

        public event EventHandler ProfilePictureChanged;

        private int userId = LoginForm.currentUserId;

        Form1 form1 = new Form1();

        private bool dragging = false;
        private int dragCursorX;
        private int dragCursorY;
        private int dragFormX;
        private int dragFormY;
        public ChangeProfilePictureForm()
        {
            InitializeComponent();
            LoadCurrentProfilePicture(LoginForm.currentUserId);
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            try
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp";
                    openFileDialog.Title = "Válasszon profilképet";

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string selectedImagePath = openFileDialog.FileName;

                        FileInfo fileInfo = new FileInfo(selectedImagePath);
                        if (fileInfo.Length > 5 * 1024 * 1024) 
                        {
                            MessageBox.Show("A fájl mérete túl nagy. Kérlek, válassz kisebb fájlt.");
                            return;
                        }
                        if (File.Exists(selectedImagePath))
                        {
                            Image selectedImage = Image.FromFile(selectedImagePath);

                            Image resizedImage = ResizeImage(selectedImage, 100, 100);

                            roundPictureBox1.Image = resizedImage;
                        }
                        else
                        {
                            MessageBox.Show("A fájl nem található.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a profilkép frissítésekor: " + ex.Message);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (roundPictureBox1.Image != null)
                {
                    // Átalakítjuk a képet byte[] formátumba
                    byte[] profilePictureBytes;
                    using (MemoryStream ms = new MemoryStream())
                    {
                        // Használjunk egy konkrét formátumot, pl. JPEG
                        roundPictureBox1.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                        profilePictureBytes = ms.ToArray();
                    }

                    using (var connection = new SQLiteConnection(dbPath))
                    {
                        connection.Open();

                        string updateQuery = "UPDATE user SET profile_picture = @profilePicture WHERE id = @userId";
                        using (var command = new SQLiteCommand(updateQuery, connection))
                        {
                            command.Parameters.AddWithValue("@profilePicture", profilePictureBytes);
                            command.Parameters.AddWithValue("@userId", userId);

                            command.ExecuteNonQuery();
                        }
                    }
                    GlobalEvents.OnProfilePictureUpdated();


                    this.Close();
                }
                else
                {
                    MessageBox.Show("Nincs kiválasztva kép a mentéshez.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a profilkép mentésekor: " + ex.Message);
            }
        }

        private void ChangeProfilePictureForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            ProfilePictureChanged?.Invoke(this, EventArgs.Empty);
            form1.GetProfilePictureFromDatabase(LoginForm.currentUserId);
        }

        private void LoadCurrentProfilePicture(int userId)
        {
            try
            {
                using (var connection = new SQLiteConnection(dbPath))
                {
                    connection.Open();
                    string query = "SELECT profile_picture FROM user WHERE id = @userId";
                    using (var command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        var result = command.ExecuteScalar();

                        if (result != null && result != DBNull.Value)
                        {
                            byte[] profilePictureBytes = (byte[])result;
                            using (MemoryStream ms = new MemoryStream(profilePictureBytes))
                            {
                                roundPictureBox1.Image = Image.FromStream(ms);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Nincs beállítva profilkép.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a profilkép betöltésekor: " + ex.Message);
            }
        }

        public Image ResizeImage(Image image, int maxWidth, int maxHeight)
        {
            int originalWidth = image.Width;
            int originalHeight = image.Height;

            float ratioX = (float)maxWidth / (float)originalWidth;
            float ratioY = (float)maxHeight / (float)originalHeight;
            float ratio = Math.Min(ratioX, ratioY);

            int newWidth = (int)(originalWidth * ratio);
            int newHeight = (int)(originalHeight * ratio);

            Bitmap newImage = new Bitmap(newWidth, newHeight);

            using (Graphics graphics = Graphics.FromImage(newImage))
            {
                graphics.DrawImage(image, 0, 0, newWidth, newHeight);
            }

            return newImage;
        }

        private void panelTitleBar_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            dragCursorX = Cursor.Position.X;
            dragCursorY = Cursor.Position.Y;
            dragFormX = this.Left;
            dragFormY = this.Top;
        }

        private void panelTitleBar_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                this.Left = dragFormX + (Cursor.Position.X - dragCursorX);
                this.Top = dragFormY + (Cursor.Position.Y - dragCursorY);
            }
        }

        private void panelTitleBar_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }
    }
}
