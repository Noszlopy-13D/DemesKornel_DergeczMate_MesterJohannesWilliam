﻿using PasswordManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Password_Manager
{
    public partial class VerificationForm : Form
    {
        LoginForm loginForm = new LoginForm();
        private string expectedCode;
        private string _email;
        public VerificationForm(string email, string code)
        {
            InitializeComponent();
            expectedCode = code;  
            _email = email;
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            string inputCode = txtVerificationCode.Text;
            if (inputCode == expectedCode)
            {
                MessageBox.Show("Sikeres hitelesítés!");
                this.DialogResult = DialogResult.OK; 
                this.Close();
            }
            else
            {
                MessageBox.Show("Érvénytelen kód. Kérlek, próbáld újra.");
            }
        }

        private void btnResendCode_Click(object sender, EventArgs e)
        {
            string verificationCode = loginForm.GenerateVerificationCode();
            loginForm.SendVerificationEmail(_email, verificationCode);
            expectedCode = verificationCode;
        }
    }
}
