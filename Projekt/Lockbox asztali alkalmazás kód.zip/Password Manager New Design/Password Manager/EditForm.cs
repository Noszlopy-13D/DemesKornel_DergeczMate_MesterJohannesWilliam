﻿using Password_Manager.UserControls;
using PasswordManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Password_Manager
{
    public partial class EditForm : Form
    {
        private string dbPath = "Data Source=pwdmanager.db";

        private int currentUserId;

        public event Action RecordUpdated;

        public EditForm(int recordId, string appName, string username, string password, Image applicationLogo, string identifier)
        {
            InitializeComponent();
            txtId.Text = recordId.ToString();
            txtApplication.Texts = appName;
            txtUsername.Texts = username;
            txtPassword.Texts = password;

            currentUserId = LoginForm.currentUserId;

            List<ComboBoxItem> items = new List<ComboBoxItem>
            {
                new ComboBoxItem(Image.FromFile("../../Images/imageOther.png"), "Egyéb", "imageOther"),
                new ComboBoxItem(Image.FromFile("../../Images/imageGoogle.png"), "Google", "imageGoogle"),
                new ComboBoxItem(Image.FromFile("../../Images/imageSteam.png"), "Steam", "imageSteam"),
                new ComboBoxItem(Image.FromFile("../../Images/imageFacebook.png"), "Facebook", "imageFacebook"),
                new ComboBoxItem(Image.FromFile("../../Images/imageInstagram.png"), "Instagram", "imageInstagram"),
                new ComboBoxItem(Image.FromFile("../../Images/imageSnapchat.png"), "Snapchat", "imageSnapchat"),
                new ComboBoxItem(Image.FromFile("../../Images/imageTwitch.png"), "Twitch", "imageTwitch"),
                new ComboBoxItem(Image.FromFile("../../Images/imageAmazon.png"), "Amazon", "imageAmazon"),
                new ComboBoxItem(Image.FromFile("../../Images/imageApple.png"), "Apple", "imageApple"),
                new ComboBoxItem(Image.FromFile("../../Images/imageDiscord.png"), "Discord", "imageDiscord"),
                new ComboBoxItem(Image.FromFile("../../Images/imageDropbox.png"), "Dropbox", "imageDropbox"),
                new ComboBoxItem(Image.FromFile("../../Images/imageEa.png"), "EA", "imageEa"),
                new ComboBoxItem(Image.FromFile("../../Images/imageExplorer.png"), "Explorer", "imageExplorer"),
                new ComboBoxItem(Image.FromFile("../../Images/imageGithub.png"), "Github", "imageGithub"),
                new ComboBoxItem(Image.FromFile("../../Images/imageMessenger.png"), "Messenger", "imageMessenger"),
                new ComboBoxItem(Image.FromFile("../../Images/imageMicrosoft.png"), "Microsoft", "imageMicrosoft"),
                new ComboBoxItem(Image.FromFile("../../Images/imagePaypal.png"), "Paypal", "imagePaypal"),
                new ComboBoxItem(Image.FromFile("../../Images/imagePinterest.png"), "Pinterest", "imagePinterest"),
                new ComboBoxItem(Image.FromFile("../../Images/imagePlaystation.png"), "Playstation", "imagePlaystation"),
                new ComboBoxItem(Image.FromFile("../../Images/imageReddit.png"), "Reddit", "imageReddit"),
                new ComboBoxItem(Image.FromFile("../../Images/imageSoundcloud.png"), "Soundcloud", "imageSoundcloud"),
                new ComboBoxItem(Image.FromFile("../../Images/imageSpotify.png"), "Spotify", "imageSpotify"),
                new ComboBoxItem(Image.FromFile("../../Images/imageThreads.png"), "Threads", "imageThreads"),
                new ComboBoxItem(Image.FromFile("../../Images/imageUtorrent.png"), "uTorrent", "imageUtorrent"),
                new ComboBoxItem(Image.FromFile("../../Images/imageVk.png"), "VK", "imageVk"),
                new ComboBoxItem(Image.FromFile("../../Images/imageWhatsapp.png"), "WhatsApp", "imageWhatsapp"),
                new ComboBoxItem(Image.FromFile("../../Images/imageXbox.png"), "Xbox", "imageXbox"),
            };

            ComboBoxItem otherItem = items.First(item => item.Text == "Egyéb");
            items.Remove(otherItem);

            items = items.OrderBy(item => item.Text).ToList();

            items.Add(otherItem);

            comboBoxImages.Items.Clear();
            foreach (var item in items)
            {
                comboBoxImages.Items.Add(item);
            }

            comboBoxImages.DrawMode = DrawMode.OwnerDrawFixed;
            comboBoxImages.DrawItem += ComboBoxImages_DrawItem;

            SelectComboBoxItemByIdentifier(identifier);
        }

        private void SaveChanges()
        {
            // Az új adatok megszerzése
            string application = txtApplication.Texts;
            string username = txtUsername.Texts;
            string password = txtPassword.Texts;
            int id = Convert.ToInt32(txtId.Text);
            var selectedItem = comboBoxImages.SelectedItem as ComboBoxItem;

            if (selectedItem == null || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Töltsd ki az összes mezőt és válassz egy alkalmazást!");
                return;
            }

            string encryptedPassword = EncryptionHelper.Encrypt(password);
            UpdateRecordInDatabase(currentUserId, id, application, username, encryptedPassword, selectedItem.Image);

            RecordUpdated?.Invoke();

            this.Close();
        }

        private void UpdateRecordInDatabase(int userId, int recordId, string applicationName, string username, string encryptedPassword, Image applicationLogo)
        {
            using (var connection = new SQLiteConnection(dbPath))
            {
                connection.Open();
                string sql = @"
                    UPDATE saved_passwords 
                    SET app_name = @appName, username = @username, password = @password, logo = @logo
                    WHERE user_id = @userId AND id = @recordId";

                    using (var command = new SQLiteCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@userId", userId);
                        command.Parameters.AddWithValue("@recordId", recordId);
                        command.Parameters.AddWithValue("@appName", applicationName);
                        command.Parameters.AddWithValue("@username", username);
                        command.Parameters.AddWithValue("@password", encryptedPassword);

                    using (var ms = new MemoryStream())
                    {
                        applicationLogo.Save(ms, applicationLogo.RawFormat);
                        byte[] logoBytes = ms.ToArray();
                        command.Parameters.AddWithValue("@logo", logoBytes);
                    }
                    command.ExecuteNonQuery();
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveChanges();
        }

        private void ComboBoxImages_DrawItem(object sender, DrawItemEventArgs e)
        {
            e.DrawBackground();

            if (e.Index < 0) return;

            var item = (ComboBoxItem)comboBoxImages.Items[e.Index];

            using (Font font = new Font("Sans-Serif", 16))
            {
                e.Graphics.DrawImage(item.Image, e.Bounds.X, e.Bounds.Y, 100, 100);
                e.Graphics.DrawString(item.Text, font, Brushes.White, e.Bounds.X + 110, e.Bounds.Y + 40);
            }
            e.DrawFocusRectangle();
        }

        private void comboBoxImages_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedItem = comboBoxImages.SelectedItem as ComboBoxItem;

            bool isTextInComboBox = comboBoxImages.Items.Cast<ComboBoxItem>().Any(item => item.Text == txtApplication.Texts);
            if (string.IsNullOrWhiteSpace(txtApplication.Texts) || isTextInComboBox)
            {
                txtApplication.Texts = selectedItem.Text;

            }
        }

        private void comboBoxImages_DropDown(object sender, EventArgs e)
        {
            int dropdownHeight = comboBoxImages.Items.Count * comboBoxImages.ItemHeight;
            if (dropdownHeight > comboBoxImages.MaxDropDownItems * comboBoxImages.ItemHeight)
            {
                dropdownHeight = comboBoxImages.MaxDropDownItems * comboBoxImages.ItemHeight;
            }

            // Az új magasságot itt alkalmazzuk
            comboBoxImages.DropDownHeight = dropdownHeight;
        }

        private void SelectComboBoxItemByIdentifier(string identifier)
        {
            for (int i = 0; i < comboBoxImages.Items.Count; i++)
            {
                var item = comboBoxImages.Items[i] as ComboBoxItem;
                if (item != null && item.Identifier == identifier)
                {
                    comboBoxImages.SelectedIndex = i;
                    break;
                }
            }
        }
    }
}
