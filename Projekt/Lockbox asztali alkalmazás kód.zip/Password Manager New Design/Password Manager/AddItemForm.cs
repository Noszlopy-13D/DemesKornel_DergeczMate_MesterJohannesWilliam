﻿using System;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;
using PasswordManager;
using Password_Manager.UserControls;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Collections.Generic;


namespace Password_Manager
{
    public partial class AddItemForm : Form
    {
        private string dbPath = "Data Source=pwdmanager.db";
        private int currentUserId;

        private bool isPasswordVisible = false;

        UC_Main uc_main = new UC_Main();

        public event Action PasswordAdded;

        public AddItemForm()
        {   
            InitializeComponent();
            currentUserId = LoginForm.currentUserId;

            List<ComboBoxItem> items = new List<ComboBoxItem>
            {
                new ComboBoxItem(Image.FromFile("../../Images/imageOther.png"), "Egyéb", "imageOther"),
                new ComboBoxItem(Image.FromFile("../../Images/imageGoogle.png"), "Google", "imageGoogle"),
                new ComboBoxItem(Image.FromFile("../../Images/imageSteam.png"), "Steam", "imageSteam"),
                new ComboBoxItem(Image.FromFile("../../Images/imageFacebook.png"), "Facebook", "imageFacebook"),
                new ComboBoxItem(Image.FromFile("../../Images/imageInstagram.png"), "Instagram", "imageInstagram"),
                new ComboBoxItem(Image.FromFile("../../Images/imageSnapchat.png"), "Snapchat", "imageSnapchat"),
                new ComboBoxItem(Image.FromFile("../../Images/imageTwitch.png"), "Twitch", "imageTwitch"),
                new ComboBoxItem(Image.FromFile("../../Images/imageAmazon.png"), "Amazon", "imageAmazon"),
                new ComboBoxItem(Image.FromFile("../../Images/imageApple.png"), "Apple", "imageApple"),
                new ComboBoxItem(Image.FromFile("../../Images/imageDiscord.png"), "Discord", "imageDiscord"),
                new ComboBoxItem(Image.FromFile("../../Images/imageDropbox.png"), "Dropbox", "imageDropbox"),
                new ComboBoxItem(Image.FromFile("../../Images/imageEa.png"), "EA", "imageEa"),
                new ComboBoxItem(Image.FromFile("../../Images/imageExplorer.png"), "Explorer", "imageExplorer"),
                new ComboBoxItem(Image.FromFile("../../Images/imageGithub.png"), "Github", "imageGithub"),
                new ComboBoxItem(Image.FromFile("../../Images/imageMessenger.png"), "Messenger", "imageMessenger"),
                new ComboBoxItem(Image.FromFile("../../Images/imageMicrosoft.png"), "Microsoft", "imageMicrosoft"),
                new ComboBoxItem(Image.FromFile("../../Images/imagePaypal.png"), "Paypal", "imagePaypal"),
                new ComboBoxItem(Image.FromFile("../../Images/imagePinterest.png"), "Pinterest", "imagePinterest"),
                new ComboBoxItem(Image.FromFile("../../Images/imagePlaystation.png"), "Playstation", "imagePlaystation"),
                new ComboBoxItem(Image.FromFile("../../Images/imageReddit.png"), "Reddit", "imageReddit"),
                new ComboBoxItem(Image.FromFile("../../Images/imageSoundcloud.png"), "Soundcloud", "imageSoundcloud"),
                new ComboBoxItem(Image.FromFile("../../Images/imageSpotify.png"), "Spotify", "imageSpotify"),
                new ComboBoxItem(Image.FromFile("../../Images/imageThreads.png"), "Threads", "imageThreads"),
                new ComboBoxItem(Image.FromFile("../../Images/imageUtorrent.png"), "uTorrent", "imageUtorrent"),
                new ComboBoxItem(Image.FromFile("../../Images/imageVk.png"), "VK", "imageVk"),
                new ComboBoxItem(Image.FromFile("../../Images/imageWhatsapp.png"), "WhatsApp", "imageWhatsapp"),
                new ComboBoxItem(Image.FromFile("../../Images/imageXbox.png"), "Xbox", "imageXbox"),
            };

            ComboBoxItem otherItem = items.First(item => item.Text == "Egyéb");
            items.Remove(otherItem);

            items = items.OrderBy(item => item.Text).ToList();

            items.Add(otherItem);

            comboBoxImages.Items.Clear();
            foreach (var item in items)
            {
                comboBoxImages.Items.Add(item);
            }
        }
       
        private void ComboBoxImages_DrawItem(object sender, DrawItemEventArgs e)
        {
            e.DrawBackground();

            if (e.Index < 0) return;

            using (Font font = new Font("Sans-Sherif", 18))
            {
                var item = (ComboBoxItem)comboBoxImages.Items[e.Index];
                // Kép megjelenítése
                e.Graphics.DrawImage(item.Image, e.Bounds.X + 10, e.Bounds.Y + 10, 80, 80);
                // Szöveg megjelenítése
                e.Graphics.DrawString(item.Text, font, Brushes.White, e.Bounds.X + 110, e.Bounds.Y + 35);     
            }

            e.DrawFocusRectangle();
        }

        private void btnTogglePassword_Click(object sender, EventArgs e)
        {
            if (isPasswordVisible)
            {
                txtPassword.PasswordChar = true;
                btnTogglePassword.Text = "👁";
            }
            else
            {
                txtPassword.PasswordChar = false;
                btnTogglePassword.Text = "👁‍🗨";
            }

            isPasswordVisible = !isPasswordVisible;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // Szövegek lekérése a formról
                string application = txtApplication.Texts;
                string username = txtUsername.Texts;
                string password = txtPassword.Texts;
                var selectedItem = comboBoxImages.SelectedItem as ComboBoxItem;

                if (selectedItem == null || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                {
                    MessageBox.Show("Töltsd ki az összes mezőt és válassz egy alkalmazást!");
                    return;
                }

                //string applicationName = selectedItem.Text;
                Image applicationLogo = selectedItem.Image;
                string identifier = selectedItem.Identifier;

                // Jelszó titkosítása
                string encryptedPassword = EncryptionHelper.Encrypt(password);

                // Jelszó és egyéb adatok mentése adatbázisba
                SaveToDatabase(currentUserId, application, username, encryptedPassword, applicationLogo, identifier);
                MessageBox.Show("Adat mentése sikeres!");

                PasswordAdded?.Invoke();

                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt az adat mentésekor: " + ex.Message);
            }
        }

        private void SaveToDatabase(int userId, string applicationName, string username, string encryptedPassword, Image applicationLogo, string identifier)
        {
            using (var connection = new SQLiteConnection(dbPath))
            {
                connection.Open();

                // SQL parancs az új rekord beszúrásához
                string sql = @"
                    INSERT INTO saved_passwords (user_id, app_name, username, password, logo, createdAt, logo_identifier) 
                    VALUES (@userId, @appName, @username, @password, @logo, @createdAt, @logoIdentifier)";

                using (var command = new SQLiteCommand(sql, connection))
                {
                    // Paraméterek hozzáadása
                    command.Parameters.AddWithValue("@userId", userId);
                    command.Parameters.AddWithValue("@appName", applicationName);
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", encryptedPassword);

                    // Kép mentése byte tömbként
                    using (var ms = new MemoryStream())
                    {
                        applicationLogo.Save(ms, applicationLogo.RawFormat);
                        byte[] logoBytes = ms.ToArray();
                        command.Parameters.AddWithValue("@logo", logoBytes);
                    }

                    command.Parameters.AddWithValue("@createdAt", DateTime.Now);
                    command.Parameters.AddWithValue("@logoIdentifier", identifier);

                    // Adatok beszúrása
                    command.ExecuteNonQuery();
                }
            }
        }

        private void comboBoxImages_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxImages.SelectedIndex == -1)
            {
                comboBoxImages.BackColor = Color.FromArgb(44,44,44);
            }
            var selectedItem = comboBoxImages.SelectedItem as ComboBoxItem;

            bool isTextInComboBox = comboBoxImages.Items.Cast<ComboBoxItem>().Any(item => item.Text == txtApplication.Texts);
            if (string.IsNullOrWhiteSpace(txtApplication.Texts) || isTextInComboBox)
            {
                txtApplication.Texts = selectedItem.Text;
                
            }
        }

        private void btnPWDGenerate_Click(object sender, EventArgs e)
        {
            PasswordGeneratorForm passwordGenerator = new PasswordGeneratorForm();
            if (passwordGenerator.ShowDialog() == DialogResult.OK) 
            {
                txtPassword.Texts = passwordGenerator.GeneratedPassword;
            }
        }

        private void AddItemForm_Load(object sender, EventArgs e)
        {
            this.ActiveControl = null;
            txtApplication.Focus();
        }

        private void comboBoxImages_DropDown(object sender, EventArgs e)
        {

            int dropdownHeight = comboBoxImages.Items.Count * comboBoxImages.ItemHeight;
            if (dropdownHeight > comboBoxImages.MaxDropDownItems * comboBoxImages.ItemHeight)
            {
                dropdownHeight = comboBoxImages.MaxDropDownItems * comboBoxImages.ItemHeight;
            }

            // Az új magasságot itt alkalmazzuk
            comboBoxImages.DropDownHeight = dropdownHeight;
        }
    }
    public class ComboBoxItem
    {
        public Image Image { get; set; }
        public string Text { get; set; }
        public string Identifier { get; set; } 


        public ComboBoxItem(Image image, string text, string identifier)
        {
            Image = image;
            Text = text;
            Identifier = identifier;
        }

        public override string ToString()
        {
            return Text;  // A szöveg jelenik meg, amikor a ComboBox elem kiválasztásra kerül
        }
    }
}


  
