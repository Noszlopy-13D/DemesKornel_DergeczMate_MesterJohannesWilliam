﻿using Password_Manager.Properties;
using Password_Manager.UserControls;
using PasswordManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Password_Manager
{
    public partial class ChangeUsernameForm : Form
    {
        private string dbPath = "Data Source=pwdmanager.db";

        public event EventHandler UsernameUpdated;

        public ChangeUsernameForm()
        {
            InitializeComponent();     
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                int userId = LoginForm.currentUserId;

                using (SQLiteConnection connection = new SQLiteConnection(dbPath))
                {
                    connection.Open();

                    string checkUserQuery = "SELECT COUNT(*) FROM user WHERE username = @username";
                    using (var checkCommand = new SQLiteCommand(checkUserQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@username", txtNewUsername.Texts);
                        int userCount = Convert.ToInt32(checkCommand.ExecuteScalar());
                        if (userCount > 0)
                        {
                            MessageBox.Show("Ez a felhasználónév már foglalt.");
                            return;
                        }
                    }

                    string query = "UPDATE user SET username = @Username WHERE id = @userId";

                    using (SQLiteCommand command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Username", txtNewUsername.Texts);
                        command.Parameters.AddWithValue("@userId", userId);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            UserSettings settings = SettingsManager.LoadSettings();
                            settings.Username = txtNewUsername.Texts;
                            SettingsManager.SaveSettings(settings);
                            GlobalEvents.OnUsernameUpdated();
                            MessageBox.Show("Felhasználónév sikeresen frissítve!");
                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Hiba történt az email cím frissítésekor.");
                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba: " + ex.Message);
            }
        }

        private void ChangeUsernameForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            UsernameUpdated?.Invoke(this, EventArgs.Empty);
        }
    }
}
