﻿using Password_Manager;
using System;
using System.Data.SQLite;
using System.IO;
using System.Net.Mail;
using System.Net;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using System.Drawing.Drawing2D;
using System.Drawing;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace PasswordManager
{
    public partial class LoginForm : Form
    {
        RegisterForm registerForm = new RegisterForm();
        private string dbPath = "Data Source=pwdmanager.db";
        public bool isAutoLogin = false;

        private bool isPasswordVisible = false;

        public static int currentUserId = -1;

        public static string currentUsername;

        private EmailService twoFactorAuth;

        private UserSettings settings;

        public LoginForm()
        {
            InitializeComponent();

            LoadLoginData();

            txtUsername.KeyDown += TxtUsername_KeyDown;
            txtPassword.KeyDown += TxtPassword_KeyDown;

            twoFactorAuth = new EmailService();
        }

        private void LoadLoginData()
        {
            UserSettings settings = SettingsManager.LoadSettings();
            if (settings != null)
            {
                if (settings.AutoLoginEnabled)
                {
                    txtUsername.Texts = settings.Username;
                    string hashedPassword = settings.EncryptedPassword;

                    if (!string.IsNullOrEmpty(hashedPassword))
                    {
                        if (AuthenticateHashed(txtUsername.Texts, hashedPassword))
                        {
                            currentUserId = GetUserId(settings.Username);
                            chkRememberMe.Checked = true;
                            isAutoLogin = true;
                            return;
                        }
                    }
                }
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            Login();
        }
        private void Login()
        {
            string username = txtUsername.Texts;
            string password = txtPassword.Texts;

            currentUsername = username;

            if (Authenticate(username, password))
            {
                currentUserId = GetUserId(username);

                UserSettings settings = SettingsManager.LoadSettings();
                if (settings.TwoFactorAuthenticationEnabled)
                {
                    string verificationCode = GenerateVerificationCode();
                    string email = GetUserEmail(username);
                    SendVerificationEmail(email, verificationCode);
                    SettingsManager.SaveSettings(settings);

                    VerificationForm verificationForm = new VerificationForm(email, verificationCode);
                    if (verificationForm.ShowDialog() == DialogResult.OK)
                    {
                        if (chkRememberMe.Checked)
                        {
                            SaveLoginData(username, password);
                        }
                        else
                        {
                            SettingsManager.LoadSettings();
                            settings.AutoLoginEnabled = false;
                            SettingsManager.SaveSettings(settings);
                        }     
                        OpenMainForm();
                    }
                    else
                    {
                        MessageBox.Show("A hitelesítés meghiúsult. Kérlek, próbáld újra.");
                    }
                }
                else
                {
                    if (chkRememberMe.Checked)
                    {
                        SaveLoginData(username, password);
                    }
                    else
                    {
                        SettingsManager.LoadSettings();
                        settings.AutoLoginEnabled = false;
                        SettingsManager.SaveSettings(settings);

                    }
                    OpenMainForm();
                }
                
            }
            else
            {
                MessageBox.Show("Hibás felhasználónév vagy jelszó!");
            }
        }

        public bool Authenticate(string username, string password)
        {
            using (var connection = new SQLiteConnection(dbPath))
            {
                connection.Open();
                string query = "SELECT password FROM user WHERE username = @username";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    var result = command.ExecuteScalar();

                    if (result != null)
                    {
                        string storedPasswordHash = result.ToString();
                        return PasswordHelper.VerifyPassword(password, storedPasswordHash);
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }
        public bool AuthenticateHashed(string username, string hashedpassword)
        {
            using (var connection = new SQLiteConnection(dbPath))
            {
                connection.Open();
                string query = "SELECT password FROM user WHERE username = @username";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    var result = command.ExecuteScalar();

                    if (result != null)
                    {
                        string storedPasswordHash = result.ToString();
                        return storedPasswordHash == hashedpassword;
                    }
                    else
                    {
                        return false;
                    }
                }
            }
        }

        public string GetUserEmail(string username)
        {
            using (var connection = new SQLiteConnection(dbPath))
            {
                connection.Open();
                string query = "SELECT email FROM user WHERE username = @username";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    var result = command.ExecuteScalar();
                    return result?.ToString();
                }
            }
        }
        private void SaveLoginData(string username, string password)
        {
            UserSettings settings = SettingsManager.LoadSettings();

            // Ellenőrzés, hogy a settings nem null
            if (settings == null)
            {
                settings = new UserSettings();
            }

            settings.EncryptedPassword = PasswordHelper.HashPassword(password);
            settings.Username = username;
            settings.AutoLoginEnabled = true;

            SettingsManager.SaveSettings(settings);
        }

        private int GetUserId(string username)
        {
            int userId = -1;
            using (var connection = new SQLiteConnection(dbPath))
            {
                connection.Open();
                string query = "SELECT id FROM user WHERE username = @username";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    var result = command.ExecuteScalar();
                    if (result != null)
                    {
                        userId = Convert.ToInt32(result);
                    }
                }
            }
            return userId;
        }

        public async void SendVerificationEmail(string email, string code)
        {
            try
            {
                EmailService emailService = new EmailService();
                await emailService.SendEmail(email, "Kétlépcsős Hitelesítő Kód", code);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba az email küldésekor: {ex.Message}");
            }
        }
        public string GenerateVerificationCode()
        {
            Random random = new Random();
            return random.Next(100000, 999999).ToString();
        }


        private void OpenMainForm()
        {
            this.Hide();
            if (Form1.instance == null)
            {
                Form1 mainForm = new Form1();
                mainForm.Show();
            }
            else
            {
                Form1.instance.Show();
            }

        }

        private void BtnSignup_Click(object sender, EventArgs e)
        {
            registerForm.ShowDialog();
        }

        private void btnTogglePassword_Click(object sender, EventArgs e)
        {
            if (isPasswordVisible)
            {
                txtPassword.PasswordChar = true; 
                btnTogglePassword.Text = "👁"; 
            }
            else
            {
                txtPassword.PasswordChar = false; 
                btnTogglePassword.Text = "👁‍🗨"; 
            }

            isPasswordVisible = !isPasswordVisible; 
        }

        private void TxtUsername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Login();
            }
        }

        private void TxtPassword_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Login();
            }
        }

        bool isChecked = false;
        private void chkRememberMe_CheckedChanged(object sender, EventArgs e)
        {
            isChecked = chkRememberMe.Checked;
        }

        private void chkRememberMe_Click(object sender, EventArgs e)
        {
            if (chkRememberMe.Checked && !isChecked)
                chkRememberMe.Checked = false;
            else
            {
                chkRememberMe.Checked = true;
                isChecked = false;
            }
        }

        private void LoginForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
