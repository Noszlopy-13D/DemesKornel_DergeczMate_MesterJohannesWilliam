﻿using Password_Manager.UserControls;
using PasswordManager;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Manager
{
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        /// 

        static Mutex mutex = new Mutex(true, "LockBox");
        [STAThread]
        static void Main()
        {
            Application.SetCompatibleTextRenderingDefault(false);
            Application.EnableVisualStyles();

            LoginForm loginForm = new LoginForm();

            // Adatbázis inicializálása
            DatabaseHelper.InitializeDatabase();
            DatabaseHelper.CreatePasswordTableIfNotExists();

            EncryptionKeyManager.EnsureEncryptionKeyExists();

            //form1.InitializeTrayIcon();

            UserSettings settings = SettingsManager.LoadSettings();

            if (!settings.AutoBackupEnabled)
            {
                GlobalEvents.OnBackupSettingChanged();
                settings.BackupInterval = "0";
            }
            if (settings.AutoLoginEnabled)
            {
                if (!mutex.WaitOne(TimeSpan.Zero, true))
                {
                    MessageBox.Show("Az alkalmazás már fut.");
                    return;
                }
                Application.Run(new Form1());
                mutex.ReleaseMutex();
                //Application.Run(new Form1());
            }
            else
            {
                Application.Run(new LoginForm());
            }
        }
    }
}
