﻿namespace Password_Manager
{
    partial class AddItemForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.comboBoxImages = new System.Windows.Forms.ComboBox();
            this.btnTogglePassword = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnPWDGenerate = new System.Windows.Forms.Button();
            this.txtPassword = new CustomControls.RJControls.RJTextBox();
            this.txtUsername = new CustomControls.RJControls.RJTextBox();
            this.txtApplication = new CustomControls.RJControls.RJTextBox();
            this.SuspendLayout();
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // comboBoxImages
            // 
            this.comboBoxImages.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.comboBoxImages.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.comboBoxImages.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxImages.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBoxImages.FormattingEnabled = true;
            this.comboBoxImages.ItemHeight = 100;
            this.comboBoxImages.Location = new System.Drawing.Point(12, 70);
            this.comboBoxImages.MaxDropDownItems = 5;
            this.comboBoxImages.Name = "comboBoxImages";
            this.comboBoxImages.Size = new System.Drawing.Size(274, 106);
            this.comboBoxImages.TabIndex = 1;
            this.comboBoxImages.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.ComboBoxImages_DrawItem);
            this.comboBoxImages.DropDown += new System.EventHandler(this.comboBoxImages_DropDown);
            this.comboBoxImages.SelectedIndexChanged += new System.EventHandler(this.comboBoxImages_SelectedIndexChanged);
            // 
            // btnTogglePassword
            // 
            this.btnTogglePassword.BackColor = System.Drawing.Color.Transparent;
            this.btnTogglePassword.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnTogglePassword.FlatAppearance.BorderSize = 0;
            this.btnTogglePassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTogglePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnTogglePassword.ForeColor = System.Drawing.Color.White;
            this.btnTogglePassword.Location = new System.Drawing.Point(650, 145);
            this.btnTogglePassword.Name = "btnTogglePassword";
            this.btnTogglePassword.Size = new System.Drawing.Size(31, 31);
            this.btnTogglePassword.TabIndex = 9;
            this.btnTogglePassword.Text = "👁";
            this.btnTogglePassword.UseVisualStyleBackColor = false;
            this.btnTogglePassword.Click += new System.EventHandler(this.btnTogglePassword_Click);
            // 
            // btnSave
            // 
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.Red;
            this.btnSave.Location = new System.Drawing.Point(520, 206);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(130, 38);
            this.btnSave.TabIndex = 10;
            this.btnSave.Text = "Mentés";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnPWDGenerate
            // 
            this.btnPWDGenerate.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnPWDGenerate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPWDGenerate.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPWDGenerate.ForeColor = System.Drawing.Color.Red;
            this.btnPWDGenerate.Location = new System.Drawing.Point(12, 206);
            this.btnPWDGenerate.Name = "btnPWDGenerate";
            this.btnPWDGenerate.Size = new System.Drawing.Size(160, 38);
            this.btnPWDGenerate.TabIndex = 13;
            this.btnPWDGenerate.Text = "Jelszó Generálás";
            this.btnPWDGenerate.UseVisualStyleBackColor = true;
            this.btnPWDGenerate.Click += new System.EventHandler(this.btnPWDGenerate_Click);
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.txtPassword.BorderColor = System.Drawing.Color.Red;
            this.txtPassword.BorderFocusColor = System.Drawing.Color.Red;
            this.txtPassword.BorderRadius = 0;
            this.txtPassword.BorderSize = 2;
            this.txtPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.ForeColor = System.Drawing.Color.LightGray;
            this.txtPassword.Location = new System.Drawing.Point(311, 145);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4);
            this.txtPassword.Multiline = false;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtPassword.PasswordChar = false;
            this.txtPassword.PlaceholderColor = System.Drawing.Color.Silver;
            this.txtPassword.PlaceholderText = "Jelszó";
            this.txtPassword.ReadOnly = false;
            this.txtPassword.Size = new System.Drawing.Size(339, 31);
            this.txtPassword.TabIndex = 19;
            this.txtPassword.Texts = "";
            this.txtPassword.UnderlinedStyle = false;
            // 
            // txtUsername
            // 
            this.txtUsername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.txtUsername.BorderColor = System.Drawing.Color.Red;
            this.txtUsername.BorderFocusColor = System.Drawing.Color.Red;
            this.txtUsername.BorderRadius = 0;
            this.txtUsername.BorderSize = 2;
            this.txtUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.ForeColor = System.Drawing.Color.LightGray;
            this.txtUsername.Location = new System.Drawing.Point(311, 108);
            this.txtUsername.Margin = new System.Windows.Forms.Padding(4);
            this.txtUsername.Multiline = false;
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtUsername.PasswordChar = false;
            this.txtUsername.PlaceholderColor = System.Drawing.Color.Silver;
            this.txtUsername.PlaceholderText = "Felhasználónév";
            this.txtUsername.ReadOnly = false;
            this.txtUsername.Size = new System.Drawing.Size(339, 31);
            this.txtUsername.TabIndex = 18;
            this.txtUsername.Texts = "";
            this.txtUsername.UnderlinedStyle = false;
            // 
            // txtApplication
            // 
            this.txtApplication.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.txtApplication.BorderColor = System.Drawing.Color.Red;
            this.txtApplication.BorderFocusColor = System.Drawing.Color.Red;
            this.txtApplication.BorderRadius = 0;
            this.txtApplication.BorderSize = 2;
            this.txtApplication.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApplication.ForeColor = System.Drawing.Color.LightGray;
            this.txtApplication.Location = new System.Drawing.Point(311, 69);
            this.txtApplication.Margin = new System.Windows.Forms.Padding(4);
            this.txtApplication.Multiline = false;
            this.txtApplication.Name = "txtApplication";
            this.txtApplication.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtApplication.PasswordChar = false;
            this.txtApplication.PlaceholderColor = System.Drawing.Color.Silver;
            this.txtApplication.PlaceholderText = "Alkalmazás";
            this.txtApplication.ReadOnly = false;
            this.txtApplication.Size = new System.Drawing.Size(339, 31);
            this.txtApplication.TabIndex = 17;
            this.txtApplication.Texts = "";
            this.txtApplication.UnderlinedStyle = false;
            // 
            // AddItemForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.ClientSize = new System.Drawing.Size(721, 258);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.txtApplication);
            this.Controls.Add(this.btnPWDGenerate);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnTogglePassword);
            this.Controls.Add(this.comboBoxImages);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "AddItemForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Hozzáadás";
            this.Load += new System.EventHandler(this.AddItemForm_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ComboBox comboBoxImages;
        private System.Windows.Forms.Button btnTogglePassword;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnPWDGenerate;
        private CustomControls.RJControls.RJTextBox txtApplication;
        private CustomControls.RJControls.RJTextBox txtUsername;
        private CustomControls.RJControls.RJTextBox txtPassword;
    }
}