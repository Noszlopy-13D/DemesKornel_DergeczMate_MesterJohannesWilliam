﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Password_Manager
{
    public class UserSettings
    {
        public string Username { get; set; }
        public string EncryptedPassword { get; set; } 
        public DateTime LastBackupDate { get; set; }
        public bool AutoLoginEnabled { get; set; }
        public string BackupPath { get; set; }
        public bool AutoBackupEnabled { get; set; }
        public bool TwoFactorAuthenticationEnabled { get; set; }
        public string BackupInterval { get; set; }
        public bool BackupNotificationsEnabled { get; set; }
        public bool MinimizeToTrayOnClose { get; set; }
        public int sortOption { get; set; }

    }
}
