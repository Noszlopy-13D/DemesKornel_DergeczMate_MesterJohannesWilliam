﻿using PasswordManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Manager
{
    public partial class ChangePasswordForm : Form
    {
        private string dbPath = "Data Source=pwdmanager.db";

        public ChangePasswordForm()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string password1 = txtPassword1.Texts;
            string password2 = txtPassword2.Texts;
            if (string.IsNullOrWhiteSpace(password1) || string.IsNullOrWhiteSpace(password2))
            {
                MessageBox.Show("Kérlek, töltsd ki az összes mezőt.");
                return;
            }

            if (password1 == password2)
            {
                txtPassword1.BackColor = System.Drawing.Color.LightGreen;
                txtPassword2.BackColor = System.Drawing.Color.LightGreen;

                try
                {
                    lblMessage.Visible = false;
                    int currentUserId = LoginForm.currentUserId;

                    string verificationCode = GenerateVerificationCode();
                    string email = GetUserEmail(currentUserId);
                    SendVerificationEmail(email, verificationCode);


                    PasswordChangeVerificationForm verificationForm = new PasswordChangeVerificationForm(email, verificationCode, password1);
                    if (verificationForm.ShowDialog() == DialogResult.OK)
                    {
                        this.Close();
                    }

                }
                catch (Exception ex)
                {
                    lblMessage.Text = "Hiba történt: " + ex.Message;
                }
            }
            else
            {
                txtPassword1.BackColor = System.Drawing.Color.LightCoral;
                txtPassword2.BackColor = System.Drawing.Color.LightCoral;
                lblMessage.Visible = true;
            }
        }
        public async void SendVerificationEmail(string email, string code)
        {
            try
            {
                EmailService emailService = new EmailService();
                await emailService.SendEmail(email, "Hitelesítő Kód", code);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba az email küldésekor: {ex.Message}");
            }
        }
        public string GenerateVerificationCode()
        {
            Random random = new Random();
            return random.Next(100000, 999999).ToString();
        }
        public string GetUserEmail(int userId)
        {
            using (var connection = new SQLiteConnection(dbPath))
            {
                connection.Open();
                string query = "SELECT email FROM user WHERE id = @id";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@id", userId);
                    var result = command.ExecuteScalar();
                    return result?.ToString();
                }
            }
        }
    }
}
