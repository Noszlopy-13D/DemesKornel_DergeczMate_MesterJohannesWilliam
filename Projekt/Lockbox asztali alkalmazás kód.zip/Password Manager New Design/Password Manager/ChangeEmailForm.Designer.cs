﻿namespace Password_Manager
{
    partial class ChangeEmailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSave = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lblMessage = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtEmail1 = new CustomControls.RJControls.RJTextBox();
            this.txtEmail2 = new CustomControls.RJControls.RJTextBox();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            this.btnSave.FlatAppearance.BorderColor = System.Drawing.Color.Red;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.Red;
            this.btnSave.Location = new System.Drawing.Point(145, 222);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(130, 38);
            this.btnSave.TabIndex = 19;
            this.btnSave.Text = "Mentés";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(18, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 16);
            this.label2.TabIndex = 20;
            this.label2.Text = "Új Email cím:";
            // 
            // lblMessage
            // 
            this.lblMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.lblMessage.AutoEllipsis = true;
            this.lblMessage.AutoSize = true;
            this.lblMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblMessage.ForeColor = System.Drawing.Color.Red;
            this.lblMessage.Location = new System.Drawing.Point(101, 183);
            this.lblMessage.Name = "lblMessage";
            this.lblMessage.Size = new System.Drawing.Size(219, 16);
            this.lblMessage.TabIndex = 21;
            this.lblMessage.Text = "Az email címek nem egyeznek!";
            this.lblMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblMessage.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(18, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(186, 16);
            this.label1.TabIndex = 22;
            this.label1.Text = "Új Email cím mégegyszer:";
            // 
            // txtEmail1
            // 
            this.txtEmail1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.txtEmail1.BorderColor = System.Drawing.Color.Red;
            this.txtEmail1.BorderFocusColor = System.Drawing.Color.Red;
            this.txtEmail1.BorderRadius = 0;
            this.txtEmail1.BorderSize = 2;
            this.txtEmail1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail1.ForeColor = System.Drawing.Color.LightGray;
            this.txtEmail1.Location = new System.Drawing.Point(21, 74);
            this.txtEmail1.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail1.Multiline = false;
            this.txtEmail1.Name = "txtEmail1";
            this.txtEmail1.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtEmail1.PasswordChar = false;
            this.txtEmail1.PlaceholderColor = System.Drawing.Color.Silver;
            this.txtEmail1.PlaceholderText = "";
            this.txtEmail1.Size = new System.Drawing.Size(378, 31);
            this.txtEmail1.TabIndex = 23;
            this.txtEmail1.Texts = "";
            this.txtEmail1.UnderlinedStyle = false;
            // 
            // txtEmail2
            // 
            this.txtEmail2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(44)))), ((int)(((byte)(44)))), ((int)(((byte)(44)))));
            this.txtEmail2.BorderColor = System.Drawing.Color.Red;
            this.txtEmail2.BorderFocusColor = System.Drawing.Color.Red;
            this.txtEmail2.BorderRadius = 0;
            this.txtEmail2.BorderSize = 2;
            this.txtEmail2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail2.ForeColor = System.Drawing.Color.LightGray;
            this.txtEmail2.Location = new System.Drawing.Point(21, 135);
            this.txtEmail2.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail2.Multiline = false;
            this.txtEmail2.Name = "txtEmail2";
            this.txtEmail2.Padding = new System.Windows.Forms.Padding(10, 7, 10, 7);
            this.txtEmail2.PasswordChar = false;
            this.txtEmail2.PlaceholderColor = System.Drawing.Color.Silver;
            this.txtEmail2.PlaceholderText = "";
            this.txtEmail2.Size = new System.Drawing.Size(378, 31);
            this.txtEmail2.TabIndex = 24;
            this.txtEmail2.Texts = "";
            this.txtEmail2.UnderlinedStyle = false;
            // 
            // ChangeEmailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(33)))), ((int)(((byte)(33)))));
            this.ClientSize = new System.Drawing.Size(420, 272);
            this.Controls.Add(this.txtEmail2);
            this.Controls.Add(this.txtEmail1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblMessage);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnSave);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "ChangeEmailForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Email megváltoztatása";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblMessage;
        private System.Windows.Forms.Label label1;
        private CustomControls.RJControls.RJTextBox txtEmail1;
        private CustomControls.RJControls.RJTextBox txtEmail2;
    }
}