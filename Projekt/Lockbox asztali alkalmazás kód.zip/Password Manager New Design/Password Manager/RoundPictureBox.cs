﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.Drawing;

namespace Password_Manager
{
    internal class RoundPictureBox : PictureBox
    {
        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);

            // Sima élekhez az antialiasing beállítása
            pe.Graphics.SmoothingMode = SmoothingMode.AntiAlias;

            // Kerek forma rajzolása
            GraphicsPath grpath = new GraphicsPath();
            grpath.AddEllipse(0, 0, ClientSize.Width, ClientSize.Height);

            // Állítsuk be a régiót, hogy a kép lekerekített formában jelenjen meg
            this.Region = new Region(grpath);

            // Rajzoljuk ki a képet a lekerekített régióval
            pe.Graphics.SetClip(grpath); // Beállítjuk a klipszerű maszkot
            base.OnPaint(pe); // Meghívjuk az alapértelmezett rajzolást


            /*
            GraphicsPath grpath = new GraphicsPath();
            grpath.AddEllipse(0, 0, ClientSize.Width, ClientSize.Height);
            this.Region = new System.Drawing.Region(grpath);
            base.OnPaint(pe);*/
        }
    }
}
