﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;

namespace Password_Manager
{
    public class EmailService
    {
        private string smtpServer = "smtp.rackhost.hu"; 
        private int smtpPort = 587; 
        private string username = "info@lockbox.hu"; 
        private string password = "Lockbox0522"; 

        public async Task SendEmail(string toEmail, string subject, string body)
        {
            try
            {
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress(username);
                mail.To.Add(toEmail);
                mail.Subject = subject;
                mail.Body = body;

                using (SmtpClient smtpClient = new SmtpClient(smtpServer, smtpPort))
                {
                    smtpClient.Credentials = new NetworkCredential(username, password);
                    smtpClient.EnableSsl = true;
                    await smtpClient.SendMailAsync(mail);
                }
            }
            catch (SmtpException smtpEx)
            {
                MessageBox.Show($"SMTP hiba: {smtpEx.StatusCode} - {smtpEx.Message}");
                throw;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hiba az e-mail küldésekor: {ex.Message}");
                throw;
            }
        }
    }
}
