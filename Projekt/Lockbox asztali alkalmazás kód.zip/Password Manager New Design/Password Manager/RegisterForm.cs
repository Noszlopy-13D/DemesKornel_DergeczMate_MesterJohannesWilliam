﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;
using PasswordManager;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.IO;


namespace Password_Manager
{
    public partial class RegisterForm : Form
    {
        private static string dbPath = "Data Source=pwdmanager.db";

        private bool isPasswordVisible = false;
        

        public RegisterForm()
        {
            InitializeComponent();
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Texts;
            string password = txtPassword.Texts;
            string email = txtEmail.Texts;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(email))
            {
                MessageBox.Show("Kérlek, töltsd ki az összes mezőt.");
                return;
            }
            if (!IsValidEmail(email))
            {
                MessageBox.Show("Kérlek, adj meg egy érvényes e-mail címet!");
                return;
            }

            string hashedPassword = PasswordHelper.HashPassword(password);


            try
            {
                using (var connection = new SQLiteConnection(dbPath))
                {
                    connection.Open();

                    // Ellenőrizd, hogy létezik-e a felhasználónév
                    string checkUserQuery = "SELECT COUNT(*) FROM user WHERE username = @username";
                    using (var checkCommand = new SQLiteCommand(checkUserQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@username", username);
                        int userCount = Convert.ToInt32(checkCommand.ExecuteScalar());
                        if (userCount > 0)
                        {
                            MessageBox.Show("Ez a felhasználónév már foglalt.");
                            return;
                        }
                    }

                    Image defaultImage = roundPictureBox1.Image; 


                    // Felhasználó regisztrálása az adatbázisba
                    string insertQuery = "INSERT INTO user (username, password, email, profile_picture) VALUES (@username, @password, @Email, @ProfilePicture)";
                    using (var command = new SQLiteCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@username", username);
                        command.Parameters.AddWithValue("@password", hashedPassword);
                        command.Parameters.AddWithValue("@Email", email);

                        using (var ms = new MemoryStream())
                        {
                            defaultImage.Save(ms, defaultImage.RawFormat);
                            byte[] logoBytes = ms.ToArray();
                            command.Parameters.AddWithValue("@ProfilePicture", logoBytes);
                        }

                        command.ExecuteNonQuery();
                        MessageBox.Show("Regisztráció sikeres!");
                        this.Close();
                    }
                }
            }
            catch (SQLiteException ex)
            {
                MessageBox.Show("Sikertelen regisztráció! Hiba: " + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Sikertelen regisztráció! Hiba: " + ex.Message);
            }
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public bool IsValidEmail(string email)
        {
            try
            {
                MailAddress mail = new MailAddress(email);
                return true;
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private void btnTogglePassword_Click(object sender, EventArgs e)
        {
            if (isPasswordVisible)
            {
                txtPassword.PasswordChar = true; 
            }
            else
            {
                txtPassword.PasswordChar = false;
            }

            isPasswordVisible = !isPasswordVisible; 
        }
    }
}
