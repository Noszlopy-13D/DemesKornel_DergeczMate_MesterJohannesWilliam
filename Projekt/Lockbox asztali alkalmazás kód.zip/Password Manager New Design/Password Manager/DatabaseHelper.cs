﻿using System;
using System.Data.SQLite;
using System.IO;
using System.Windows.Forms;

namespace Password_Manager
{
    public static class DatabaseHelper
    {
        private static string dbPath = "Data Source=pwdmanager.db";


        public static void InitializeDatabase()
        {
            if (!File.Exists("pwdmanager.db"))
            {
                try
                {
                    SQLiteConnection.CreateFile("pwdmanager.db");

                    using (var connection = new SQLiteConnection("Data Source=pwdmanager.db"))
                    {
                        connection.Open();
                        string createTableQuery = @"
                        CREATE TABLE IF NOT EXISTS user (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            username TEXT NOT NULL,
                            password TEXT NOT NULL,
                            email TEXT NOT NULL,
                            profile_picture BLOB NOT NULL
                        );";
                        using (var command = new SQLiteCommand(createTableQuery, connection))
                        {
                            command.ExecuteNonQuery();
                        }
                    }
                    MessageBox.Show("Adatbázis sikeresen létrehozva!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Hiba történt az adatbázis inicializálásakor: {ex.Message}");
                }
            }

        }

        public static void CreatePasswordTableIfNotExists()
        {
            using (var connection = new SQLiteConnection("Data Source=pwdmanager.db"))
            {
                connection.Open();
                string createTableQuery = @"
                    CREATE TABLE IF NOT EXISTS saved_passwords (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    app_name TEXT,
                    username TEXT,
                    password TEXT,
                    logo BLOB,
                    createdAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                    logo_identifier TEXT,
                    FOREIGN KEY (user_id) REFERENCES user(id)
                    )";
                using (var command = new SQLiteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }
    }
}
