﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Manager
{
    public partial class PasswordGeneratorForm : Form
    {
        public string GeneratedPassword { get; private set; }

        public PasswordGeneratorForm()
        {
            InitializeComponent();
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            int passwordLength;
            if (!int.TryParse(passwordLenght.Text, out passwordLength) || passwordLength <= 0)
            {
                MessageBox.Show("Kérlek adj meg egy érvényes jelszó hosszt!");
                return;
            }

            bool includeLower = checkBoxLower.Checked;
            bool includeUpper = checkBoxUpper.Checked;
            bool includeDigits = checkBoxDigits.Checked;
            bool includeSpecial = checkBoxSpecial.Checked;

            GeneratedPassword = GeneratePassword(passwordLength, includeLower, includeUpper, includeDigits, includeSpecial);

            if (!string.IsNullOrEmpty(GeneratedPassword))
            {
                this.DialogResult = DialogResult.OK; // Beállítjuk a dialog result-ot
                this.Close(); // Bezárjuk a formot
            }
        }

        private string GeneratePassword(int length, bool includeLower, bool includeUpper, bool includeDigits, bool includeSpecial)
        {
            const string lowerChars = "abcdefghijklmnopqrstuvwxyz";
            const string upperChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string digitChars = "0123456789";
            const string specialChars = "!@#$%^&*()-_=+[]{};:,.<>?";

            StringBuilder characterPool = new StringBuilder();
            if (includeLower) characterPool.Append(lowerChars);
            if (includeUpper) characterPool.Append(upperChars);
            if (includeDigits) characterPool.Append(digitChars);
            if (includeSpecial) characterPool.Append(specialChars);

            if (characterPool.Length == 0)
            {
                MessageBox.Show("Legalább egy karaktertípust válassz!");
                return string.Empty;
            }

            Random random = new Random();
            char[] password = new char[length];
            for (int i = 0; i < length; i++)
            {
                password[i] = characterPool[random.Next(characterPool.Length)];
            }

            return new string(password);
        }
    }
}
