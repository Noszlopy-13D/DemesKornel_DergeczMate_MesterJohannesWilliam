﻿using Password_Manager.UserControls;
using PasswordManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Password_Manager
{
    public partial class EmailChangeVerificationForm : Form
    {
        private string dbPath = "Data Source=pwdmanager.db";

        UC_Profile uc_profile = new UC_Profile();

        ChangeEmailForm changeemailform = new ChangeEmailForm();
        private string expectedCode;
        private string _email;
        private string _newEmail;
        public EmailChangeVerificationForm(string email, string code, string newEmail)
        {
            InitializeComponent();
            expectedCode = code;
            _email = email;
            _newEmail = newEmail;
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            string inputCode = txtVerificationCode.Text;
            if (inputCode == expectedCode)
            {
                UpdateEmailInDatabase(LoginForm.currentUserId, _newEmail);
            }
            else
            {
                MessageBox.Show("Érvénytelen kód. Kérlek, próbáld újra.");
            }
        }

        private void btnResendCode_Click(object sender, EventArgs e)
        {
            string verificationCode = changeemailform.GenerateVerificationCode();
            changeemailform.SendVerificationEmail(_email, verificationCode);
            expectedCode = verificationCode;
        }
        private void UpdateEmailInDatabase(int userId, string newEmail)
        {
            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(dbPath))
                {
                    string query = "UPDATE user SET email = @Email WHERE id = @userId";

                    using (SQLiteCommand command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Email", newEmail);
                        command.Parameters.AddWithValue("@userId", userId);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Email cím sikeresen frissítve!");
                            this.DialogResult = DialogResult.OK;
                            uc_profile.LoadAndSetUserProfile(LoginForm.currentUserId);
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Hiba történt az email cím frissítésekor.");
                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba: " + ex.Message);
            }
        }
    }
}
