﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json;

namespace Password_Manager
{
    public static class SettingsManager
    {
        private static string settingsFilePath = "userSettings.json";

        // Beállítások mentése
        public static void SaveSettings(UserSettings settings)
        {
            string json = JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(settingsFilePath, json);
        }

        // Beállítások betöltése
        public static UserSettings LoadSettings()
        {
            if (File.Exists(settingsFilePath))
            {
                string json = File.ReadAllText(settingsFilePath);
                return JsonSerializer.Deserialize<UserSettings>(json);
            }

            // Ha nincs beállítás fájl, akkor térjünk vissza alapértelmezett értékekkel
            return new UserSettings
            {
                Username = "",
                EncryptedPassword = "",
                LastBackupDate = DateTime.MinValue,
                AutoLoginEnabled = false,
                BackupPath = "",
                AutoBackupEnabled = false,
                TwoFactorAuthenticationEnabled = true,
                BackupInterval = "",
                BackupNotificationsEnabled = true,
                MinimizeToTrayOnClose = false,
                sortOption = 2,
            };
        }
    }
}
