﻿using Password_Manager.UserControls;
using PasswordManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Manager
{
    public partial class PasswordChangeVerificationForm : Form
    {
        private string dbPath = "Data Source=pwdmanager.db";

        UC_Profile uc_profile = new UC_Profile();

        ChangePasswordForm changepasswordform = new ChangePasswordForm();
        private string expectedCode;
        private string _email;
        private string _newPassword;

        public PasswordChangeVerificationForm(string email, string code, string newPassword)
        {
            InitializeComponent();
            expectedCode = code;
            _email = email;
            _newPassword = newPassword;
        }

        private void btnVerify_Click(object sender, EventArgs e)
        {
            string inputCode = txtVerificationCode.Text;
            if (inputCode == expectedCode)
            {
                UpdatePasswordInDatabase(LoginForm.currentUserId, _newPassword);
            }
            else
            {
                MessageBox.Show("Érvénytelen kód. Kérlek, próbáld újra.");
            }
        }

        private void btnResendCode_Click(object sender, EventArgs e)
        {
            string verificationCode = changepasswordform.GenerateVerificationCode();
            changepasswordform.SendVerificationEmail(_email, verificationCode);
            expectedCode = verificationCode;
        }

        private void UpdatePasswordInDatabase(int userId, string newPassword)
        {
            string hashedPassword = PasswordHelper.HashPassword(newPassword);
            try
            {
                using (SQLiteConnection connection = new SQLiteConnection(dbPath))
                {
                    string query = "UPDATE user SET password = @Password WHERE id = @userId";

                    using (SQLiteCommand command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Password", hashedPassword);
                        command.Parameters.AddWithValue("@userId", userId);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            UserSettings settings = SettingsManager.LoadSettings();
                            settings.EncryptedPassword = hashedPassword;
                            SettingsManager.SaveSettings(settings);
                            MessageBox.Show("Jelszó sikeresen frissítve!");
                            this.DialogResult = DialogResult.OK;
                            uc_profile.LoadAndSetUserProfile(LoginForm.currentUserId);
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Hiba történt az jelszó frissítésekor.");
                            this.DialogResult = DialogResult.OK;
                            this.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba: " + ex.Message);
            }
        }
    }
}
