﻿using CustomControls.RJControls;
using PasswordManager;
using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.DirectoryServices;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Password_Manager.UserControls
{
    public partial class UC_Main : UserControl
    {
        private List<PasswordData> passwords = new List<PasswordData>();
        private string dbPath = "Data Source=pwdmanager.db";

        private List<CustomPanel> cardList = new List<CustomPanel>();

        private int currentUserId = LoginForm.currentUserId;

        private bool isPasswordVisible = false;

        private Label hiddenFocusTarget;

        public int _recordId;
        public string _appName;
        public string _username;
        public string _password;
        public Image _logo;
        public string _identifier;

        public UC_Main()
        {
            InitializeComponent();
            RefreshPasswords();

            EnableDoubleBuffering(this);

            hiddenFocusTarget = new Label
            {
                Size = new Size(0, 0),
                Location = new Point(0, 0),
                TabStop = false
            };
            this.Controls.Add(hiddenFocusTarget);
            UserSettings settings = SettingsManager.LoadSettings();
            comboBoxSort.SelectedIndex = settings.sortOption;
        }

        public void LoadSavedPasswords()
        {
            UserSettings settings = SettingsManager.LoadSettings();
            doubleBufferedFlowLayoutPanel1.SuspendLayout(); // Felfüggesztjük az elrendezés frissítését
            try
            {
                doubleBufferedFlowLayoutPanel1.Controls.Clear();

                using (var connection = new SQLiteConnection(dbPath))
                {
                    connection.Open();

                    string query = "SELECT id, app_name, username, password, logo, createdAt, logo_identifier FROM saved_passwords WHERE user_id = @userId";

                    switch (settings.sortOption)
                    {
                        case 0: // Név szerint (A-Z)
                            query += " ORDER BY app_name ASC";
                            break;
                        case 1: // Név szerint (Z-A)
                            query += " ORDER BY app_name DESC";
                            break;
                        case 2: // Létrehozási dátum szerint (növekvő)
                            query += " ORDER BY createdAt DESC";
                            break;
                        case 3: // Létrehozási dátum szerint (csökkenő)
                            query += " ORDER BY createdAt ASC";
                            break;
                        default:
                            query += " ORDER BY createdAt DESC"; // Alapértelmezett
                            break;
                    }

                    using (var command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userId", currentUserId);

                        using (SQLiteDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string id = reader["id"].ToString();
                                string appName = reader["app_name"].ToString();
                                string username = reader["username"].ToString();
                                string encryptedPassword = reader["password"].ToString();
                                byte[] logoBytes = (byte[])reader["logo"];
                                DateTime createdAt = Convert.ToDateTime(reader["createdAt"]);
                                string identifier = reader["logo_identifier"].ToString();

                                Image logo;
                                using (var ms = new MemoryStream(logoBytes))
                                {
                                    logo = Image.FromStream(ms);
                                }

                                CreateCard(id, appName, username, encryptedPassword, logo, createdAt, identifier);
                            }
                        }
                    }
                }
            }
            finally
            {
                doubleBufferedFlowLayoutPanel1.ResumeLayout();
            }
        }

        private void CreateCard(string id, string appName, string username, string encryptedPassword, Image logo, DateTime createdAt, string identifier)
        {
            CustomPanel card = new CustomPanel
            {
                Size = new Size(225, 250),
                Margin = new Padding(10),
                BackColor = Color.FromArgb(30,30,30),
                BorderColor = Color.Red,
                BorderRadius = 20,
                Tag = id,
            };

            RJCircularPictureBox pictureBox = new RJCircularPictureBox
            {
                Image = logo,
                Size = new Size(64, 64),
                Location = new Point(82, 10),
                SizeMode = PictureBoxSizeMode.StretchImage,
                BackColor = Color.White,
                BorderColor = appName == "Egyéb" ? Color.Red : Color.Transparent,
                BorderColor2 = appName == "Egyéb" ? Color.Cyan : Color.Transparent,
            };
            card.Controls.Add(pictureBox);
            
            Label lblAppName = new Label
            {
                Text = appName,
                Location = new Point(25, 80),
                Size = new Size(180, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Arial", 10, FontStyle.Bold),
                ForeColor = Color.FromArgb(255,255,255),
            };
            card.Controls.Add(lblAppName);

            TextBox lblUsername = new TextBox
            {
                Text = username,
                Location = new Point(10, 130),
                Size = new Size(180, 50),
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Sans-Sherif", 14, FontStyle.Bold),
                ReadOnly = true,
                BackColor = Color.FromArgb(40,40,40),
                ForeColor = Color.FromArgb(255,255,255),
                Name = "txtUsername",
            };
            card.Controls.Add(lblUsername);

            TextBox lblPassword = new TextBox
            {
                Text = EncryptionHelper.Decrypt(encryptedPassword),
                Location = new Point(10, 180),
                Size = new Size(150, 50),
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Sans-Sherif", 14, FontStyle.Bold),
                ReadOnly = true,
                PasswordChar = '*',
                BackColor = Color.FromArgb(40,40,40),
                ForeColor = Color.FromArgb(255, 255, 255),
                Name = "txtPassword",
            };
            card.Controls.Add(lblPassword);

            CustomButton btnTogglePassword = new CustomButton
            {
                BackColor = Color.FromArgb(30,30,30),
                BorderColor = Color.FromArgb(30, 30, 30),
                FlatStyle = FlatStyle.Flat,
                BorderSize = 1,
                Font = new Font("Microsoft Sans Serif", 12F, FontStyle.Regular),
                ForeColor = Color.White,
                Location = new Point(160, 180),
                Name = "btnTogglePassword",
                Size = new Size(30, 30),
                Text = "👁",
            };
            btnTogglePassword.Click += (s, e) => TogglePasswordVisibility(lblPassword, btnTogglePassword);
            card.Controls.Add(btnTogglePassword);

            CustomButton btnCopyUNToClipBoard = new CustomButton
            {
                BackColor = Color.FromArgb(30,30,30),
                BorderColor = Color.FromArgb(30, 30, 30),
                FlatStyle = FlatStyle.Flat,
                BorderSize = 1,
                Location = new Point(190, 130),
                Name = "btnCopyUNToClipBoard",
                Size = new Size(30, 30),
                BackgroundImage = global::Password_Manager.Properties.Resources.iconCopy,
                BackgroundImageLayout = ImageLayout.Stretch,
            };
            btnCopyUNToClipBoard.Click += (s, e) => btnCopyUNToClipboard_Click(lblUsername);
            card.Controls.Add(btnCopyUNToClipBoard);

            CustomButton btnCopyPWDToClipBoard = new CustomButton
            {
                BackColor = Color.FromArgb(30,30,30),
                BorderColor = Color.FromArgb(30, 30, 30),
                FlatStyle = FlatStyle.Flat,
                BorderSize = 1,
                Location = new Point(190, 180),
                Name = "btnCopyPWDToClipBoard",
                Size = new Size(30, 30),
                BackgroundImage = global::Password_Manager.Properties.Resources.iconCopy,
                BackgroundImageLayout = ImageLayout.Stretch,
            };
            btnCopyPWDToClipBoard.Click += (s, e) => btnCopyPWDToClipboard_Click(lblPassword);
            card.Controls.Add(btnCopyPWDToClipBoard);

            CustomButton btnDelete = new CustomButton
            {
                BackColor = Color.FromArgb(30, 30, 30),
                BorderColor = Color.FromArgb(30, 30, 30),
                FlatStyle = FlatStyle.Flat,
                BorderSize = 1,
                BackgroundImage = global::Password_Manager.Properties.Resources.iconDelete,
                BackgroundImageLayout = ImageLayout.Stretch,
                Location = new Point(195, 215),
                Name = "btnDelete",
                Size = new Size(25, 25),
                Tag = id,
            };
            card.Controls.Add(btnDelete);
            btnDelete.Click += (sender, e) => DeleteCard(Convert.ToInt32(btnDelete.Tag), card); 

            CustomButton btnEdit = new CustomButton
            {
                BackColor = Color.FromArgb(30, 30, 30),
                BorderColor = Color.FromArgb(30,30,30),
                FlatStyle = FlatStyle.Flat,
                BorderSize = 1,
                BackgroundImage = global::Password_Manager.Properties.Resources.iconEdit1,
                BackgroundImageLayout = ImageLayout.Stretch,
                Location = new Point(160, 215),
                Name = "btnEdit",
                Size = new Size(25, 25),
                Tag = id,
            };
            btnEdit.Click += (sender, e) => EditCard(Convert.ToInt32(btnEdit.Tag));
            card.Controls.Add(btnEdit);

            Label lblCreatedAt = new Label
            {
                Text = $"Létrehozva: {createdAt:yyyy-MM-dd}",
                Location = new Point(5, 220),
                Size = new Size(180, 20),
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Arial", 8, FontStyle.Italic),
                ForeColor = Color.FromArgb(200, 200, 200),
                Visible = false,
            };
            card.Controls.Add(lblCreatedAt);

            Label lblIdentifier = new Label
            {
                Text = identifier,
                Location = new Point(1, 1),
                Size = new Size(180, 20),
                Visible = false,
            };
            card.Controls.Add(lblIdentifier);


            doubleBufferedFlowLayoutPanel1.Controls.Add(card);     
        }
        private void EditCard(int recordId)
        {
            try
            {
                using (var connection = new SQLiteConnection(dbPath))
                {
                    connection.Open();
                    string query = "SELECT app_name, username, password, logo, logo_identifier FROM saved_passwords WHERE id = @id";
                    using (var command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", recordId);
                        using (SQLiteDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string appName = reader["app_name"].ToString();
                                string username = reader["username"].ToString();
                                string password = EncryptionHelper.Decrypt(reader["password"].ToString()); 
                                byte[] logoBytes = (byte[])reader["logo"];
                                string identifier = reader["logo_identifier"].ToString();
       
                                Image logo;
                                using (var ms = new MemoryStream(logoBytes))
                                {
                                    logo = Image.FromStream(ms);
                                }
                                connection.Close();
                                
                                this._recordId = recordId;
                                this._appName = appName;
                                this._username = username;
                                this._password = password;
                                this._logo = logo;
                                this._identifier = identifier;
                            }
                            else
                            {
                                MessageBox.Show("Nem található rekord a megadott azonosítóval.");
                                return;
                            }
                        }
                    }
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba: " + ex.Message);
                return;
            }
            EditForm editForm = new EditForm(_recordId, _appName, _username, _password, _logo, _identifier);
            editForm.RecordUpdated += RefreshPasswords;  

            editForm.ShowDialog();
        }

        private void DeleteCard(int recordId, Panel card)
        {
            DialogResult dialogResult = MessageBox.Show($"Biztosan törölni szeretnéd ezt a bejegyzést?",
                                                        "Törlés megerősítése",
                                                        MessageBoxButtons.YesNo,
                                                        MessageBoxIcon.Warning);

            if (dialogResult == DialogResult.Yes)
            {
                using (var connection = new SQLiteConnection(dbPath))
                {
                    connection.Open();
                    string query = "DELETE FROM saved_passwords WHERE id = @recordId AND user_id = @userId";
                    using (var command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@recordId", recordId);
                        command.Parameters.AddWithValue("@userId", currentUserId);
                        command.ExecuteNonQuery();
                    }
                }

                RefreshPasswords();
            }
        }

        private void TogglePasswordVisibility(TextBox passwordTextBox, Button toggleButton)
        {
            bool isPasswordVisible = toggleButton.Tag as bool? ?? false;
            if (isPasswordVisible)
            {
                toggleButton.Enabled = false;
                passwordTextBox.PasswordChar = '*';
                hiddenFocusTarget.Focus();
                toggleButton.Enabled = true;
            }
            else
            {
                toggleButton.Enabled = false;
                passwordTextBox.PasswordChar = '\0';
                hiddenFocusTarget.Focus();
                toggleButton.Enabled = true;
            }
            toggleButton.Tag = !isPasswordVisible;
        }

        public void RefreshPasswords()
        {
            LoadSavedPasswords(); 
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchText = txtSearch.Text.ToLower();
            FilterPasswords(searchText);
        }

        private void FilterPasswords(string searchText)
        {
            
            if (string.IsNullOrWhiteSpace(searchText))
            {
                LoadSavedPasswords();
                return;
            }

            passwords = GetPasswordsFromDatabase(searchText);  

            doubleBufferedFlowLayoutPanel1.Controls.Clear();  

            foreach (var password in passwords)  
            {
                CreateCard(password.Id.ToString(), password.ApplicationName, password.Username, password.Password, Image.FromStream(new MemoryStream(password.Logo)), password.CreatedAt, password.Identifier);  // Létrehozzuk az egyes jelszókártyákat a szűrt eredményekből
            }
        }



        private List<PasswordData> GetPasswordsFromDatabase(string searchText = null)
        {
            var passwordList = new List<PasswordData>();

            using (var connection = new SQLiteConnection(dbPath))
            {
                connection.Open();
                string query = "SELECT id, app_name, username, password, logo, createdAt, logo_identifier FROM saved_passwords WHERE user_id = @userId";

                if (!string.IsNullOrWhiteSpace(searchText))  // Ha van keresési szöveg, szűrjük az adatokat
                {
                    query += " AND (app_name LIKE @search OR username LIKE @search)";
                }

                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@userId", currentUserId);
                    if (!string.IsNullOrWhiteSpace(searchText))
                    {
                        command.Parameters.AddWithValue("@search", "%" + searchText + "%");
                    }

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id = Convert.ToInt32(reader["id"]);
                            var password = new PasswordData(
                                id,
                                reader["app_name"].ToString(),
                                reader["username"].ToString(),
                                reader["password"].ToString(),
                                (byte[])reader["logo"],
                                Convert.ToDateTime(reader["createdAt"]),
                                reader["logo_identifier"].ToString()
                            );

                            passwordList.Add(password);
                        }
                    }
                }
            }
            return passwordList;
        }



        private void button1_Click(object sender, EventArgs e)
        {
            AddItemForm addItem = new AddItemForm();
            addItem.PasswordAdded += RefreshPasswords;
            addItem.ShowDialog();
        }

        private void btnCopyUNToClipboard_Click(TextBox txtbox)
        {
            Clipboard.SetText(txtbox.Text);

            ToolTip tooltip = new ToolTip();
            tooltip.Show("Felhasználónév másolva!", txtbox, 1000);
        }
        private void btnCopyPWDToClipboard_Click(TextBox txtbox)
        {
            Clipboard.SetText(txtbox.Text);

            ToolTip tooltip = new ToolTip();
            tooltip.Show("Jelszó másolva!", txtbox, 1000);
        }

        private void EnableDoubleBuffering(Control control)
        {
            if (SystemInformation.TerminalServerSession)
                return;


            var controlType = control.GetType();
            var pi = controlType.GetProperty("DoubleBuffered", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
            if (pi != null && pi.PropertyType == typeof(bool))
            {
                pi.SetValue(control, true, null);
            }

            foreach (Control childControl in control.Controls)
            {
                EnableDoubleBuffering(childControl);
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox3.Enabled = false;
            txtSearch.Focus();
        }

        private void txtSearch_Leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(txtSearch.Text))
            {
                pictureBox3.Visible = true;
                pictureBox3.Enabled = true;
            }
            
        }

        private void txtSearch_Click(object sender, EventArgs e)
        {
            pictureBox3.Visible = false;
            pictureBox3.Enabled = false;
        }

        private void doubleBufferedFlowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {
            Color startColor = Color.FromArgb(11,7,17); 
            Color endColor = Color.FromArgb(40,40,40);   
            
            using (LinearGradientBrush brush = new LinearGradientBrush(
                doubleBufferedFlowLayoutPanel1.ClientRectangle, 
                startColor,            
                endColor,              
                LinearGradientMode.Vertical)) 
            {
                e.Graphics.FillRectangle(brush, doubleBufferedFlowLayoutPanel1.ClientRectangle); 
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();
            int sortOption = comboBoxSort.SelectedIndex;
            settings.sortOption = sortOption;
            SettingsManager.SaveSettings(settings);
            LoadSavedPasswords();
        }
    }


    public class CustomPanel : Panel
    {
        public Color BorderColor { get; set; } = Color.Red;
        public int BorderRadius { get; set; } = 20; 
        private readonly int BorderWidth = 2;

        public CustomPanel()
        {
            this.DoubleBuffered = true; 
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.UpdateStyles();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            e.Graphics.Clear(this.BackColor);


            using (Pen pen = new Pen(BorderColor, BorderWidth))
            {
                // Lekerekített téglalap rajzolása
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                e.Graphics.DrawArc(pen, 0, 0, BorderRadius, BorderRadius, 180, 90);  // Bal felső sarok
                e.Graphics.DrawArc(pen, this.Width - BorderRadius - 1, 0, BorderRadius, BorderRadius, 270, 90); // Jobb felső sarok
                e.Graphics.DrawArc(pen, this.Width - BorderRadius - 1, this.Height - BorderRadius - 1, BorderRadius, BorderRadius, 0, 90); // Jobb alsó sarok
                e.Graphics.DrawArc(pen, 0, this.Height - BorderRadius - 1, BorderRadius, BorderRadius, 90, 90);  // Bal alsó sarok

                // A bordert összekötő vonalak
                e.Graphics.DrawLine(pen, BorderRadius / 2, 0, this.Width - BorderRadius / 2, 0); // Felső
                e.Graphics.DrawLine(pen, this.Width, BorderRadius / 2, this.Width, this.Height - BorderRadius / 2); // Jobb
                e.Graphics.DrawLine(pen, BorderRadius / 2, this.Height, this.Width - BorderRadius / 2, this.Height); // Alsó
                e.Graphics.DrawLine(pen, 0, this.Height - BorderRadius / 2, 0, BorderRadius / 2); // Bal
            }



            /*
            using (GraphicsPath path = new GraphicsPath())
            {
                path.AddArc(0, 0, BorderRadius, BorderRadius, 180, 90);
                path.AddArc(this.Width - BorderRadius, 0, BorderRadius, BorderRadius, 270, 90);
                path.AddArc(this.Width - BorderRadius, this.Height - BorderRadius, BorderRadius, BorderRadius, 0, 90);
                path.AddArc(0, this.Height - BorderRadius, BorderRadius, BorderRadius, 90, 90);
                path.CloseFigure();

                this.Region = new Region(path);
            }
            */

            using (Pen pen = new Pen(BorderColor, BorderWidth))
            {
                e.Graphics.DrawPath(pen, CreateRoundedRectanglePath(new Rectangle(0, 0, this.Width - BorderWidth, this.Height - BorderWidth), BorderRadius));
            }
        }

        private GraphicsPath CreateRoundedRectanglePath(Rectangle rect, int radius)
        {
            GraphicsPath path = new GraphicsPath();
            path.AddArc(rect.X, rect.Y, radius, radius, 180, 90);
            path.AddArc(rect.X + rect.Width - radius, rect.Y, radius, radius, 270, 90);
            path.AddArc(rect.X + rect.Width - radius, rect.Y + rect.Height - radius, radius, radius, 0, 90);
            path.AddArc(rect.X, rect.Y + rect.Height - radius, radius, radius, 90, 90);
            path.CloseFigure();
            return path;
        }

        [DllImport("Gdi32.dll")]
        private static extern IntPtr CreateRoundRectRgn(int nLeftRect, int nTopRect, int nRightRect, int nBottomRect, int nWidthEllipse, int nHeightEllipse);

        [DllImport("Gdi32.dll")]
        private static extern bool DeleteObject(IntPtr hObject);
    }

    public class CustomButton : Button
    {
        public int BorderSize { get; set; } = 0;
        public Color BorderColor { get; set; } = Color.Black;

        public CustomButton()
        {
            this.DoubleBuffered = true;  // Dupla pufferelés itt is
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.UpdateStyles();
        }


        protected override void OnPaint(PaintEventArgs pevent)
        {
            base.OnPaint(pevent);

            
            using (Pen pen = new Pen(BorderColor, BorderSize))
            {
                pevent.Graphics.DrawRectangle(pen, 0, 0, this.Width - BorderSize, this.Height - BorderSize);
            }
        }
    }


    public class DoubleBufferedFlowLayoutPanel : FlowLayoutPanel
    {
        public DoubleBufferedFlowLayoutPanel()
        {
            // Engedélyezzük a kettős pufferelést a vezérlőn
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);
            this.SetStyle(ControlStyles.ResizeRedraw, true);
            this.UpdateStyles();
        }
    }

    public class PasswordData
    {
        public int Id { get; set; }                   // Azonosító
        public string ApplicationName { get; set; }   // Alkalmazás neve
        public string Username { get; set; }          // Felhasználónév
        public string Password { get; set; }          // Jelszó
        public byte[] Logo { get; set; }              // Alkalmazás logója (opcionális)
        public DateTime CreatedAt { get; set; }
        public string Identifier { get; set; }

        public PasswordData(int id, string applicationName, string username, string password, byte[] logo, DateTime createdAt, string identifier)
        {
            Id = id;
            ApplicationName = applicationName;
            Username = username;
            Password = password;
            Logo = logo;
            CreatedAt = createdAt;
            Identifier = identifier;
        }
    }
}
