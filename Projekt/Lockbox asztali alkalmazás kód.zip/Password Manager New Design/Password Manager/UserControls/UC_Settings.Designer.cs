﻿namespace Password_Manager.UserControls
{
    partial class UC_Settings
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBackupPath = new System.Windows.Forms.TextBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.toggleTrayicon = new Password_Manager.UserControls.ToggleButton();
            this.toggleNotify = new Password_Manager.UserControls.ToggleButton();
            this.toggleAutoBackup = new Password_Manager.UserControls.ToggleButton();
            this.toggle2FA = new Password_Manager.UserControls.ToggleButton();
            this.toggleAutoLogin = new Password_Manager.UserControls.ToggleButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(59, 106);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(225, 20);
            this.label2.TabIndex = 20;
            this.label2.Text = "Automatikus bejelentkezés";
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(12)))), ((int)(((byte)(22)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(59, 204);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(274, 20);
            this.label1.TabIndex = 21;
            this.label1.Text = "Kétlépcsős azonosítás E-mailben";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(60, 316);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(260, 20);
            this.label3.TabIndex = 24;
            this.label3.Text = "Automatikus biztonsági mentés";
            // 
            // txtBackupPath
            // 
            this.txtBackupPath.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.txtBackupPath.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtBackupPath.ForeColor = System.Drawing.Color.Red;
            this.txtBackupPath.Location = new System.Drawing.Point(63, 258);
            this.txtBackupPath.MaxLength = 25;
            this.txtBackupPath.Name = "txtBackupPath";
            this.txtBackupPath.ReadOnly = true;
            this.txtBackupPath.Size = new System.Drawing.Size(594, 38);
            this.txtBackupPath.TabIndex = 25;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.pictureBox5.Image = global::Password_Manager.Properties.Resources.iconBrowse;
            this.pictureBox5.Location = new System.Drawing.Point(663, 258);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(38, 38);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 26;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Click += new System.EventHandler(this.pictureBox5_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.comboBox1.ForeColor = System.Drawing.Color.White;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "1 Perc",
            "5 Perc",
            "10 Perc",
            "30 Perc",
            "1 Óra",
            "1 Nap",
            "1 Hónap"});
            this.comboBox1.Location = new System.Drawing.Point(429, 366);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 28);
            this.comboBox1.TabIndex = 27;
            this.comboBox1.Visible = false;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(86, 369);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(337, 20);
            this.label4.TabIndex = 28;
            this.label4.Text = "Automatikus mentés ennyi időközönként:";
            this.label4.Visible = false;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(86, 418);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(267, 20);
            this.label5.TabIndex = 30;
            this.label5.Text = "Értesítés a biztonsági mentésről";
            this.label5.Visible = false;
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(59, 155);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(211, 20);
            this.label6.TabIndex = 31;
            this.label6.Text = "Bezáráskor minimalizálás";
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(17)))), ((int)(((byte)(27)))));
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(61, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(218, 16);
            this.label7.TabIndex = 33;
            this.label7.Text = "Biztonsági mentés elérési útja:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(46, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(197, 39);
            this.label8.TabIndex = 34;
            this.label8.Text = "Beállítások";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.panel1.Controls.Add(this.label8);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(768, 66);
            this.panel1.TabIndex = 35;
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(0, 62);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(768, 490);
            this.panel2.TabIndex = 36;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // toggleTrayicon
            // 
            this.toggleTrayicon.AutoSize = true;
            this.toggleTrayicon.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.toggleTrayicon.Location = new System.Drawing.Point(336, 153);
            this.toggleTrayicon.MinimumSize = new System.Drawing.Size(45, 22);
            this.toggleTrayicon.Name = "toggleTrayicon";
            this.toggleTrayicon.OffBackColor = System.Drawing.Color.Crimson;
            this.toggleTrayicon.OffToggleColor = System.Drawing.Color.White;
            this.toggleTrayicon.OnBackColor = System.Drawing.Color.LimeGreen;
            this.toggleTrayicon.OnToggleColor = System.Drawing.Color.White;
            this.toggleTrayicon.Size = new System.Drawing.Size(45, 22);
            this.toggleTrayicon.TabIndex = 32;
            this.toggleTrayicon.UseVisualStyleBackColor = false;
            this.toggleTrayicon.CheckedChanged += new System.EventHandler(this.toggleTrayicon_CheckedChanged);
            // 
            // toggleNotify
            // 
            this.toggleNotify.AutoSize = true;
            this.toggleNotify.Location = new System.Drawing.Point(363, 416);
            this.toggleNotify.MinimumSize = new System.Drawing.Size(45, 22);
            this.toggleNotify.Name = "toggleNotify";
            this.toggleNotify.OffBackColor = System.Drawing.Color.Crimson;
            this.toggleNotify.OffToggleColor = System.Drawing.Color.White;
            this.toggleNotify.OnBackColor = System.Drawing.Color.LimeGreen;
            this.toggleNotify.OnToggleColor = System.Drawing.Color.White;
            this.toggleNotify.Size = new System.Drawing.Size(45, 22);
            this.toggleNotify.TabIndex = 29;
            this.toggleNotify.UseVisualStyleBackColor = true;
            this.toggleNotify.Visible = false;
            this.toggleNotify.CheckedChanged += new System.EventHandler(this.toggleNotify_CheckedChanged);
            // 
            // toggleAutoBackup
            // 
            this.toggleAutoBackup.AutoSize = true;
            this.toggleAutoBackup.Location = new System.Drawing.Point(336, 314);
            this.toggleAutoBackup.MinimumSize = new System.Drawing.Size(45, 22);
            this.toggleAutoBackup.Name = "toggleAutoBackup";
            this.toggleAutoBackup.OffBackColor = System.Drawing.Color.Crimson;
            this.toggleAutoBackup.OffToggleColor = System.Drawing.Color.White;
            this.toggleAutoBackup.OnBackColor = System.Drawing.Color.LimeGreen;
            this.toggleAutoBackup.OnToggleColor = System.Drawing.Color.White;
            this.toggleAutoBackup.Size = new System.Drawing.Size(45, 22);
            this.toggleAutoBackup.TabIndex = 23;
            this.toggleAutoBackup.UseVisualStyleBackColor = true;
            this.toggleAutoBackup.CheckedChanged += new System.EventHandler(this.toggleAutoBackup_CheckedChanged);
            // 
            // toggle2FA
            // 
            this.toggle2FA.AutoSize = true;
            this.toggle2FA.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(16)))), ((int)(((byte)(12)))), ((int)(((byte)(22)))));
            this.toggle2FA.Location = new System.Drawing.Point(336, 202);
            this.toggle2FA.MinimumSize = new System.Drawing.Size(45, 22);
            this.toggle2FA.Name = "toggle2FA";
            this.toggle2FA.OffBackColor = System.Drawing.Color.Crimson;
            this.toggle2FA.OffToggleColor = System.Drawing.Color.White;
            this.toggle2FA.OnBackColor = System.Drawing.Color.LimeGreen;
            this.toggle2FA.OnToggleColor = System.Drawing.Color.White;
            this.toggle2FA.Size = new System.Drawing.Size(45, 22);
            this.toggle2FA.TabIndex = 22;
            this.toggle2FA.UseVisualStyleBackColor = false;
            this.toggle2FA.CheckedChanged += new System.EventHandler(this.toggle2FA_CheckedChanged);
            // 
            // toggleAutoLogin
            // 
            this.toggleAutoLogin.AutoSize = true;
            this.toggleAutoLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(11)))), ((int)(((byte)(7)))), ((int)(((byte)(17)))));
            this.toggleAutoLogin.Location = new System.Drawing.Point(336, 104);
            this.toggleAutoLogin.MinimumSize = new System.Drawing.Size(45, 22);
            this.toggleAutoLogin.Name = "toggleAutoLogin";
            this.toggleAutoLogin.OffBackColor = System.Drawing.Color.Crimson;
            this.toggleAutoLogin.OffToggleColor = System.Drawing.Color.White;
            this.toggleAutoLogin.OnBackColor = System.Drawing.Color.LimeGreen;
            this.toggleAutoLogin.OnToggleColor = System.Drawing.Color.White;
            this.toggleAutoLogin.Size = new System.Drawing.Size(45, 22);
            this.toggleAutoLogin.TabIndex = 0;
            this.toggleAutoLogin.UseVisualStyleBackColor = false;
            this.toggleAutoLogin.CheckedChanged += new System.EventHandler(this.toggleAutoLogin_CheckedChanged);
            // 
            // UC_Settings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.toggleTrayicon);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.toggleNotify);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.txtBackupPath);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.toggleAutoBackup);
            this.Controls.Add(this.toggle2FA);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.toggleAutoLogin);
            this.Controls.Add(this.panel2);
            this.Name = "UC_Settings";
            this.Size = new System.Drawing.Size(768, 561);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ToggleButton toggleAutoLogin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private ToggleButton toggle2FA;
        private ToggleButton toggleAutoBackup;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBackupPath;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label5;
        private ToggleButton toggleNotify;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private ToggleButton toggleTrayicon;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}
