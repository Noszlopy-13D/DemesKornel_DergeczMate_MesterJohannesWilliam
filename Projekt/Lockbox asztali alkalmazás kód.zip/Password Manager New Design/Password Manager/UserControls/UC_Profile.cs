﻿using PasswordManager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace Password_Manager.UserControls
{
    public partial class UC_Profile : UserControl
    {
        private string dbPath = "Data Source=pwdmanager.db";
        private string currentUsername;
        private int currentUserId = LoginForm.currentUserId;

        private bool isPasswordVisible = false;
        public UC_Profile()
        {
            InitializeComponent();
            LoadEmail();
            LoadAndSetUserProfile(currentUserId);

            ChangeEmailForm emailChangeForm = new ChangeEmailForm();
            emailChangeForm.EmailUpdated += ChangeEmailForm_EmailUpdated;

            GlobalEvents.UsernameUpdated += GlobalEvents_UsernameUpdated;
        }
        

        public void LoadAndSetUserProfile(int userId)
        {
            try
            {
                using (var connection = new SQLiteConnection(dbPath))
                {
                    connection.Open();

                    string query = "SELECT username, email, profile_picture FROM user WHERE id = @userId";

                    using (var command = new SQLiteCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userId", userId);

                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                txtUsername.Texts = reader["username"].ToString();
                                txtEmail.Texts = reader["email"].ToString();

                                byte[] profilePictureBytes = reader["profile_picture"] as byte[];

                                if (profilePictureBytes != null && profilePictureBytes.Length > 0)
                                {
                                    using (MemoryStream ms = new MemoryStream(profilePictureBytes))
                                    {
                                        roundPictureBox1.Image = Image.FromStream(ms);
                                    }
                                }
                                else
                                {
                                    roundPictureBox1.Image = Properties.Resources.defaultaccount;
                                }
                            }
                            else
                            {
                                MessageBox.Show("A felhasználó nem található.");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a profil betöltésekor: " + ex.Message);
            }
        }

        private void LoadEmail()
        {
            using (var connection = new SQLiteConnection(dbPath))
            {
                connection.Open();
                string query = "SELECT email FROM user WHERE username = @username";
                using (var command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", currentUsername);
                    var result = command.ExecuteScalar();
                    if (result != null)
                    {
                        txtEmail.Texts = result.ToString();
                    }
                }
            }
        }

        private void btnChangeProfilePicture_Click(object sender, EventArgs e)
        {
            ChangeProfilePictureForm form = new ChangeProfilePictureForm();
            form.ProfilePictureChanged += ChangeProfilePictureForm_ProfilePictureChanged;
            form.ShowDialog();
        }
        private void ChangeProfilePictureForm_ProfilePictureChanged(object sender, EventArgs e)
        {
            LoadAndSetUserProfile(currentUserId);
        }
        private void ChangeEmailForm_EmailUpdated(object sender, EventArgs e)
        {
            LoadAndSetUserProfile(currentUserId);
        }
        private void GlobalEvents_UsernameUpdated(object sender, EventArgs e)
        {
            LoadAndSetUserProfile(currentUserId);
        }

        private void btnChangeEmail_Click(object sender, EventArgs e)
        {
            ChangeEmailForm form = new ChangeEmailForm();
            form.ShowDialog();
        }

        private void btnChangeUsername_Click(object sender, EventArgs e)
        {
            ChangeUsernameForm form = new ChangeUsernameForm();
            form.ShowDialog();
        }

        private void btnChangePassword_Click(object sender, EventArgs e)
        {
            ChangePasswordForm form = new ChangePasswordForm();
            form.ShowDialog();
        }
    }
}
