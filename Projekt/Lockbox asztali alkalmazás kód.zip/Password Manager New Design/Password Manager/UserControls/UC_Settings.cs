﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Manager.UserControls
{
    public partial class UC_Settings : UserControl
    {
        public UC_Settings()
        {
            InitializeComponent();

            UserSettings settings = SettingsManager.LoadSettings();
            toggleAutoLogin.Checked = settings.AutoLoginEnabled;
            toggle2FA.Checked = settings.TwoFactorAuthenticationEnabled;
            toggleAutoBackup.Checked = settings.AutoBackupEnabled;
            txtBackupPath.Text = settings.BackupPath;
            comboBox1.Text = settings.BackupInterval;
            toggleNotify.Checked = settings.BackupNotificationsEnabled;
            toggleTrayicon.Checked = settings.MinimizeToTrayOnClose;
            txtBackupPath.Text = settings.BackupPath;
            SettingsManager.SaveSettings(settings);
        }

        private void toggleAutoLogin_CheckedChanged(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();
            if (toggleAutoLogin.Checked)
            {
                settings.AutoLoginEnabled = true;
            }
            else
            {
                settings.AutoLoginEnabled = false;
            }
            SettingsManager.SaveSettings(settings);
        }

        private void toggle2FA_CheckedChanged(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();
            if (toggle2FA.Checked)
            {
                settings.TwoFactorAuthenticationEnabled = true;
            }
            else
            {
                settings.TwoFactorAuthenticationEnabled = false;
            }
            SettingsManager.SaveSettings(settings);
        }

        private void toggleAutoBackup_CheckedChanged(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();
            if (toggleAutoBackup.Checked)
            {
                settings.AutoBackupEnabled = true;
                comboBox1 .Visible = true;
                label4 .Visible = true;
                label5 .Visible = true;
                toggleNotify.Visible = true;
            }
            else
            {
                settings.AutoBackupEnabled = false;
                settings.BackupInterval = "0";
                comboBox1.Visible = false;
                label4.Visible = false;
                label5 .Visible = false;
                toggleNotify.Visible = false;
                GlobalEvents.OnBackupSettingChanged();
            }
            SettingsManager.SaveSettings(settings);
        }
        private void toggleNotify_CheckedChanged(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();
            if (toggleNotify.Checked)
            {
                settings.BackupNotificationsEnabled = true;
            }
            else
            {
                settings.BackupNotificationsEnabled = false;
            }
            SettingsManager.SaveSettings(settings);
        }
        private void toggleTrayicon_CheckedChanged(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();
            settings.MinimizeToTrayOnClose = toggleTrayicon.Checked;
            SettingsManager.SaveSettings(settings);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();
            settings.BackupInterval = comboBox1.SelectedItem.ToString();
            SettingsManager.SaveSettings(settings);

            UC_Backup uc_backup = new UC_Backup();
            uc_backup.SetBackupTimer();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = "Válaszd ki a biztonsági mentés mappáját";

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    string selectedPath = folderDialog.SelectedPath;

                    UserSettings settings = SettingsManager.LoadSettings();
                    settings.BackupPath = selectedPath;
                    SettingsManager.SaveSettings(settings);

                    txtBackupPath.Text = selectedPath;
                }
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Color startColor = Color.FromArgb(11, 7, 17);
            Color endColor = Color.FromArgb(40, 40, 40);

            using (LinearGradientBrush brush = new LinearGradientBrush(
                panel2.ClientRectangle,
                startColor,
                endColor,
                LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, panel2.ClientRectangle);
            }
        }
    }
}
