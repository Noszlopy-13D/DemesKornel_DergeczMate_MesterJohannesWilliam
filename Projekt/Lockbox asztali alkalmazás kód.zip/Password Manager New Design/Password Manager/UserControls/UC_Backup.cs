﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Manager.UserControls
{
    public partial class UC_Backup : UserControl
    {
        private UserSettings settings;

        private Timer backupTimer;

        public UC_Backup()
        {
            InitializeComponent();
            UserSettings settings = SettingsManager.LoadSettings();
            if(settings.LastBackupDate == DateTime.MinValue)
            {
                lblLastBackupTime.Text = "Nincs mentés";
            }
            else
            {
                lblLastBackupTime.Text = settings.LastBackupDate.ToString();
            }   

            GlobalEvents.BackupSettingChanged += StopBackupTimer;
        }

        private void btnBackup_Click(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();

            string dbPath = "pwdmanager.db"; 

            if(settings.BackupPath != "")
            {
                BackupDatabaseAndKey(dbPath, settings.BackupPath, EncryptionKeyManager.LoadEncryptionKey());
                MessageBox.Show("Biztonsági mentés kész!");
            }
            else
            {
                using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
                {
                    folderDialog.Description = "Válassza ki a biztonsági mentés helyét";

                    if (folderDialog.ShowDialog() == DialogResult.OK)
                    {
                        string backupPath = folderDialog.SelectedPath;

                        string encryptionKey = EncryptionKeyManager.LoadEncryptionKey();

                        if (string.IsNullOrEmpty(encryptionKey))
                        {
                            encryptionKey = EncryptionKeyManager.GenerateEncryptionKey();
                            EncryptionKeyManager.SaveEncryptionKey(encryptionKey, settings.BackupPath);
                            EncryptionKeyManager.SetEnvironmentVariable("ENCRYPTION_KEY", encryptionKey);
                        }

                        BackupDatabaseAndKey(dbPath, backupPath, encryptionKey);
                        MessageBox.Show("Biztonsági mentés kész!");

                        DateTime date = DateTime.Now;
                        settings.LastBackupDate = date;
                        settings.BackupPath = backupPath;
                        lblLastBackupTime.Text = date.ToString();

                        SettingsManager.SaveSettings(settings);
                    }
                }
            } 
        }
        public void BackupDatabaseAndKey(string dbPath, string backupPath, string encryptionKey)
        {

            string keyFilePath = Path.Combine(backupPath, "encryption_key.txt");
            string backupFile = Path.Combine(backupPath, "my_database_backup.db");

            File.Copy(dbPath, backupFile, overwrite: true);
            if (File.Exists(keyFilePath))
            {
                File.SetAttributes(keyFilePath, FileAttributes.Normal);
            }
            File.WriteAllText(keyFilePath, EncryptionKeyManager.LoadEncryptionKey());
            File.SetAttributes(keyFilePath, FileAttributes.Hidden | FileAttributes.ReadOnly);
        }

        private void btnRestoreBackup_Click(object sender, EventArgs e)
        {
            EncryptionKeyManager.ImportDatabaseAndKey();
        }

        private void btnDeleteBackup_Click(object sender, EventArgs e)
        {
            UserSettings settings = SettingsManager.LoadSettings();
            if (string.IsNullOrEmpty(settings.BackupPath))
            {
                MessageBox.Show("Nincs kiválasztott biztonsági mentési hely.");
                return;
            }

            var confirmResult = MessageBox.Show("Biztosan törölni szeretnéd a biztonsági mentés fájljait?",
                                                 "Megerősítés",
                                                 MessageBoxButtons.YesNo);
            if (confirmResult == DialogResult.Yes)
            {
                try
                {
                    if (Directory.Exists(settings.BackupPath))
                    {
                        // Az eltávolítandó fájlok nevei vagy mintái
                        string[] backupFiles = { "my_database_backup.db", "encryption_key.txt" };

                        // Törlés a megadott mappában
                        foreach (var fileName in backupFiles)
                        {
                            string filePath = Path.Combine(settings.BackupPath, fileName);
                            if (File.Exists(filePath))
                            {
                                File.SetAttributes(filePath, FileAttributes.Normal);
                                File.Delete(filePath);
                            }
                        }

                        MessageBox.Show("A biztonsági mentés fájljai sikeresen törölve.");

                    }
                    else
                    {
                        MessageBox.Show("A kiválasztott biztonsági mentési hely nem található.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Hiba történt a biztonsági mentés fájljainak törlésekor: {ex.Message}");
                }
            }
        }

        public void SetBackupTimer()
        {
            if (backupTimer != null)
            {
                backupTimer.Stop();
                backupTimer.Dispose();
            }

            UserSettings settings = SettingsManager.LoadSettings();
            int intervalMinutes = GetIntervalInMinutes(settings.BackupInterval);
            if (intervalMinutes > 0)
            {
                backupTimer = new Timer();
                backupTimer.Interval = intervalMinutes * 60 * 1000;
                backupTimer.Tick += new EventHandler(BackupTimer_Tick);
                backupTimer.Start();
            }
        }
        private void StopBackupTimer(object sender, EventArgs e)
        {
            backupTimer?.Stop();
            backupTimer?.Dispose();
        }
        private void BackupTimer_Tick(object sender, EventArgs e)
        {
            PerformAutomaticBackup(); 
        }

        private int GetIntervalInMinutes(string intervalText)
        {
            switch (intervalText)
            {
                case "1 Perc": return 1;
                case "5 Perc": return 5;
                case "10 Perc": return 10;
                case "30 Perc": return 30;
                case "1 Óra": return 60;
                case "1 Nap": return 1440;
                case "1 hónap": return 43200;
                default: return 0; 
            }
        }

        private void PerformAutomaticBackup()
        {
            UserSettings settings = SettingsManager.LoadSettings();
            DateTime currentTime = DateTime.Now;
            TimeSpan timeSinceLastBackup = currentTime - settings.LastBackupDate;
            if(settings.BackupPath != "")
            {
                if(Directory.Exists(settings.BackupPath))
                {
                    if(GetIntervalInMinutes(settings.BackupInterval) != 0)
                    {
                        PerformBackup();
                        settings.LastBackupDate = DateTime.Now;
                        lblLastBackupTime.Text = DateTime.Now.ToString();
                        SettingsManager.SaveSettings(settings);
                        GlobalEvents.OnBackupSuccessful();
                        SetBackupTimer();
                    }
                }
                else
                {
                    GlobalEvents.OnBackupFailed();
                }
            }
        }
        public void PerformBackup()
        {
            UserSettings settings = SettingsManager.LoadSettings();
            string backupPath = settings.BackupPath;

            if (Directory.Exists(backupPath))
            {
                string dbPath = "pwdmanager.db";
                string keyFilePath = Path.Combine(backupPath, "encryption_key.txt");
                string backupFile = Path.Combine(backupPath, "my_database_backup.db");

                File.Copy(dbPath, backupFile, overwrite: true);
                if (File.Exists(keyFilePath))
                {
                    File.SetAttributes(keyFilePath, FileAttributes.Normal);
                }
                File.WriteAllText(keyFilePath, EncryptionKeyManager.LoadEncryptionKey());
                File.SetAttributes(keyFilePath, FileAttributes.Hidden | FileAttributes.ReadOnly);
                
                settings.LastBackupDate = DateTime.Now; 
                SettingsManager.SaveSettings(settings);
            }
            else
            {
                MessageBox.Show("A mentési elérési út nem található. Kérlek, válassz ki egy érvényes helyet.");
            }
        }
        public void CheckBackupOnStartup()
        {
            UserSettings settings = SettingsManager.LoadSettings();
            DateTime lastBackupTime = settings.LastBackupDate;
            DateTime currentTime = DateTime.Now;
            if (settings.AutoBackupEnabled)
            {
                if ((currentTime - lastBackupTime).TotalMinutes >= GetIntervalInMinutes(settings.BackupInterval))
                {
                    PerformAutomaticBackup();
                }
            }
            SetBackupTimer();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            Color startColor = Color.FromArgb(11, 7, 17);
            Color endColor = Color.FromArgb(40, 40, 40);

            using (LinearGradientBrush brush = new LinearGradientBrush(
                panel2.ClientRectangle,
                startColor,
                endColor,
                LinearGradientMode.Vertical))
            {
                e.Graphics.FillRectangle(brush, panel2.ClientRectangle);
            }
        }
    }
}
