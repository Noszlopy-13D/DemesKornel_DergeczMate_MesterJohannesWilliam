﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Password_Manager
{
    class EncryptionKeyManager
    {
        public static void EnsureEncryptionKeyExists()
        {
            // Ellenőrizzük, hogy létezik-e már a környezetváltozóban a kulcs
            string encryptionKey = LoadEncryptionKey();

            if (string.IsNullOrEmpty(encryptionKey))
            {
                DialogResult result = MessageBox.Show("Nem található titkosítási kulcs. Szeretne importálni egy adatbázist és egy titkosítási kulcsot?",
                                                "Importálás",
                                                MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {
                    ImportDatabaseAndKey();
                }
                else
                {
                    encryptionKey = GenerateEncryptionKey();

                    SetEnvironmentVariable("ENCRYPTION_KEY", encryptionKey);

                    MessageBox.Show("Új titkosítási kulcs generálva és tárolva a környezetváltozók között.");
                }
            }
            else
            {
                //MessageBox.Show("A titkosítási kulcs már létezik.");
            }
        }

        public static string GenerateEncryptionKey()
        {
            using (var rngCryptoServiceProvider = new RNGCryptoServiceProvider())
            {
                byte[] keyBytes = new byte[32];
                rngCryptoServiceProvider.GetBytes(keyBytes);
                return Convert.ToBase64String(keyBytes);
            }
        }
        public static void ImportDatabaseAndKey()
        {
            using (FolderBrowserDialog folderDialog = new FolderBrowserDialog())
            {
                folderDialog.Description = "Válassza ki a biztonsági mentési mappát";

                if (folderDialog.ShowDialog() == DialogResult.OK)
                {
                    string backupPath = folderDialog.SelectedPath;
                    string dbBackupFilePath = Path.Combine(backupPath, "my_database_backup.db");
                    string keyFilePath = Path.Combine(backupPath, "encryption_key.txt");

                    if (File.Exists(dbBackupFilePath) && File.Exists(keyFilePath))
                    {
                        try
                        {
                            string originalDbPath = "pwdmanager.db";

                            string encryptionKey = File.ReadAllText(keyFilePath);

                            File.Copy(dbBackupFilePath, originalDbPath, overwrite: true);

                            EncryptionKeyManager.SetEnvironmentVariable("ENCRYPTION_KEY", encryptionKey);

                            MessageBox.Show("Biztonsági mentés sikeresen visszaállítva!");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Hiba történt a visszaállítás során: {ex.Message}");
                        }
                    }
                    else
                    {
                        MessageBox.Show("A kiválasztott mappában nem találhatók a szükséges fájlok.");
                    }
                }
            }
        }
        public static string LoadEncryptionKey()
        {
            return Environment.GetEnvironmentVariable("ENCRYPTION_KEY", EnvironmentVariableTarget.User);
        }

        public static void SaveEncryptionKey(string encryptionKey, string backupPath)
        {
            string keyFilePath = Path.Combine(backupPath, "encryption_key.txt");

            try
            {
                File.WriteAllText(keyFilePath, encryptionKey);

                File.SetAttributes(keyFilePath, FileAttributes.Hidden | FileAttributes.ReadOnly);

                MessageBox.Show("Biztonsági kulcs sikeresen elmentve.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hiba történt a biztonsági kulcs mentésekor: " + ex.Message);
            }
        }

        public static void SetEnvironmentVariable(string key, string value)
        {
            Environment.SetEnvironmentVariable(key, value, EnvironmentVariableTarget.User);
        }
    }
}
