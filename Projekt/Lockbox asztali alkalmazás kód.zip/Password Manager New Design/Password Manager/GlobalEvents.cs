﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Password_Manager
{
    public static class GlobalEvents
    {
        public static event EventHandler ProfilePictureUpdated;
        public static event EventHandler UsernameUpdated;
        public static event EventHandler BackupSuccessful;
        public static event EventHandler BackupFailed;
        public static event EventHandler BackupSettingChanged;

        public static void OnUsernameUpdated()
        {
            UsernameUpdated?.Invoke(null, EventArgs.Empty);
        }
        public static void OnProfilePictureUpdated()
        {
            ProfilePictureUpdated?.Invoke(null, EventArgs.Empty);
        }
        public static void OnBackupSuccessful()
        {
            BackupSuccessful?.Invoke(null, EventArgs.Empty);
        }
        public static void OnBackupFailed()
        {
            BackupFailed?.Invoke(null, EventArgs.Empty);
        }
        public static void OnBackupSettingChanged() 
        {
            BackupSettingChanged?.Invoke(null, EventArgs.Empty);
        }
    }
}
