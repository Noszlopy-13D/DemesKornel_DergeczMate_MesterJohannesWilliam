<?php

require __DIR__ . '/composer/vendor/autoload.php';

use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$host_env = $_ENV['DB_HOST'];
$dbname_env = $_ENV['DB_NAME'];
$username_env = $_ENV['DB_USERNAME'];
$password_env = $_ENV['DB_PASSWORD'];


$host = $host_env;
$dbname = $dbname_env;
$username = $username_env;
$password = $password_env;

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Adatbázis kapcsolódási hiba: " . $e->getMessage());
}
?>