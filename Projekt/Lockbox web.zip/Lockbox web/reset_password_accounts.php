<?php
session_start();
require 'db.php';

$token = $_GET['token'];

// Ellenőrizzük az email és token párost
$stmt = $pdo->prepare("SELECT * FROM password_resets WHERE token = ? AND expiry > NOW()");
$stmt->execute([$token]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$result) {
    die("Érvénytelen vagy lejárt kérés.");
}

$email = $result['email'];

// Adott e-mailhez tartozó fiókok lekérése
$stmt = $pdo->prepare("SELECT id, username FROM user WHERE email = ?");
$stmt->execute([$email]);
$accounts = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Ha nincs fiók az e-mail címhez
if (empty($accounts)) {
    die("Nincs regisztrált fiók ezzel az e-mail címmel.");
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <script type="text/javascript" src="script/script.js" defer></script>
    <title>LockBox</title>
    <style>
        body{
            width: 100%;
            height: 100%;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            text-align: center;
            justify-content: center;
            align-items: center;
        }
        .accounts-container{
            width: 50%;
            margin: 0px auto;
            border: 1px solid white;
            border-radius: 5px;
            padding: 10px;
            text-align: center;
            justify-content: center;
            margin-bottom: 30px;
            cursor: pointer;
            transition: all .3s ;
        }
        .accounts-container:hover{
            transform: scale(1.1);
        }
        .button{
            width: 200px;
            margin-top: 10px;
            background-color: transparent;
            border: 1px solid white;
            border-radius: 5px;
            color: white;
            transition: all .3s;
            padding: 20px 0;
        }
        .button:hover{
            background-color: white;
            color: black;
        }
    </style>
</head>
<body>
    <main>
        <p style="margin-bottom: 20px">Válaszd ki a fiókot, amelynek a jelszavát módosítani szeretnéd:</p>
        <form action="process_reset.php" method="POST">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
            <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
            <div>
                <?php foreach ($accounts as $account): ?>
                        <div class="accounts-container" onclick="selectAccount('<?php echo $account['id']; ?>')">
                                <input type="text" name="account_id" value="<?php echo $account['id']; ?>" hidden>
                                <?php echo htmlspecialchars($account['username']); ?>
                        </div>
                <?php endforeach; ?>
            </div>
        </form>
        <script>
            function selectAccount(accountId) {
                // Beállítja a kiválasztott fiók azonosítóját az űrlaphoz
                const form = document.querySelector("form");
                const accountInput = document.createElement("input");
                accountInput.type = "hidden";
                accountInput.name = "account_id";
                accountInput.value = accountId;

                // Hozzáadjuk az új inputot az űrlaphoz
                form.appendChild(accountInput);

                // Küldjük az űrlapot
                form.submit();
            }
        </script>
    </main>
</body>
</html>