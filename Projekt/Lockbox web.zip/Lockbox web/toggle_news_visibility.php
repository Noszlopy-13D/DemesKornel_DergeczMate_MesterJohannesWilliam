<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "admin") {
    header('Location: login.php');
    exit;
}

// Ha nincs megfelelő adat küldve, kilépünk
if (!isset($_POST['id']) || !isset($_POST['is_visible'])) {
    http_response_code(400);
    echo "Hiányzó adatok!";
    exit;
}

$news_id = intval($_POST['id']);
$is_visible = intval($_POST['is_visible']); // 0 vagy 1

// Frissítés az adatbázisban
$stmt = $pdo->prepare("UPDATE news SET is_visible = ? WHERE id = ?");
$success = $stmt->execute([$is_visible, $news_id]);

if ($success) {
    echo "Sikeres módosítás!";
} else {
    http_response_code(500);
    echo "Hiba történt az adatbázis frissítése közben!";
}
?>
