<?php
require 'db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    try {
        $stmt = $pdo->prepare("SELECT logo FROM applications WHERE id = ?");
        $stmt->execute([$id]);
        $application = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($application) {
            header("Content-Type: image/png");
            echo $application['logo'];
        } else {
            http_response_code(404);
            echo "Logó nem található.";
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo "Hiba történt: " . $e->getMessage();
    }
} else {
    http_response_code(400);
    echo "Hiányzó ID paraméter.";
}
?>

header("HTTP/1.0 404 Not Found");
?>