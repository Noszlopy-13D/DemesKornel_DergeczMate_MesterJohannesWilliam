<?php
require 'db.php';

require 'composer/vendor/autoload.php';
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$email_host_env = $_ENV['EMAIL_HOST'];
$email_username_env = $_ENV['EMAIL_USERNAME'];
$email_password_env = $_ENV['EMAIL_PASSWORD'];

$current_time = date('Y-m-d H:i:s');

// Töröljük a lejárt tokeneket
$stmt = $pdo->prepare("DELETE FROM password_resets WHERE expiry < ?");
$stmt->execute([$current_time]);

$mail = new PHPMailer(true);

// Ellenőrizzük, hogy a kérelem POST módszerrel érkezett
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    // Ellenőrizzük, hogy az e-mail létezik az adatbázisban
    $stmt = $pdo->prepare("SELECT id FROM user WHERE email = ?");
    $stmt->execute([$email]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    

    if ($result) {
        try {
            // Token generálása
            $token = bin2hex(random_bytes(32));
            date_default_timezone_set("Europe/Budapest");
            $expiry = date('Y-m-d H:i:s', strtotime('+15 minutes'));
            $user_id = $result['id'];

            $stmt = $pdo->prepare("INSERT INTO password_resets (user_id, token, expiry, email) VALUES (?, ?, ?, ?)");
            $stmt->execute([$user_id, $token, $expiry, $email]);

            $reset_link = "http://lockbox.hu/reset_password_accounts.php?token=$token";

            // Szerver beállítások
            $mail->isSMTP();
            $mail->Host = $email_host_env; 
            $mail->SMTPAuth = true;
            $mail->Username = $email_username_env; 
            $mail->Password = $email_password_env; 
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->CharSet = 'UTF-8';
        
            // Címzettek
            $mail->setFrom($email_username_env, 'LockBox');
            $mail->addAddress($email); // Címzett email címe 
        
            // Tartalom
            $mail->isHTML(true);
            $mail->Subject = 'Jelszó helyreállítás';
            $mail->Body = "
            
                <p>Kattints az alábbi gombra a jelszó visszaállításához: </p>

                <a href=\"$reset_link\" style=\"
                    display: inline-block;
                    padding: 10px 20px;
                    font-size: 16px;
                    font-weight: bold;
                    color: #ffffff;
                    background-color: #007bff;
                    text-decoration: none;
                    border-radius: 5px;
                    text-align: center;
                    margin-top: 10px;
                    margin-bottom: 10px;
                \">Jelszó visszaállítása</a>

                <p>A link 15 percig érvényes.</p>
               
               ";
        
            $mail->send();
            $msg = "Az e-mail sikeresen elküldve!";
            header("Location: forgot_password.php?msg=" . urlencode($msg));
            exit();
        } catch (Exception $e) {
            $error = "Hiba történt az e-mail küldésekor!";
            header("Location: forgot_password.php?error=" . urlencode($error));
        }
    } else {
        $error = "Az e-mail cím nem található!";
        header("Location: forgot_password.php?error=" . urlencode($error));
    }
    //header("Location: reset_password_accounts.php?token=$token");
}
?>
