<?php
session_start();
require 'db.php';

if (isset($_POST['id']) && isset($_POST['title']) && isset($_POST['content'])) {
    $id = $_POST['id'];
    $title = $_POST['title'];
    $content = $_POST['content'];
    $visible = isset($_POST['visible']) ? 1 : 0;

    // Frissítés SQL lekérdezés
    $stmt = $pdo->prepare("UPDATE news SET title = ?, content = ?, is_visible = ? WHERE id = ?");
    $stmt->execute([$title, $content, $visible, $id]);

    header("Location: admin_news.php");
    exit();
} else {
    echo "Hiba történt a frissítés során!";
}
?>