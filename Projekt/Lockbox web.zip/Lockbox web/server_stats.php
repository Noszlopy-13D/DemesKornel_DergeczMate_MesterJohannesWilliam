<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "admin") {
    header('Location: login.php');
    exit;
}

$cpu_load = sys_getloadavg()[0] * 10; // Szimulált CPU érték
$memory_usage = memory_get_usage(true) / 1024 / 1024; // MB

header('Content-Type: application/json');

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo json_encode([
    'cpu' => round($cpu_load, 2),
    'ram' => round($memory_usage, 2)
]);