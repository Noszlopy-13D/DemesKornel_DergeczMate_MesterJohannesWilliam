<?php
session_start();
require 'db.php';

require 'composer/vendor/autoload.php';
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$email_host_env = $_ENV['EMAIL_HOST'];
$email_username_env = $_ENV['EMAIL_USERNAME'];
$email_password_env = $_ENV['EMAIL_PASSWORD'];

$mail = new PHPMailer(true);

if (isset($_POST['username']) && 
    isset($_POST['password'])) {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $pdo->prepare("SELECT * FROM user WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // 2FA ellenőrzés
            if ($user['two_factor_enabled'] == 1) {
                $email = $user['email'];
        
                // Kód generálás
                $two_factor_code = rand(100000, 999999);
                $_SESSION['verification_code'] = $two_factor_code;
                $_SESSION['code_time'] = time();
                $_SESSION['email'] = $email;
                $_SESSION['username'] = $username;

                // E-mail küldés
                try {
                    $mail->isSMTP();
                    $mail->Host = $email_host_env; 
                    $mail->SMTPAuth = true;
                    $mail->Username = $email_username_env; 
                    $mail->Password = $email_password_env; 
                    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                    $mail->Port = 587;

                    $mail->CharSet = 'UTF-8';
                
                    // Címzettek
                    $mail->setFrom($email_username_env, 'LockBox');
                    $mail->addAddress($email); // Címzett email címe 
                
                    // Tartalom
                    $mail->isHTML(true);
                    $mail->Subject = 'Bejelentkezés megerősítése';
                    $mail->Body    = 'A bejelentkezést a következő kóddal tudod megerősíteni: ' . $two_factor_code;
                
                    $mail->send();
                    echo 'E-mail elküldve!';
                } catch (Exception $e) {
                    echo "Hiba történt az e-mail küldésekor: {$mail->ErrorInfo}";
                }

                // Átirányítás a 2FA kód megadásához
                header("Location: verify_2fa.php");
                exit;
            }
            else{
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];
                $ip_address = $_SERVER['REMOTE_ADDR']; 

                $ch = curl_init("http://ipinfo.io/{$ip_address}/json");
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $response = curl_exec($ch);
                curl_close($ch);
                
                $geo_data = json_decode($response, true);
                if (isset($geo_data['city']) && isset($geo_data['country'])) {
                    $location = $geo_data['city'] . ", " . $geo_data['country'];
                } else {
                    $location = "Ismeretlen";
                }
                
                if (isset($geo_data['city']) && isset($geo_data['country'])) {
                    $location = $geo_data['city'] . ", " . $geo_data['country'];
                } else {
                    $location = "Ismeretlen";
                }

                // Aktív felhasználó mentése az adatbázisba
                $stmt = $pdo->prepare("INSERT INTO active_users (user_id, username, ip_address, location) 
                VALUES (?, ?, ?, ?)");
                $stmt->execute([$user['id'], $user['username'], $ip_address, $location]);

                $stmt = $pdo->prepare("DELETE FROM failed_logins WHERE ip_address = ?");
                $stmt->execute([$ip_address]);

                $stmt = $pdo->prepare("DELETE FROM failed_logins WHERE attempt_time < NOW() - INTERVAL 1 DAY");
                $stmt->execute();

                $stmt = $pdo->prepare("DELETE FROM active_users WHERE last_seen < NOW() - INTERVAL 1 DAY");
                $stmt->execute();

                $stmt = $pdo->prepare("UPDATE user SET last_login = NOW() WHERE id = ?");
                $stmt->execute([$user['id']]);

                if ($user['role'] == 'admin') {
                    header('Location: admin_dashboard.php');
                    exit;
                } else {
                    header('Location: dashboard.php');
                    exit;
                }
            }
        } 
        else {
            $em = 'Hibás felhasználónév vagy jelszó!';

            $ip_address = $_SERVER['REMOTE_ADDR']; 
            $stmt = $pdo->prepare("INSERT INTO failed_logins (ip_address) VALUES (?)");
            $stmt->execute([$ip_address]);

            header("Location: ../login.php?view=login&l_error=$em"); 
            exit;
        }
    }

} else {
    header("Location: ../login.php");
    exit();
}
?>