<!DOCTYPE html>
<html lang="hu">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>LockBox</title>
        <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css"  rel="stylesheet" />
        <link rel="stylesheet" href="css/index_styles.css">
        <link rel="stylesheet" href="css/navbar_styles.css">
        <style>
            body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            font-size: 18px;
            color: #333;
            color: white;
            height: 100%;
            display: flex;
            flex-direction: column;
            box-sizing: border-box;
            }
            h1{
                text-align: center;
                font-size: 2rem;
                margin-bottom: 30px;
                font-weight: bold;
            }
            h2{
                font-size: 24px;
            }
            p, ul{
                margin-bottom: 20px;
            }
            p a {
                color: #0056b3;
                text-decoration: none;
            }
            a:hover {
                text-decoration: underline;
            }
            .section {
                margin: 60px;
                margin-bottom: 40px;
                flex: 1;
            }
        </style>
    </head>
    <body>
        <nav class="navigation">
            <div class="menu-container">
                <div class="logo">LockBox</div>
                <button class="toggle-button" onclick="toggleMenu()">☰</button>
                <ul class="menu">
                    <li><a href="index.php">Főoldal</a></li>
                    <li><a href="download.php">Letöltés</a></li>
                    <li><a href="contact.php">Kapcsolat</a></li>
                    <li><a href="login.php">Bejelentkezés</a></li>
                </ul>
            </div>
            <ul class="menu mobile" id="mobileMenu">
                <li><a href="index.php">Főoldal</a></li>
                <li><a href="download.php">Letöltés</a></li>
                <li><a href="contact.php">Kapcsolat</a></li>
                <li><a href="login.php">Bejelentkezés</a></li>
            </ul>
        </nav>
        <script>
            function toggleMenu() {
                const mobileMenu = document.getElementById('mobileMenu');
                
                // Mobil nézetben engedélyezzük az animációkat
                if (window.innerWidth <= 700) {
                    if (mobileMenu.classList.contains('show')) {
                        // Ha már meg van nyitva, akkor elrejthetjük
                        mobileMenu.classList.remove('show');
                        mobileMenu.classList.add('hide');
                        setTimeout(function() {
                            mobileMenu.style.display = 'none'; // Eltüntetjük végleg, miután az animáció befejeződött
                        }, 300); // Az animáció ideje
                    } else {
                        // Ha nincs nyitva, akkor megjelenítjük
                        mobileMenu.style.display = 'flex'; // Először jelenjen meg
                        setTimeout(function() {
                            mobileMenu.classList.remove('hide');
                            mobileMenu.classList.add('show'); // Animáció indítása
                        }, 10); // Kis késleltetés, hogy az animáció észlelhető legyen
                    }
                }
            }
            window.addEventListener('resize', function() {
                const mobileMenu = document.getElementById('mobileMenu');
                if (window.innerWidth > 700) {
                    mobileMenu.style.display = 'none';
                }
            });
            document.addEventListener("DOMContentLoaded", function() {
                const mobileMenu = document.getElementById('mobileMenu');
                mobileMenu.style.display = 'none';
            });
        </script>   
    <div class="section">
        <h1>Általános Szerződési Feltételek (ÁSZF)</h1>

        <h2 class="mb-2 text-lg font-semibold text-gray-50">1. Bevezető rendelkezések</h2>
        <p>A Lockbox weboldal és asztali alkalmazás egy iskolai projekt, amely kísérleti jellegű jelszókezelő
             szolgáltatást nyújt. A Szolgáltatás célja oktatási és demonstrációs célok elérése, nem pedig 
             professzionális, kereskedelmi vagy hivatásos használat. Az oldalon történő bármilyen tevékenység 
             kizárólag a Felhasználó saját felelősségére történik.</p>

        <h2 class="mb-2 text-lg font-semibold text-gray-50">2. A szolgáltatás használata</h2>
        <p>A LockBox lehetőséget nyújt jelszavak tárolására és kezelésére, azonban nem garantáljuk az adatok
             teljes körű biztonságát. A felhasználók kötelesek saját adataik védelméről gondoskodni,
              például erős jelszó használatával.</p>

        <h2 class="mb-2 text-lg font-semibold text-gray-50">3. Felhasználói felelősség</h2>
        <p>Mivel a LockBox egy iskolai projekt, a szolgáltatás használatából eredő bármilyen kárért a fejlesztő
             nem vállal felelősséget. A rendszer fejlesztése során mindent megtettünk a biztonság érdekében,
              azonban nem garantálható a hibamentes működés.</p>

        <h2 class="mb-2 text-lg font-semibold text-gray-50">4. Felhasználói kötelezettségek</h2>
        <ul class="space-y-1 text-gray-50 list-disc list-inside">
            <li>A felhasználók kötelesek helyes és valós adatokat megadni a regisztráció során.</li>
            <li>A szolgáltatást nem szabad jogsértő célokra használni.</li>
        </ul>

        <h2 class="mb-2 text-lg font-semibold text-gray-50">5. A szolgáltatás megszüntetése</h2>
        <p>A fejlesztő fenntartja a jogot, hogy a LockBox weboldalt és asztali alkalmazást bármikor megszüntesse,
            előzetes értesítés nélkül.</p>

        <h2 class="mb-2 text-lg font-semibold text-gray-50">6. Egyéb rendelkezések</h2>
        <p>Ezek az Általános Szerződési Feltételek kizárólag a LockBox iskolai projektre vonatkoznak,
            és nem minősülnek kereskedelmi szolgáltatási feltételeknek.</p>

        <h2 class="mb-2 text-lg font-semibold text-gray-50">7. Jogszabályi megfelelés</h2>
        <p>A weboldal és az asztali alkalmazás tartalma a Szolgáltató szellemi tulajdonát képezi.
             A Felhasználó nem jogosult a weboldal és az asztali alkalmazás forráskódjának vagy
              tartalmának bármely módon történőreprodukálására, terjesztésére vagy felhasználására.</p>

        <h2 class="mb-2 text-lg font-semibold text-gray-50">8. Szerzői jogok</h2>
        <p>A Szolgáltatás Magyarország hatályos jogszabályainak megfelelése mellett működik. 
            Az oldalon történő bármilyen tevékenységre kizárólag a magyar jog az irányadó.</p>    
             
        <h2 class="mb-2 text-lg font-semibold text-gray-50">9. Záró rendelkezések</h2>
        <ul class="space-y-1 text-gray-50 list-disc list-inside">
            <li>A jelen ÁSZF bármikor módosítható a Szolgáltató által.
                 A módosítások a weboldalon történő közzétételkor lépnek hatályba.</li>
            <li>A Szolgáltatás használatával a Felhasználó elfogadja a jelen ÁSZF-ben foglalt feltételeket.</li>
        </ul>

        <h2 class="mb-2 text-lg font-semibold text-gray-50">10. Kapcsolat</h2>
        <p>Kérdés esetén forduljon hozzánk a <a href="contact.php">kapcsolat</a> oldalunkon.</p>
    </div>

        <!-- Lábléc -->
        <footer class="bg-black rounded-lg shadow dark:bg-gray-900 m-4">
            <div class="w-full max-w-screen-xl mx-auto p-4 md:py-8">
                <div class="sm:flex sm:items-center sm:justify-between">
                    <a href="index.php" class="flex items-center mb-4 sm:mb-0 space-x-3 rtl:space-x-reverse">
                        <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">LockBox</span>
                    </a>
                    <ul class="flex flex-wrap items-center mb-6 text-sm font-medium text-gray-500 sm:mb-0 dark:text-gray-400">
                        <li>
                            <a href="about_us.php" class="hover:underline me-4 md:me-6">Rólunk</a>
                        </li>
                        <li>
                            <a href="contact.php" class="hover:underline me-4 md:me-6">Kapcsolat</a>
                        </li>
                        <li>
                            <a href="privacy_policy.php" class="hover:underline me-4 md:me-6">Adatvédelmi szabályzat</a>
                        </li>
                        <li>
                        <a href="aszf.php" style="font-weight: bold;" class="hover:underline me-4 md:me-6">ÁSZF</a>
                        </li>
                    </ul>
                </div>
                <hr class="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
                <span class="block text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2025 LockBox™ Minden jog fenntartva.</span>
            </div>
        </footer>
    </body>
</html>