<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

if (!isset($_GET['id'])) {
    header('Location: dashboard.php');
    exit;
}

$id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// Ellenőrizzük, hogy a felhasználó valóban hozzáférhet-e a kívánt jelszóhoz
$stmt = $pdo->prepare("SELECT * FROM saved_passwords WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user_id]);
$password_data = $stmt->fetch();

if (!$password_data) {
    header('Location: dashboard.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $app_name = $_POST['app_name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $logo_identifier = $_POST['logo_identifier']; // Ezt felhasználhatjuk logó azonosításhoz, ha szükséges

    $stmt = $pdo->prepare("UPDATE saved_passwords SET app_name = ?, username = ?, password = ?, logo_identifier = ? WHERE id = ?");
    $stmt->execute([$app_name, $username, $password, $logo_identifier, $id]);

    header('Location: dashboard.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/styles.css">
    <title>Jelszó Szerkesztése</title>
</head>
<body>
    <div class="edit-password-container">
        <h1>Jelszó Szerkesztése</h1>
        <form method="POST">
            <input type="text" name="app_name" placeholder="Alkalmazás neve" value="<?= htmlspecialchars($password_data['app_name']) ?>" required>
            <input type="text" name="username" placeholder="Felhasználónév" value="<?= htmlspecialchars($password_data['username']) ?>" required>
            <input type="password" name="password" placeholder="Jelszó" value="<?= htmlspecialchars($password_data['password']) ?>" required>
            <input type="text" name="logo_identifier" placeholder="Logó azonosító" value="<?= htmlspecialchars($password_data['logo_identifier']) ?>">
            <button type="submit">Frissítés</button>
        </form>
        <p><a href="dashboard.php">Vissza a főoldalra</a></p>
    </div>
</body>
</html>