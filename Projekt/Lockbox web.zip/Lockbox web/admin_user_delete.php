<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

if (!isset($_GET['id'])) {
    die("Nincs megadva felhasználó azonosító.");
}

$userId = $_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM user WHERE id = ?");
$stmt->execute([$appId]);
$user = $stmt->fetch();

if (!$user) {
    die("Az felhasználó nem található.");
}

$deleteStmt = $pdo->prepare("DELETE FROM user WHERE id = ?");
$deleteStmt->execute([$userId]);

header("Location: admin_user.php");
exit;
?>