<?php
require 'db.php';

// Adatok a POST-ból
$account_id = $_POST['account_id'];
$password = password_hash($_POST['password'], PASSWORD_BCRYPT);

// Jelszó frissítése
$stmt = $pdo->prepare("UPDATE user SET password = ? WHERE id = ?");
$stmt->execute([$password, $account_id]);

// Token törlése
$stmt = $pdo->prepare("DELETE FROM password_resets WHERE email = ?");
$stmt->execute([$_POST['email']]);

header('Location: login.php');
?>
