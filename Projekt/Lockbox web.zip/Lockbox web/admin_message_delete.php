<?php
session_start();
require 'db.php';

// Csak adminisztrátorok férhetnek hozzá
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: login.php');
    exit;
}

// Az alkalmazás id-je az URL-ből
if (!isset($_GET['id'])) {
    die("Nincs megadva üzenet azonosító.");
}

$msgId = $_GET['id'];

// Ellenőrizzük, hogy létezik-e az alkalmazás
$stmt = $pdo->prepare("SELECT * FROM contact WHERE id = ?");
$stmt->execute([$msgId]);
$msg = $stmt->fetch();

if (!$msg) {
    die("Az alkalmazás nem található.");
}

// Törlés az adatbázisból
$deleteStmt = $pdo->prepare("DELETE FROM contact WHERE id = ?");
$deleteStmt->execute([$msgId]);

// Visszairányítás az admin oldalra
header("Location: admin_message.php");
exit;
?>