<?php
session_start();
require 'db.php'; // Adatbázis kapcsolat

// Ellenőrizzük, hogy a felhasználó be van-e jelentkezve
if (!isset($_SESSION['user_id'])) {
    die("Nincs jogosultság.");
}

// Felhasználó azonosító
$user_id = $_SESSION['user_id'];

// Lekérdezzük a profilképet

    try {
        $stmt = $pdo->prepare("SELECT profile_picture FROM user WHERE id = ?");
        $stmt->execute([$user_id]);
        $user_pp = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user_pp) {
            header("Content-Type: image/png");
            echo $user_pp['profile_picture'];
        } else {
            echo "icons/default_profile_picture.png";
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo "Hiba történt: " . $e->getMessage();
    }
?>
