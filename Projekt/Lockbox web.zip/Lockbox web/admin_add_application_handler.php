<?php
session_start();
require 'db.php';

// Csak adminisztrátorok férhetnek hozzá
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit;
}

if (isset($_FILES['app_logo']) && $_FILES['app_logo']['error'] == 0) {
    $fileInfo = getimagesize($_FILES['app_logo']['tmp_name']);
    if ($fileInfo === false) {
        die("A fájl nem érvényes kép.");
    }

    // Fájlméret ellenőrzése (pl. maximum 2 MB)
    if ($_FILES['app_logo']['size'] > 2 * 1024 * 1024) {
        die("A kép túl nagy (maximum 2 MB lehet).");
    }

    // Csak PNG vagy JPEG típus engedélyezése
    if (!in_array($fileInfo['mime'], ['image/png', 'image/jpeg'])) {
        die("Csak PNG vagy JPEG típusú képek engedélyezettek.");
    }

    $logo = file_get_contents($_FILES['app_logo']['tmp_name']);
    $name = $_POST['app_name'];
    // Mentés az adatbázisba
    $stmt = $pdo->prepare("INSERT INTO applications (name, logo) VALUES (?, ?)");
    $stmt->execute([$name, $logo]);

    header('Location: admin_add_application.php');
} else {
        $error = "Hiba történt a fájl feltöltése közben.";
    }
?>