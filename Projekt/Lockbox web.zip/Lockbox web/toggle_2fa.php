<?php
require 'db.php';
session_start();

$user_id = $_SESSION['user_id'];

// A POST adatok beolvasása
$data = json_decode(file_get_contents('php://input'), true);
$enable_2fa = isset($data['enable']) ? $data['enable'] : false;

if ($user_id !== null) {
    // 2FA állapot frissítése az adatbázisban
    $stmt = $pdo->prepare("UPDATE user SET two_factor_enabled = ? WHERE id = ?");
    $stmt->execute([$enable_2fa, $user_id]);

    // Visszajelzés JSON formátumban
    echo json_encode([
        'success' => true,
        'message' => $enable_2fa ? '2FA engedélyezve.' : '2FA letiltva.'
    ]);
} else {
    // Hiba, ha nincs bejelentkezve a felhasználó
    echo json_encode([
        'success' => false,
        'message' => 'Nincs bejelentkezve.'
    ]);
}
?>
