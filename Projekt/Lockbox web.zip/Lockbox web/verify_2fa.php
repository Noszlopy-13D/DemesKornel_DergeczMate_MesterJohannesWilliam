<?php
session_start();
require 'db.php';

if (!isset($_SESSION['verification_code'])) {
    echo "Nincs aktív kód vagy email cím módosítás.";
    exit();
}

$email = $_SESSION['email'];
$username = $_SESSION['username'];

$stmt = $pdo->prepare("SELECT * FROM user WHERE username = ?");
$stmt->execute([$username]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input_code = $_POST['verification_code'];

    $codeCreationTime = $_SESSION['code_time'];

    $expirationTime = 10 * 60;
    // Kód lejáratának ellenőrzése (10 perc)
    if (time() - $codeCreationTime > $expirationTime) {
        echo "<p style='color:red;'>A kód lejárt. Kérj egy újat!</p>";
        // Kód érvénytelenítése és session törlés
        unset($_SESSION['verification_code']);
        unset($_SESSION['code_time']);
    } else {
        // Kód érvényesítés
        if ($input_code == $_SESSION['verification_code']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            $ip_address = $_SERVER['REMOTE_ADDR']; 

            $ch = curl_init("http://ipinfo.io/{$ip_address}/json");
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            curl_close($ch);
            
            $geo_data = json_decode($response, true);
            if (isset($geo_data['city']) && isset($geo_data['country'])) {
                $location = $geo_data['city'] . ", " . $geo_data['country'];
            } else {
                $location = "Ismeretlen";
            }
            
            if (isset($geo_data['city']) && isset($geo_data['country'])) {
                $location = $geo_data['city'] . ", " . $geo_data['country'];
            } else {
                $location = "Ismeretlen";
            }

            // Aktív felhasználó mentése az adatbázisba
            $stmt = $pdo->prepare("INSERT INTO active_users (user_id, username, ip_address, location) 
            VALUES (?, ?, ?, ?)");
            $stmt->execute([$user['id'], $user['username'], $ip_address, $location]);

            $stmt = $pdo->prepare("DELETE FROM failed_logins WHERE ip_address = ?");
            $stmt->execute([$ip_address]);

            $stmt = $pdo->prepare("DELETE FROM failed_logins WHERE attempt_time < NOW() - INTERVAL 1 DAY");
            $stmt->execute();

            $stmt = $pdo->prepare("DELETE FROM active_users WHERE last_seen < NOW() - INTERVAL 1 DAY");
            $stmt->execute();

            $stmt = $pdo->prepare("UPDATE user SET last_login = NOW() WHERE id = ?");
            $stmt->execute([$user['id']]);

            unset($_SESSION['verification_code']);
            unset($_SESSION['code_time']);
            unset($_SESSION['code_time']);

            if ($user['role'] == 'admin') {
                header('Location: admin_dashboard.php');
                exit;
            } else {
                header('Location: dashboard.php');
                exit;
            }
        } else {
            echo "<p style='color:red'>Hibás kód. Kérlek próbáld újra.<p>";
        }
    }
}

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <title>LockBox</title>
    <style>
        body{
            width: 100%;
            height: 100%;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            text-align: center;
            justify-content: center;
            align-items: center;
        }
        .button{
            background-color: transparent;
            border: 1px solid white;
            color: white;
            transition: all .3s;
            cursor: pointer;
        }
        .button:hover{
            background-color: white;
            color: black;
        }
        #back-button{
            display: inline-flex; 
            align-items: center;
            color: white;
            font-weight: bold;
            text-decoration: none;
        }
        #back-button:hover{
            text-decoration: underline;
        }
        #countdown {
            font-size: 20px;
            font-weight: bold;
            color: red;
        }
    </style>
</head>
<body>
  <main>
    <p style="margin-bottom: 50px">A megerősítő kódot elküldtük a(z) <b><?php echo $email?></b> E-mail címre!</p>
    <div style="margin-bottom: 50px">
        <p>A kód érvényessége: <span id="countdown"></span></p>
    </div>
    <form method="POST">
        <label for="verification_code">Megerősítő kód:</label>
        <input type="text" name="verification_code" required>
        <input class="button" type="submit" value="Megerősítés">
    </form>

    <form method="POST" action="2fa_resend_code.php">
        <input class="button" type="submit" value="Új kód kérése">
    </form>
    <div>
        <p><a href="login.php" id="back-button"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#FFFFFF"><path d="M560-240 320-480l240-240 56 56-184 184 184 184-56 56Z"/></svg>Vissza a bejelentkezéshez</a></p>
    </div>
  </main>
  <script>
        // A kód létrehozásának időpontja a PHP session-ből
        var codeCreationTime = <?php echo $_SESSION['code_time']; ?>;
        var expirationTime = 10 * 60;

        // Számoljuk ki, mikor jár le a kód
        var expirationTimestamp = codeCreationTime + expirationTime;

        // Visszaszámláló funkció
        function updateCountdown() {
            var currentTime = Math.floor(Date.now() / 1000); 
            var remainingTime = expirationTimestamp - currentTime;

            if (remainingTime <= 0) {
                document.getElementById('countdown').innerHTML = "A kód lejárt!";
                clearInterval(countdownInterval);
            } else {
                var minutes = Math.floor(remainingTime / 60);
                var seconds = remainingTime % 60;
                document.getElementById('countdown').innerHTML = minutes + " perc " + seconds + " másodperc";
            }
        }

        // Indítjuk a visszaszámlálót
        var countdownInterval = setInterval(updateCountdown, 1000);

    </script>
</body>
</html>