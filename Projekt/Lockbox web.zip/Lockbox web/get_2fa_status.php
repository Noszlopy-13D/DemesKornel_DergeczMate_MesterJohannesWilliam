<?php
header('Content-Type: application/json');
require 'db.php';
session_start();

$user_id = $_SESSION['user_id'];

if ($user_id !== null) {
    // A 2FA állapot lekérése az adatbázisból
    $stmt = $pdo->prepare("SELECT two_factor_enabled FROM user WHERE id = ?");
    $stmt->execute([$user_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result) {
        echo json_encode(['enabled' => (bool) $result['two_factor_enabled']]);
    } else {
        echo json_encode(['enabled' => false]);
    }
} else {
    // Ha nincs bejelentkezve a felhasználó, adjunk vissza hibát
    echo json_encode(['enabled' => false, 'error' => 'Nincs bejelentkezve']);
}
?>
