<?php
session_start();
require 'db.php';

require 'composer/vendor/autoload.php';
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$email_host_env = $_ENV['EMAIL_HOST'];
$email_username_env = $_ENV['EMAIL_USERNAME'];
$email_password_env = $_ENV['EMAIL_PASSWORD'];

$mail = new PHPMailer(true);

$user_id = $_SESSION['user_id'];

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$stmt = $pdo->prepare("SELECT email FROM user WHERE id = ?");
$stmt->execute([$user_id]);
$stmt_old_email = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $old_email = $stmt_old_email['email'];
    $new_email = $_SESSION['new_email'];

    // E-mail formátum ellenőrzés
    if (!filter_var($new_email, FILTER_VALIDATE_EMAIL)) {
        echo "Érvénytelen e-mail cím.";
    } else {
        // Új email cím mentése ideiglenesen
        $_SESSION['new_email'] = $new_email;

        // Kód generálás és email küldés
        $verification_code = rand(100000, 999999);
        $_SESSION['verification_code'] = $verification_code;
        $_SESSION['code_time'] = time();

        // E-mail küldés
        try {
            // Szerver beállítások
            $mail->isSMTP();
            $mail->Host = $email_host_env; 
            $mail->SMTPAuth = true;
            $mail->Username = $email_username_env; 
            $mail->Password = $email_password_env; 
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->CharSet = 'UTF-8';
        
            // Címzettek
            $mail->setFrom($email_username_env, 'LockBox');
            $mail->addAddress($old_email); // Címzett email címe (a felhasználó régi emailje)
        
            // Tartalom
            $mail->isHTML(true);
            $mail->Subject = 'Email változtatás megerősítése';
            $mail->Body    = 'A kérésedet a következő kóddal tudod megerősíteni: ' . $verification_code;
        
            $mail->send();
            echo 'E-mail elküldve!';
        } catch (Exception $e) {
            echo "Hiba történt az e-mail küldésekor: {$mail->ErrorInfo}";
        }

        // Átirányítás a kód megerősítésére
        header('Location: verify_email.php');
        exit();
    }
}
?>