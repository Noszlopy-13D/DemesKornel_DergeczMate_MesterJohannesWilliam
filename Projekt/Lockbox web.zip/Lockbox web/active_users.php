<?php
session_start();

require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "admin") {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->query("SELECT DISTINCT user_id, username, ip_address, location FROM active_users");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$table_rows = "";

if (count($rows) > 0) {
    foreach ($rows as $row) {
        $table_rows .= "<tr>
                            <td>" . htmlspecialchars($row['user_id']) . "</td>
                            <td>" . htmlspecialchars($row['username']) . "</td>
                            <td>" . htmlspecialchars($row['ip_address']) . "</td>
                            <td>" . htmlspecialchars($row['location']) . "</td>
                        </tr>";
    }
} else {
    $table_rows = "<tr><td colspan='4'>Nincsenek aktív felhasználók.</td></tr>";
}

echo $table_rows;
?>