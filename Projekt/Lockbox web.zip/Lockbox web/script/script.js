if (!navigator.clipboard) {
    alert("A vágólap másolás nem támogatott ezen a böngészőn.");
}


function togglePassword(id) {
    const passwordField = document.getElementById('password_' + id);
    if (passwordField.type === 'password') {
        passwordField.type = 'text';
    } else {
        passwordField.type = 'password';
    }
}

function copyToClipboard(id, field) {
    const fieldElement = document.getElementById(`${field}_${id}`); 
    if (fieldElement) {
        const text = fieldElement.value;

        navigator.clipboard.writeText(text).then(() => {
            const copyButton = document.querySelector(`button[onclick="copyToClipboard(${id}, '${field}')"]`);
            if (copyButton) {
                copyButton.disabled = true;
                const originalContent = copyButton.innerHTML;
                copyButton.innerHTML = `
                    <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#75FB4C">
                        <path d="M382-240 154-468l57-57 171 171 367-367 57 57-424 424Z"/>
                    </svg>`;
                fieldElement.classList.add('copied');
                
                setTimeout(() => {
                    copyButton.innerHTML = originalContent;                
                    copyButton.disabled = false;
                    fieldElement.classList.remove('copied');
                }, 1000);
            }
        }).catch(err => {
            console.error('Sikertelen másolás: ', err);
            alert('Nem sikerült másolni a vágólapra.');
        });
    }
}

function handleFieldClick(id, field) {
    if (window.innerWidth < 800) {
        copyToClipboard(id, field);
        const fieldElement = document.getElementById(field + '_' + id);
        fieldElement.classList.add('copied');

        // Animáció eltávolítása
        setTimeout(() => {
            fieldElement.classList.remove('copied');
        }, 1000);
    }
}

window.addEventListener('resize', () => {
    console.log('Képernyőméret megváltozott:', window.innerWidth);
});
