function searchPasswords() {
  const searchQuery = document.getElementById("searchBox").value;
  const sortOption = document.getElementById("sortOptions").value;

  // Ellenőrizzük, hogy a keresési és rendezési értékek léteznek-e
  console.log("Search Query: ", searchQuery);
  console.log("Sort Option: ", sortOption);

  // AJAX kérés indítása a keresési és rendezési paraméterekkel
  const xhr = new XMLHttpRequest();
  const url = "passwords.php?search=" + encodeURIComponent(searchQuery) + "&sort=" + encodeURIComponent(sortOption);
  
  console.log("Request URL: ", url); // Ellenőrizzük, hogy az URL helyes-e

  xhr.open("GET", url, true);
  xhr.onload = function() {
      if (xhr.status === 200) {
          console.log("AJAX Response: ", xhr.responseText); // Válasz naplózása

          // Az AJAX válasz HTML tartalmának elemzése
          const responseHTML = xhr.responseText;
          
          // Kiválasztjuk a kártyák részét a válaszból
          const parser = new DOMParser();
          const doc = parser.parseFromString(responseHTML, 'text/html');
          const cards = doc.querySelector('.cards'); // A kártyák a .cards div-ben vannak

          if (cards) {
              // Csak a kártyák kerülnek a cardsContainer-be
              const cardsContainer = document.getElementById('cardsContainer');
              cardsContainer.innerHTML = cards.innerHTML;
          } else {
              console.log("No cards found in the response.");
          }
      } else {
          console.log("Request failed with status: " + xhr.status);
      }
  };
  xhr.send();
}

// Eseménykezelők beállítása
window.onload = function() {
  searchPasswords(); // Amikor az oldal betöltődik, frissítsük a kártyákat
};

