        const modal = document.getElementById('deleteModal');
        const cancelButton = document.getElementById('cancelButton');
        const confirmButton = document.getElementById('confirmButton');
        let deleteAppId = null;

        const currentPage = window.location.pathname; 

        // Törlés gombra kattintáskor a modal megjelenítése animációval
        if (currentPage.includes('passwords.php')) {
            // Ha a felhasználó a passwords.php-n van
            document.body.addEventListener('click', function(event) {
                if (event.target.classList.contains('btn-delete')) {
                    deleteAppId = event.target.getAttribute('data-id');
                    modal.style.display = 'flex'; // Modal megjelenítése
                    setTimeout(() => {
                        modal.classList.add('show'); // Animáció indítása
                    }, 10);
                }
            });
        } else {
            document.querySelectorAll('.btn-delete').forEach(button => {
                button.addEventListener('click', () => {
                    deleteAppId = button.getAttribute('data-id');
                    modal.style.display = 'flex'; // Modal megjelenítése
                    setTimeout(() => {
                        modal.classList.add('show'); // Animáció indítása
                    }, 10); // Rövid késleltetés az animáció aktiválásához
                });
            });
        }

        // Mégse gombra kattintáskor a modal elrejtése
        cancelButton.addEventListener('click', () => {
            modal.classList.remove('show'); // Animáció visszavonása
            setTimeout(() => {
                modal.style.display = 'none'; // Modal elrejtése
                deleteAppId = null;
            }, 300); // Várakozás az animáció lefutására
        });

        // Modal bezárása, ha a modal háttérre kattintunk
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('show'); // Animáció visszavonása
                setTimeout(() => {
                    modal.style.display = 'none'; // Modal elrejtése
                    deleteAppId = null;
                }, 300); // Várakozás az animáció lefutására
            }
        });