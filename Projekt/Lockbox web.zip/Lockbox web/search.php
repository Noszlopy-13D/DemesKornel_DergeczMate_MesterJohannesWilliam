<?php
require 'db.php'; // Az adatbázis kapcsolatot biztosító fájl

// Ellenőrizzük, hogy van-e keresési kifejezés
$searchQuery = isset($_GET['query']) ? trim($_GET['query']) : '';

// Adatok lekérése az adatbázisból
$stmt = $pdo->prepare("
    SELECT * 
    FROM saved_passwords 
    WHERE app_name LIKE :search OR username LIKE :search
");
$stmt->execute(['search' => '%' . $searchQuery . '%']);
$results = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Eredmények visszaadása JSON formátumban
header('Content-Type: application/json');
echo json_encode($results);