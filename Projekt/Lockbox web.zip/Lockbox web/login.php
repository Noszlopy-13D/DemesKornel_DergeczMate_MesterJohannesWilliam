<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (isset($_POST['login'])) {
        require 'login_handler.php'; 

    } elseif (isset($_POST['register'])) {
        require 'registration.php'; 
    }

    $view = isset($_GET['view']) ? $_GET['view'] : 'login';
}
if (!isset($_SESSION["user_id"]) && 
    !isset($_SESSION["user_username"])){
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/navbar_styles.css">
    <link rel="stylesheet" href="css/login_styles.css">
    <script type="text/javascript" src="script/login.js" defer></script>
    <title>LockBox</title>
</head>
<body>
<nav class="navigation">
        <div class="menu-container">
            <div class="logo">LockBox</div>
            <button class="toggle-button" onclick="toggleMenu()">☰</button>
            <ul class="menu">
                <li><a href="index.php">Főoldal</a></li>
                <li><a href="download.php">Letöltés</a></li>
                <li><a href="contact.php">Kapcsolat</a></li>
                <li><a href="login.php">Bejelentkezés</a></li>
            </ul>
        </div>
        <ul class="menu mobile" id="mobileMenu">
            <li><a href="index.php">Főoldal</a></li>
            <li><a href="download.php">Letöltés</a></li>
            <li><a href="contact.php">Kapcsolat</a></li>
            <li><a href="login.php">Bejelentkezés</a></li>
        </ul>
    </nav>
    <script>
        function toggleMenu() {
            const mobileMenu = document.getElementById('mobileMenu');
            
            if (window.innerWidth <= 700) {
                if (mobileMenu.classList.contains('show')) {
                    mobileMenu.classList.remove('show');
                    mobileMenu.classList.add('hide');
                    setTimeout(function() {
                        mobileMenu.style.display = 'none'; 
                    }, 300); 
                } else {
                    mobileMenu.style.display = 'flex'; 
                    setTimeout(function() {
                        mobileMenu.classList.remove('hide');
                        mobileMenu.classList.add('show'); 
                    }, 10);
                }
            }
        }
        window.addEventListener('resize', function() {
            const mobileMenu = document.getElementById('mobileMenu');
            if (window.innerWidth > 700) {
                mobileMenu.style.display = 'none';
            }
        });
        document.addEventListener("DOMContentLoaded", function() {
            const mobileMenu = document.getElementById('mobileMenu');
            mobileMenu.style.display = 'none';
        });
    </script>
<main>
    <div class="centered-container">
        <div class="wrapper">
            <div class="form-box login">
                <h2>Bejelentkezés</h2>
                <form action="login_handler.php" method="POST">
                    <div class="input-box">
                        <span class="icon"><ion-icon name="username"></ion-icon></span>
                        <input type="text" name="username" id="username" autocomplete="username" required>
                        <label for="username">Felhasználónév</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                        <input type="password" name="password" id="password" required>
                        <span class="toggle-password" onclick="togglePassword()"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#fff"><path d="M480-320q75 0 127.5-52.5T660-500q0-75-52.5-127.5T480-680q-75 0-127.5 52.5T300-500q0 75 52.5 127.5T480-320Zm0-72q-45 0-76.5-31.5T372-500q0-45 31.5-76.5T480-608q45 0 76.5 31.5T588-500q0 45-31.5 76.5T480-392Zm0 192q-146 0-266-81.5T40-500q54-137 174-218.5T480-800q146 0 266 81.5T920-500q-54 137-174 218.5T480-200Zm0-300Zm0 220q113 0 207.5-59.5T832-500q-50-101-144.5-160.5T480-720q-113 0-207.5 59.5T128-500q50 101 144.5 160.5T480-280Z"/></svg></span>
                        <label for="password">Jelszó</label>
                    </div>
                    <div class="remember-forgot">
                        <a href="forgot_password.php">Elfelejtetted a jelszavad?</a>
                    </div>
                    <button type="submit" class="btn">Bejelentkezés</button>
                    <div class="login-register">
                        <p>Nincs még fiókod? <a href="#" class="register-link">Regisztráció</a></p>
                    </div>
                    <?php if (isset($_GET["l_error"])) { ?>
                        <div class="alert alert-danger error" role="alert">
                            <?=htmlspecialchars($_GET["l_error"]); ?>
                        </div>
                    <?php } ?>
                </form>
            </div>

            <div class="form-box register">
                <h2>Regisztráció</h2>
                <form action="register.php" method="POST">
                    <div class="input-box">
                        <span class="icon"><ion-icon name="person"></ion-icon></span>
                        <input type="text" name="username" id="reg_username" autocomplete="username" required >
                        <label for="reg_username">Felhasználónév</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><ion-icon name="mail"></ion-icon></span>
                        <input type="email" name="email" id="email" autocomplete="email" required style="color:white">
                        <label for="email" id="email-label">Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                        <input type="password" name="password" id="reg-password" required>
                        <span class="register-toggle-password" onclick="registerTogglePassword()"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#fff"><path d="M480-320q75 0 127.5-52.5T660-500q0-75-52.5-127.5T480-680q-75 0-127.5 52.5T300-500q0 75 52.5 127.5T480-320Zm0-72q-45 0-76.5-31.5T372-500q0-45 31.5-76.5T480-608q45 0 76.5 31.5T588-500q0 45-31.5 76.5T480-392Zm0 192q-146 0-266-81.5T40-500q54-137 174-218.5T480-800q146 0 266 81.5T920-500q-54 137-174 218.5T480-200Zm0-300Zm0 220q113 0 207.5-59.5T832-500q-50-101-144.5-160.5T480-720q-113 0-207.5 59.5T128-500q50 101 144.5 160.5T480-280Z"/></svg></span>
                        <label for="reg-password">Jelszó</label>
                    </div>
                    <div class="remember-forgot">
                        <label><input type="checkbox" name="aszf" required>Elfogadom az <a href="aszf.php"><b>általános szerződési </span>feltételek<b></a>et.</label>
                    </div>
                    <button type="submit" class="btn">Regisztráció</button>
                    <div class="login-register">
                        <p>Van már fiókod? <a href="#" class="login-link">Bejelentkezés</a></p>
                    </div>
                    <?php if (isset($_GET["r_error"])) { ?>
                        <div class="alert alert-danger error" role="alert">
                            <?=htmlspecialchars($_GET["r_error"]); ?>
                        </div>
                    <?php } ?>
                </form>
            </div>
        </div>
    </div>
    <script>
        document.getElementById('email').addEventListener('input', function() {
        this.style.color = 'white';
    });
    </script>
    </main>
</body>
</html>

<?php }else{
    if($_SESSION['role'] == "admin"){
        header("Location: admin_dashboard.php");
        exit();
    }
    else{
        header("Location: dashboard.php");
        exit();
    }
} ?>