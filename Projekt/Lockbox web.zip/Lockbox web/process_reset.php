<?php
session_start();
require 'db.php';

$email = $_POST['email'];
$token = $_POST['token'];
$account_id = $_POST['account_id'];

// Ellenőrzés (biztonság kedvéért újra)
$stmt = $pdo->prepare("SELECT * FROM password_resets WHERE email = ? AND token = ? AND expiry > NOW()");
$stmt->execute([$email, $token]);
$result = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$result) {
    die("Érvénytelen vagy lejárt token.");
}

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <script type="text/javascript" src="script/app.js" defer></script>
    <script type="text/javascript" src="script/script.js" defer></script>
    <title>LockBox</title>
    <style>
        body{
            width: 100%;
            height: 100%;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            text-align: center;
            justify-content: center;
            align-items: center;
        }
        .button{
            width: 200px;
            margin-top: 10px;
            background-color: transparent;
            border: 1px solid white;
            border-radius: 5px;
            color: white;
            transition: all .3s;
            padding: 20px 0;
        }
        .button:hover{
            background-color: white;
            color: black;
        }
    </style>
</head>
<body>
    <main>
        <p style="margin-bottom: 20px">Adj meg egy új jelszót!</p>
        <form action="final_reset.php" method="POST" onsubmit="return validatePasswords()">
            <input type="hidden" name="account_id" value="<?php echo htmlspecialchars($account_id); ?>">
            <input type="hidden" name="email" value="<?php echo htmlspecialchars($email); ?>">
            <input type="password" name="password" id="password" placeholder="Új jelszó" required>
            <input type="password" name="password2" id="password2" placeholder="Új jelszó mégegyszer" required>
            <button type="submit" class="button">Jelszó módosítása</button>

            <div id="error-message" style="color: red; font-size: 14px; display: none;"></div>
        </form>

        <script>
            function validatePasswords() {
                const password = document.getElementById('password').value;
                const password2 = document.getElementById('password2').value;
                const errorMessage = document.getElementById('error-message');

                if (password !== password2) {
                    errorMessage.textContent = "A két jelszó nem egyezik meg!";
                    errorMessage.style.display = "block";
                    return false; // Megakadályozza az űrlap elküldését
                } else {
                    errorMessage.style.display = "none"; // Elrejti a hibát, ha megegyeznek
                    return true; // Engedélyezi az űrlap elküldését
                }
            }
        </script>
    </main>
</body>
</html>