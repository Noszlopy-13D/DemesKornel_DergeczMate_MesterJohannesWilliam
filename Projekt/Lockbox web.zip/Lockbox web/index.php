<!DOCTYPE html>
<html lang="hu">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Válassza a LockBox jelszókezelőt, hogy biztonságosan tárolja jelszavait. Ingyenes és könnyen használható.">
        <meta name="keywords" content="jelszókezelő, biztonságos jelszótárolás, ingyenes jelszókezelő, titkosítás">
        <meta property="og:title" content="Lockbox - Ingyenes Jelszókezelő">
        <meta property="og:description" content="Válassza a LockBox jelszókezelőt, hogy biztonságosan tárolja jelszavait. Ingyenes és könnyen használható.">
        <meta property="og:image" content="https://lockbox.hu/icons/lockbox_logo.png">
        <meta property="og:url" content="https://lockbox.hu">
        <title>LockBox - Ingyenes jelszókezelő</title>
        <link rel="canonical" href="https://lockbox.hu/">
        <link rel="icon" type="image/x-icon" href="favicon.ico">
        <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="css/index_styles.css">
        <link rel="stylesheet" href="css/navbar_styles.css">
        <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
    </head>
    <body>
    <nav class="navigation" aria-label="Breadcrumb">
        <div class="menu-container">
            <div class="logo">LockBox</div>
            <button class="toggle-button" onclick="toggleMenu()">☰</button>
            <ul class="menu">
                <li><a href="index.php">Főoldal</a></li>
                <li><a href="download.php">Letöltés</a></li>
                <li><a href="contact.php">Kapcsolat</a></li>
                <li><a href="login.php">Bejelentkezés</a></li>
            </ul>
        </div>
        <ul class="menu mobile" id="mobileMenu">
            <li><a href="index.php">Főoldal</a></li>
            <li><a href="download.php">Letöltés</a></li>
            <li><a href="contact.php">Kapcsolat</a></li>
            <li><a href="login.php">Bejelentkezés</a></li>
        </ul>
    </nav>
    <script>
        function toggleMenu() {
            const mobileMenu = document.getElementById('mobileMenu');
            
            if (window.innerWidth <= 700) {
                if (mobileMenu.classList.contains('show')) {

                    mobileMenu.classList.remove('show');
                    mobileMenu.classList.add('hide');
                    setTimeout(function() {
                        mobileMenu.style.display = 'none'; 
                    }, 300); 
                } else {
                    
                    mobileMenu.style.display = 'flex'; 
                    setTimeout(function() {
                        mobileMenu.classList.remove('hide');
                        mobileMenu.classList.add('show'); 
                    }, 10); 
                }
            }
        }
        window.addEventListener('resize', function() {
            const mobileMenu = document.getElementById('mobileMenu');
            if (window.innerWidth > 700) {
                mobileMenu.style.display = 'none';
            }
        });
        document.addEventListener("DOMContentLoaded", function() {
            const mobileMenu = document.getElementById('mobileMenu');
            mobileMenu.style.display = 'none';
        });
    </script>



        <!-- Hero szekció -->
        <div class="hero-section">
            <section>
                <div class="fadeInDown  py-8 px-4 mx-auto max-w-screen-xl text-center lg:py-16">
                    <h1 class="mb-4 text-4xl font-extrabold tracking-tight leading-none text-gray-50 md:text-5xl lg:text-6xl">LockBox Jelszókezelő</h1>
                    <p class="mb-8 text-lg font-normal text-gray-400 lg:text-xl sm:px-16 lg:px-48 ">
                        Ingyenes, biztonságos, könnyen kezelhető és minden jelszavad egy helyen!<br>
                        Tárold és kezeld jelszavaidat egyszerűen – próbáld ki a LockBoxot még ma!
                    </p>
                    <div class="flex flex-col space-y-4 sm:flex-row sm:justify-center sm:space-y-0 download-button">
                        <a href="download.php" class="inline-flex justify-center items-center py-3 px-5 text-base font-medium text-center text-white rounded-lg bg-red-700 hover:bg-red-800 focus:ring-2 focus:ring-red-300 ">
                            Letöltés
                            <svg class="w-3.5 h-3.5 ms-2 rtl:rotate-180" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9"/>
                            </svg>
                        </a>  
                    </div>
                </div>
            </section>
        </div>

        <!-- Funkciók szekció -->
        <div class="features">
            <div class="feature-item">
                <h2>Könnyű használhatóság</h2>
                <p>Egyszerű és intuitív felhasználói felület</p>
            </div>
        <div class="feature-item">
                <h2>Kapcsolat</h2>

                <p>Kérdésed van? Ne habozz kapcsolatba lépni velünk!</p>
        </div>
        
            <div class="feature-item">
                <h2>Könnyű testreszabhatóság</h2>
                <p>Teljes rugalmasság a személyes beállításokhoz.</p>
            </div>
        </div>

        <!-- Lábléc -->

        <footer class="bg-black rounded-lg shadow dark:bg-gray-900 m-4">
    <div class="w-full max-w-screen-xl mx-auto p-4 md:py-8">
        <div class="sm:flex sm:items-center sm:justify-between">
            <a href="index.php" class="flex items-center mb-4 sm:mb-0 space-x-3 rtl:space-x-reverse">
                <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">LockBox</span>
            </a>
            <ul class="flex flex-wrap items-center mb-6 text-sm font-medium text-gray-500 sm:mb-0 dark:text-gray-400">
                <li>
                    <a href="about_us.php" class="hover:underline me-4 md:me-6">Rólunk</a>
                </li>
                <li>
                    <a href="contact.php" class="hover:underline me-4 md:me-6">Kapcsolat</a>
                </li>
                <li>
                    <a href="privacy_policy.php" class="hover:underline me-4 md:me-6">Adatvédelmi szabályzat</a>
                </li>
                <li>
                <a href="aszf.php" class="hover:underline me-4 md:me-6">ÁSZF</a>
                </li>
            </ul>
        </div>
        <hr class="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
        <span class="block text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2025 LockBox™ Minden jog fenntartva.</span>
    </div>
</footer>
    </body>
</html>