<?php
session_start();
require 'db.php';

// Ellenőrizzük, hogy a felhasználó be van-e jelentkezve
if (!isset($_SESSION['user_id'])) {
    die("Hozzáférés megtagadva. Jelentkezz be először.");
}

// Feltöltés feldolgozása
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['profile_picture']['tmp_name'];
        $fileSize = $_FILES['profile_picture']['size'];
        $fileType = mime_content_type($fileTmpPath);

        // Ellenőrizzük, hogy a fájl képtípus-e
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        if (!in_array($fileType, $allowedTypes)) {
            die("Csak JPEG, PNG vagy GIF fájlok engedélyezettek.");
        }

        // Ellenőrizzük a fájl méretét (max. 2 MB)
        $maxFileSize = 2 * 1024 * 1024; // 2 MB
        if ($fileSize > $maxFileSize) {
            die("A fájl mérete túl nagy. Maximum 2 MB lehet.");
        }

        // A fájl tartalmának beolvasása
        $fileContent = file_get_contents($fileTmpPath);

        // Adatbázis frissítése
        try {
            $stmt = $pdo->prepare("UPDATE user SET profile_picture = :profile_picture WHERE id = :id");
            $stmt->bindParam(':profile_picture', $fileContent, PDO::PARAM_LOB);
            $stmt->bindParam(':id', $_SESSION['user_id'], PDO::PARAM_INT);

            if ($stmt->execute()) {

            } else {
                echo "Hiba történt a profilkép frissítése során.";
            }
        } catch (PDOException $e) {
            die("Adatbázis hiba: " . $e->getMessage());
        }
    } else {
        echo "Hiba történt a fájl feltöltése során.";
    }
    header('Location: profile.php');
}
?>