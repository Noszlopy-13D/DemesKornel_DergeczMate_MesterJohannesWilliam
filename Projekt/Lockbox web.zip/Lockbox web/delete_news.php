<?php
session_start();
require 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Törlés SQL lekérdezés
    $stmt = $pdo->prepare("DELETE FROM news WHERE id = ?");
    $stmt->execute([$id]);

    header("Location: admin_news.php");
    exit();
} else {
    echo "Hiba történt a törlés során!";
}
?>
