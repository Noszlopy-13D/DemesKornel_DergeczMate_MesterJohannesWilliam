<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT username, password FROM user WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Csak POST kérés esetén működjön
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = !empty($_POST['username']) ? $_POST['username'] : $user['username'];

    if (!empty($_POST['current_password']) && !empty($_POST['new_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];

        // Ellenőrizzük, hogy a jelenlegi jelszó helyes-e
        if (password_verify($current_password, $user['password'])) {
            // Hasheljük az új jelszót
            $password = password_hash($new_password, PASSWORD_BCRYPT);
        } else {
            echo "Helytelen jelenlegi jelszó!";
            exit;
        }
    } else {
        $password = $user['password'];
    }

    // Adatok frissítése az adatbázisban
    $update_stmt = $pdo->prepare("UPDATE user SET username = ?, password = ? WHERE id = ?");
    $update_stmt->execute([$username, $password, $user_id]);
}

header('Location: profile.php');


?>