<!DOCTYPE html>

<html lang="hu">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>LockBox</title>

    <style>

        body{

            background-color: #11121a;

            width: 100%;

            height: 100%;

            overflow: hidden;

            box-sizing: border-box;

            font-family: Arial, Helvetica, sans-serif;

        }

        div{

            width: 100%;

            margin: 0 auto;

            text-align: center;

        }

        h1{

            font-size: 52px;

            color: white;

            margin-bottom: 50px;

        }

        .container {

            max-width: 500px;

            padding: 20px;

            border-radius: 10px;

        }

        p {

            font-size: 1.2rem;

            opacity: 0.8;

            color: white;

        }

        .loader {

            margin: 20px auto;

            width: 50px;

            height: 50px;

            border: 5px solid rgba(255, 255, 255, 0.3);

            border-radius: 50%;

            border-top-color: #fff;

            animation: spin 1s linear infinite;

        }

        @keyframes spin {

            from { transform: rotate(0deg); }

            to { transform: rotate(360deg); }

        }

    </style>

</head>

<body>

<div class="container">

        <h1>LockBox karbantartás alatt</h1>

        <div class="loader"></div>

        <p>Kérjük látogass vissza később.</p>

    </div>

</body>

</html>