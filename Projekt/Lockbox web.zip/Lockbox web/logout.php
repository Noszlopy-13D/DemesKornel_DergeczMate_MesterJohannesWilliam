<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}
$stmt = $pdo->prepare("DELETE FROM active_users WHERE user_id = ?");
$stmt->execute([$_SESSION['user_id']]);


session_unset();
session_destroy();
header('Location: login.php');
exit;
?>