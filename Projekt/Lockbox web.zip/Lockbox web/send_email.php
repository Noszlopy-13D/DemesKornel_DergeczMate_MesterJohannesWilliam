<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "admin") {
    header('Location: login.php');
    exit;
}

require 'composer/vendor/autoload.php';
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$email_host_env = $_ENV['EMAIL_HOST'];
$email_username_env = $_ENV['EMAIL_USERNAME'];
$email_password_env = $_ENV['EMAIL_PASSWORD'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $recipient = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // PHPMailer konfiguráció
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = $email_host_env; // Cseréld a saját SMTP szerveredre
        $mail->SMTPAuth   = true;
        $mail->Username   = $email_username_env; // Saját e-mail cím
        $mail->Password   = $email_password_env; // Saját jelszó
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->CharSet = 'UTF-8';
        $send_subject = mb_encode_mimeheader($subject, "UTF-8", "B", "\r\n");

        $mail->setFrom($email_username_env, 'Lockbox');
        $mail->addAddress($recipient);

        $mail->isHTML(true);
        $mail->Subject = $send_subject;
        $mail->Body    = nl2br(htmlspecialchars($message));

        if ($mail->send()) {
            $stmt = $pdo->prepare("INSERT INTO sent_emails (recipient_email, subject, message) VALUES (?, ?, ?)");
            $stmt->execute( [$recipient, $subject, $message]);
            
            header('Location: admin_email.php');
        }
    } catch (Exception $e) {
        echo "Hiba az e-mail küldésénél: " . $mail->ErrorInfo;
    }
}

?>