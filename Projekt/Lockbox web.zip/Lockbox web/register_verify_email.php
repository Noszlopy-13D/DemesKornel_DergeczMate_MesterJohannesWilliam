<?php
session_start();
require 'db.php';

if (!isset($_SESSION['verification_code'])) {
    echo "Nincs aktív kód vagy email cím módosítás.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input_code = $_POST['verification_code'];

    $codeCreationTime = $_SESSION['code_time'];

    $expirationTime = 10 * 60;
    // Kód lejáratának ellenőrzése (10 perc)
    if (time() - $codeCreationTime > $expirationTime) {
        echo "<p style='color:red;'>A kód lejárt. Kérj egy újat!</p>";
        // Kód érvénytelenítése és session törlés
        unset($_SESSION['verification_code']);
        unset($_SESSION['code_time']);
    } else {
        // Kód érvényesítés
        if ($input_code == $_SESSION['verification_code']) {
            // E-mail módosítása az adatbázisban
            $username = $_SESSION['username'];
            $email = $_SESSION['email'];
            $hashed_password = $_SESSION['hashed_password']; 

            
            $stmt = $pdo->prepare("INSERT INTO user (username, email, password, profile_picture, created_at) VALUES (?, ?, ?, '', NOW())");
            $stmt->execute([$username, $email, $hashed_password]);

            unset($_SESSION['verification_code']);
            unset($_SESSION['username']);
            unset($_SESSION['email']);
            unset($_SESSION['hashed_password']);
            unset($_SESSION['code_time']);

            header('Location: login.php');
            exit;
        } else {
            echo "<p style='color:red'>Hibás kód. Kérlek próbáld újra.<p>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <script type="text/javascript" src="script/app.js" defer></script>
    <script type="text/javascript" src="script/script.js" defer></script>
    <title>LockBox</title>
    <style>
        body{
            width: 100%;
            height: 100%;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            text-align: center;
            justify-content: center;
            align-items: center;
        }
        .button{
            background-color: transparent;
            border: 1px solid white;
            color: white;
            transition: all .3s;
        }
        .button:hover{
            background-color: white;
            color: black;
        }
        #back-button{
            display: inline-flex; 
            align-items: center;
            color: white;
            font-weight: bold;
            text-decoration: none;
        }
        #back-button:hover{
            text-decoration: underline;
        }
        #countdown {
            font-size: 20px;
            font-weight: bold;
            color: red;
        }
    </style>
</head>
<body>
  <main>
    <p style="margin-bottom: 50px">A megerősítő kódot elküldtük az E-mail címére!</p>
    <div style="margin-bottom: 50px">
        <p>A kód érvényessége: <span id="countdown"></span></p>
    </div>
    <form method="POST">
        <label for="verification_code">Megerősítő kód:</label>
        <input type="text" name="verification_code" required>
        <input class="button" type="submit" value="Megerősítés">
    </form>

    <form method="POST" action="register_resend_code.php">
        <input class="button" type="submit" value="Új kód kérése">
    </form>
    <div>
        <p><a href="login.php" id="back-button"><svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#FFFFFF"><path d="M560-240 320-480l240-240 56 56-184 184 184 184-56 56Z"/></svg>Vissza a bejelentkezéshez</a></p>
    </div>
  </main>
  <script>
        // A kód létrehozásának időpontja a PHP session-ből
        var codeCreationTime = <?php echo $_SESSION['code_time']; ?>;
        var expirationTime = 10 * 60;

        // Számoljuk ki, mikor jár le a kód
        var expirationTimestamp = codeCreationTime + expirationTime;

        // Visszaszámláló funkció
        function updateCountdown() {
            var currentTime = Math.floor(Date.now() / 1000); 
            var remainingTime = expirationTimestamp - currentTime;

            if (remainingTime <= 0) {
                document.getElementById('countdown').innerHTML = "A kód lejárt!";
                clearInterval(countdownInterval);
            } else {
                var minutes = Math.floor(remainingTime / 60);
                var seconds = remainingTime % 60;
                document.getElementById('countdown').innerHTML = minutes + " perc " + seconds + " másodperc";
            }
        }

        // Indítjuk a visszaszámlálót
        var countdownInterval = setInterval(updateCountdown, 1000);

    </script>
</body>
</html>