<?php
session_start();
require 'db.php';

// Ellenőrizzük, hogy a felhasználó be van jelentkezve
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Frissítés feldolgozása
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $username = $_POST['username'];
    $email = $_POST['email'];

    // Profilkép feltöltés kezelése
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
        $image = file_get_contents($_FILES['profile_picture']['tmp_name']);  // Kép bináris adatainak beolvasása
        $stmt = $pdo->prepare("UPDATE user SET username = ?, email = ?, profile_picture = ? WHERE id = ?");
        $stmt->execute([$username, $email, $image, $user_id]);
    } else {
        // Csak a szöveges adatokat frissítjük, ha nem történt fájlfeltöltés
        $stmt = $pdo->prepare("UPDATE user SET username = ?, email = ? WHERE id = ?");
        $stmt->execute([$username, $email, $user_id]);
    }

    header('Location: dashboard.php');
    exit;
}

// Felhasználói adatok betöltése
$stmt = $pdo->prepare("SELECT * FROM user WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <title>Profil Beállítások</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="profile-container">
        <h1>Profil Beállítások</h1>
        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
            
            <label for="profile_picture">Profilkép feltöltése:</label>
            <input type="file" name="profile_picture" accept="image/*">

            <button type="submit">Frissítés</button>
        </form>
        <p><a href="dashboard.php">Vissza a főoldalra</a></p>
    </div>
</body>
</html>