<?php 
session_start();
require 'db.php';

// Az űrlap adatok ellenőrzése
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Ellenőrizzük, hogy az adatok nem üresek
    if (!empty($email) && !empty($subject) && !empty($message)) {
        // Az SQL lekérdezés előkészítése
        $stmt = $pdo->prepare("INSERT INTO contact (email, subject, message) VALUES (?, ?, ?)");
        $stmt->execute( [$email, $subject, $message]);
    }
}

?>
<!DOCTYPE html>
<html lang="hu">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>LockBox</title>
        <link href="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.css" rel="stylesheet" />
        <link rel="stylesheet" href="css/index_styles.css">
        <link rel="stylesheet" href="css/contact_styles.css">
        <link rel="stylesheet" href="css/navbar_styles.css">
        <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.2/dist/flowbite.min.js"></script>
    </head>
    <body>
    <nav class="navigation">
        <div class="menu-container">
            <div class="logo">LockBox</div>
            <button class="toggle-button" onclick="toggleMenu()">☰</button>
            <ul class="menu">
                <li><a href="index.php">Főoldal</a></li>
                <li><a href="download.php">Letöltés</a></li>
                <li><a href="contact.php">Kapcsolat</a></li>
                <li><a href="login.php">Bejelentkezés</a></li>
            </ul>
        </div>
        <ul class="menu mobile" id="mobileMenu">
            <li><a href="index.php">Főoldal</a></li>
            <li><a href="download.php">Letöltés</a></li>
            <li><a href="contact.php">Kapcsolat</a></li>
            <li><a href="login.php">Bejelentkezés</a></li>
        </ul>
    </nav>
    <script>
        function toggleMenu() {
            const mobileMenu = document.getElementById('mobileMenu');
            
            // Mobil nézetben engedélyezzük az animációkat
            if (window.innerWidth <= 700) {
                if (mobileMenu.classList.contains('show')) {
                    // Ha már meg van nyitva, akkor elrejthetjük
                    mobileMenu.classList.remove('show');
                    mobileMenu.classList.add('hide');
                    setTimeout(function() {
                        mobileMenu.style.display = 'none'; // Eltüntetjük végleg, miután az animáció befejeződött
                    }, 300); // Az animáció ideje
                } else {
                    // Ha nincs nyitva, akkor megjelenítjük
                    mobileMenu.style.display = 'flex'; // Először jelenjen meg
                    setTimeout(function() {
                        mobileMenu.classList.remove('hide');
                        mobileMenu.classList.add('show'); // Animáció indítása
                    }, 10); // Kis késleltetés, hogy az animáció észlelhető legyen
                }
            }
        }
        window.addEventListener('resize', function() {
            const mobileMenu = document.getElementById('mobileMenu');
            if (window.innerWidth > 700) {
                mobileMenu.style.display = 'none';
            }
        });
        document.addEventListener("DOMContentLoaded", function() {
            const mobileMenu = document.getElementById('mobileMenu');
            mobileMenu.style.display = 'none';
        });
    </script>
    <main>
        <div class="form-container">
            <h2>Írjon nekünk!</h2>
            <form method="POST">
                <label for="email">E-mail cím:</label>
                <input type="email" id="email" name="email" class="custom-input" placeholder="Írja be az e-mail címét" required>

                <label for="subject">Tárgy:</label>
                <input type="text" id="subject" name="subject" class="custom-input" placeholder="Írja be a tárgyat..." required>

                <label for="message">Üzenet:</label>
                <textarea id="message" name="message" placeholder="Írja ide az üzenetét..." required></textarea>

                <!-- Gombok -->
                <div class="button-container">
                    <button type="submit" class="send-button" style="float: left;">Elküld</button>
                </div>
            </form>
        </div>


        <!-- Lábléc -->
    <footer class="bg-black rounded-lg shadow" style="background: transparent">
    <div class="w-full max-w-screen-xl mx-auto p-4 md:py-8">
        <div class="sm:flex sm:items-center sm:justify-between">
            <a href="index.php" class="flex items-center mb-4 sm:mb-0 space-x-3 rtl:space-x-reverse">
                <span class="self-center text-2xl font-semibold whitespace-nowrap">LockBox</span>
            </a>
            <ul class="flex flex-wrap items-center mb-6 text-sm font-medium text-gray-500 sm:mb-0 dark:text-gray-400">
                <li>
                    <a href="about_us.php" class="hover:underline me-4 md:me-6">Rólunk</a>
                </li>
                <li>
                    <a href="contact.php" style="font-weight: bold;" class="hover:underline me-4 md:me-6">Kapcsolat</a>
                </li>
                <li>
                    <a href="privacy_policy.php" class="hover:underline me-4 md:me-6">Adatvédelmi szabályzat</a>
                </li>
                <li>
                <a href="aszf.php" class="hover:underline me-4 md:me-6">ÁSZF</a>
                </li>
            </ul>
        </div>
        <hr class="my-6 border-gray-200 sm:mx-auto dark:border-gray-700 lg:my-8" />
        <span class="block text-sm text-gray-500 sm:text-center dark:text-gray-400">© 2025 LockBox™ Minden jog fenntartva.</span>
    </div>
</footer>
</main>
    </body>
</html>