<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "admin") {
    header('Location: index.php');
    exit;
}

// Új hír hozzáadása
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_news"])) {
    $title = $_POST["title"];
    $content = $_POST["content"];
    $is_visible = isset($_POST["is_visible"]) ? 1 : 0;
    $content = trim(preg_replace('/\s+/', ' ', $content));  // Minden több szóközt egyetlen szóközre cserél
    $content = htmlspecialchars($content);


    if (!empty($title) && !empty($content)) {
        $stmt = $pdo->prepare("INSERT INTO news (title, content, is_visible) VALUES (?, ?, ?)");
        $stmt->execute([$title, $content, $is_visible]);

        header("Location: admin_news.php");
        exit;
    }
}

// Hírek lekérdezése
$stmt = $pdo->query("SELECT * FROM news ORDER BY created_at DESC");
$news = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LockBox Admin</title>
    <link rel="stylesheet" href="css/admin_styles.css">
    <link rel="stylesheet" href="css/sidebar_styles.css">
    <script type="text/javascript" src="script/app.js" defer></script>

    <style>
        main{
            margin: 0 auto;
            max-width: 1920px;
            width: 100%;
        }
        main form{
            display: flex;
            flex-direction: column;
        }
        .submit-button{
            margin: 0 auto;
            width: 50%;
            padding: 15px;
            margin-bottom: 30px;
            margin-top: 30px;
            border: 1px solid white;
            border-radius: 5px;
            background: transparent;
            color: white;
            cursor: pointer;
            transition: all .3s;
        }
        .submit-button:hover{
            background: white;
            color: black;
        }
        form input{
            height: 30px;
        }
        form textarea{
            height: 300px;
        }
        form input, form textarea{
            margin-bottom: 40px;
            border-radius: 5px;
            font-size: 16px;
        }
        .is_visible input{
            height: auto;
            margin-bottom: 10px;
        }
        .news-card 
        { 
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 10px; 
            border-radius: 8px; 
        }
        .button-container{
            display: flex;
            flex-direction: row;
            justify-content: space-between;
            width: 100%;
            margin-top: 10px;
        }
        .edit-modal-btn{
            width: 40%;
            padding: 5px;
            background-color: transparent;
            border: 1px solid orange;
            color: orange;
            transition: all .3s;
        }
        .edit-modal-btn:hover{
            background-color: orange;
            color: black;
        }
        .delete-modal-btn{
            width: 40%;
            padding: 5px;
            background-color: transparent;
            border: 1px solid red;
            color: red;     
            transition: all .3s;  
        }
        .delete-modal-btn:hover{
            background-color: red;
            color: black;
        }
    
        @media (max-width: 800px) {
            .submit-button{
                width: 100%;
                padding: 30px;
            }
        }


        /* Alap stílusok a modális ablakhoz */
        .modal {
            display: none; /* Kezdetben rejtve */
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            padding-top: 60px;
            color: black;


            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            width: 80%;
            max-width: 600px;
            border-radius: 5px;
        }

        .modal button {
            padding: 10px 20px;
            margin-bottom: 10px;
            cursor: pointer;
        }

        .modal input[type="text"], textarea {
            margin: 10px 0;
            width: 100%;
        }

        .btn {
            border: none;
            background-color: #f1f1f1;
            color: #333;
            padding: 10px 20px;
        }

        .btn-primary {
            background-color: #4CAF50;
            color: white;
        }

        .btn-danger {
            background-color: #f44336;
            color: white;
        }
    </style>
</head>
<body>
<nav id="sidebar">
    <ul>
      <li>
        <span class="logo">LockBox</span>
        <button onclick=toggleSidebar() id="toggle-btn">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="m313-480 155 156q11 11 11.5 27.5T468-268q-11 11-28 11t-28-11L228-452q-6-6-8.5-13t-2.5-15q0-8 2.5-15t8.5-13l184-184q11-11 27.5-11.5T468-692q11 11 11 28t-11 28L313-480Zm264 0 155 156q11 11 11.5 27.5T732-268q-11 11-28 11t-28-11L492-452q-6-6-8.5-13t-2.5-15q0-8 2.5-15t8.5-13l184-184q11-11 27.5-11.5T732-692q11 11 11 28t-11 28L577-480Z"/></svg>
        </button>
      </li>
      <li>
        <a href="admin_dashboard.php">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M520-640v-160q0-17 11.5-28.5T560-840h240q17 0 28.5 11.5T840-800v160q0 17-11.5 28.5T800-600H560q-17 0-28.5-11.5T520-640ZM120-480v-320q0-17 11.5-28.5T160-840h240q17 0 28.5 11.5T440-800v320q0 17-11.5 28.5T400-440H160q-17 0-28.5-11.5T120-480Zm400 320v-320q0-17 11.5-28.5T560-520h240q17 0 28.5 11.5T840-480v320q0 17-11.5 28.5T800-120H560q-17 0-28.5-11.5T520-160Zm-400 0v-160q0-17 11.5-28.5T160-360h240q17 0 28.5 11.5T440-320v160q0 17-11.5 28.5T400-120H160q-17 0-28.5-11.5T120-160Zm80-360h160v-240H200v240Zm400 320h160v-240H600v240Zm0-480h160v-80H600v80ZM200-200h160v-80H200v80Zm160-320Zm240-160Zm0 240ZM360-280Z"/></svg>
          <span>Főoldal</span>
        </a>
      </li>
      <li>
        <button button onclick=toggleSubMenu(this) class="dropdown-btn">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M240-160q-33 0-56.5-23.5T160-240q0-33 23.5-56.5T240-320q33 0 56.5 23.5T320-240q0 33-23.5 56.5T240-160Zm240 0q-33 0-56.5-23.5T400-240q0-33 23.5-56.5T480-320q33 0 56.5 23.5T560-240q0 33-23.5 56.5T480-160Zm240 0q-33 0-56.5-23.5T640-240q0-33 23.5-56.5T720-320q33 0 56.5 23.5T800-240q0 33-23.5 56.5T720-160ZM240-400q-33 0-56.5-23.5T160-480q0-33 23.5-56.5T240-560q33 0 56.5 23.5T320-480q0 33-23.5 56.5T240-400Zm240 0q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm240 0q-33 0-56.5-23.5T640-480q0-33 23.5-56.5T720-560q33 0 56.5 23.5T800-480q0 33-23.5 56.5T720-400ZM240-640q-33 0-56.5-23.5T160-720q0-33 23.5-56.5T240-800q33 0 56.5 23.5T320-720q0 33-23.5 56.5T240-640Zm240 0q-33 0-56.5-23.5T400-720q0-33 23.5-56.5T480-800q33 0 56.5 23.5T560-720q0 33-23.5 56.5T480-640Zm240 0q-33 0-56.5-23.5T640-720q0-33 23.5-56.5T720-800q33 0 56.5 23.5T800-720q0 33-23.5 56.5T720-640Z"/></svg>
          <span>Alkalmazások</span>
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M480-361q-8 0-15-2.5t-13-8.5L268-556q-11-11-11-28t11-28q11-11 28-11t28 11l156 156 156-156q11-11 28-11t28 11q11 11 11 28t-11 28L508-372q-6 6-13 8.5t-15 2.5Z"/></svg>
        </button>
        <ul class="sub-menu">
          <div>
            <li><a href="admin_application.php">Alkalmazások</a></li>
            <li><a href="admin_add_application.php">Hozzáadás</a></li>
          </div>
        </ul>
      </li>
      <li>
        <a href="admin_user.php">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M480-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM160-240v-32q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v32q0 33-23.5 56.5T720-160H240q-33 0-56.5-23.5T160-240Zm80 0h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm240-320q33 0 56.5-23.5T560-640q0-33-23.5-56.5T480-720q-33 0-56.5 23.5T400-640q0 33 23.5 56.5T480-560Zm0-80Zm0 400Z"/></svg>
        <span>Felhasználók</span>
        </a>
      </li>
      <li>
        <a href="admin_message.php">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#EA3323"><path d="M160-160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720v480q0 33-23.5 56.5T800-160H160Zm320-280L160-640v400h640v-400L480-440Zm0-80 320-200H160l320 200ZM160-640v-80 480-400Z"/></svg>
        <span>Üzenetek</span>
        </a>
      </li>
      <li>
        <a href="admin_email.php">
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#EA3323"><path d="m720-160-56-56 63-64H560v-80h167l-63-64 56-56 160 160-160 160ZM160-280q-33 0-56.5-23.5T80-360v-400q0-33 23.5-56.5T160-840h520q33 0 56.5 23.5T760-760v204q-10-2-20-3t-20-1q-10 0-20 .5t-20 2.5v-147L416-520 160-703v343h323q-2 10-2.5 20t-.5 20q0 10 1 20t3 20H160Zm58-480 198 142 204-142H218Zm-58 400v-400 400Z"/></svg>        
        <span>E-mail küldés</span>
        </a>
      </li>
      <li>
        <a href="admin_news.php">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#EA3323"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h440l200 200v440q0 33-23.5 56.5T760-120H200Zm0-80h560v-400H600v-160H200v560Zm80-80h400v-80H280v80Zm0-320h200v-80H280v80Zm0 160h400v-80H280v80Zm-80-320v160-160 560-560Z"/></svg>        
        <span><b>Hírek / Újdonságok</b></span>
        </a>
      </li>
      <li>
        <a href="logout.php">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg>
          <span>Kijelentkezés</span>
        </a>
      </li>
    </ul>
  </nav>
  <main>
    <h1>Hírek / Újdonságok</h1>
    <form method="POST">
        <label for="title">Cím:</label>
        <input type="text" name="title" id="title" required>

        <label for="content">Tartalom:</label>
        <textarea name="content" id="content" required></textarea>

        <label class="is_visible" for="is_visible">
            <input type="checkbox" name="is_visible" id="is_visible"> Látható a felhasználóknak
        </label>

        <button type="submit" name="add_news" class="submit-button">Hozzáadás</button>
    </form>

    <h1>Hírek kezelése</h1>
    <?php if (count($news) > 0){ ?>
    <?php foreach ($news as $n): ?>
        <div class="news-card">
            <strong><?= htmlspecialchars($n["title"]) ?></strong><br>
            <small><?= $n["created_at"] ?></small><br>
            <label>
                <input type="checkbox" class="visibility-toggle" data-id="<?= $n["id"] ?>" <?= $n["is_visible"] ? "checked" : "" ?>>
                Látható
            </label>
            <span id="status-<?= $n["id"] ?>" style="color: green;"></span>
            <div class="button-container">
                <button class="edit-modal-btn" 
                    onclick='openEditModal(
                        <?= $n["id"]; ?>, 
                        <?= json_encode($n["title"], JSON_HEX_APOS | JSON_HEX_QUOT); ?>, 
                        <?= json_encode($n["content"], JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE); ?>, 
                        <?= $n["is_visible"]; ?>
                    )'>
                    Szerkesztés
                </button>
                <button class="delete-modal-btn" onclick="openDeleteModal(<?= $n['id']; ?>)">Törlés</button>
            </div>
        </div>
    <?php endforeach; } else{?>
        <h2 style="color: #aaa; text-align: center;">Nincsenek megjeleníthető hírek</h2>
    <?php } ?>

    <script>
        document.querySelectorAll(".visibility-toggle").forEach(el => {
            el.addEventListener("change", function() {
                let newsId = this.getAttribute("data-id");
                let isVisible = this.checked ? 1 : 0;
                let statusSpan = document.getElementById("status-" + newsId);

                fetch("toggle_news_visibility.php", {
                    method: "POST",
                    headers: { "Content-Type": "application/x-www-form-urlencoded" },
                    body: "id=" + newsId + "&is_visible=" + isVisible
                })
                .then(response => response.text())
                .then(data => {
                    statusSpan.textContent = "✔ Mentve";
                    setTimeout(() => statusSpan.textContent = "", 2000); // 2mp után eltűnik a mentés üzenet
                })
                .catch(error => {
                    console.error("Hiba történt:", error);
                    statusSpan.style.color = "red";
                    statusSpan.textContent = "⚠ Hiba!";
                });
            });
        });


        // Nyitás és bezárás funkciók
        function openEditModal(id, title, content, visible) {
            document.getElementById('editId').value = id;
            document.getElementById('editTitle').value = title;
            document.getElementById('editContent').value = content.replace(/\\n/g, "\n");;
            document.getElementById('editVisible').checked = visible;
            document.getElementById('editModal').style.display = 'flex';


        }

        function openDeleteModal(id) {
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteModal').style.display = 'flex';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        // Ha a felhasználó kívül kattint, bezárjuk a modális ablakot
        window.onclick = function(event) {
            if (event.target.classList.contains('modal') && !event.target.classList.contains('modal-content')) {
                event.target.style.display = 'none';
            }
        };
    </script>

    <!-- Szerkesztés Modal -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <form action="update_news.php" method="POST" id="editForm">
            <input type="hidden" name="id" id="editId" />
            <div>
                <label for="title">Cím</label>
                <input type="text" name="title" id="editTitle" required />
            </div>
            <div>
                <label for="content">Tartalom</label>
                <textarea name="content" id="editContent" rows="5" required></textarea>
            </div>
            <div style="display: inline-block;">
                <input type="checkbox" name="visible" id="editVisible" style="height:auto"/>
                Látható
            </div>
            <button type="button" onclick="closeModal('editModal')">Mégsem</button>
            <button type="submit" class="btn btn-primary">Frissítés</button>
        </form>
    </div>
</div>

<!-- Törlés Modal -->
<div id="deleteModal" class="modal">
    <div class="modal-content">
        <form action="delete_news.php" method="GET" id="deleteForm">
            <input type="hidden" name="id" id="deleteId" />
            <p style="text-align: center; color: black;">Biztosan törölni szeretnéd ezt a hírt?</p>
            <button type="button" onclick="closeModal('deleteModal')">Mégsem</button>
            <button type="submit" class="btn btn-danger">Törlés</button>
        </form>
    </div>
</div>


  </main>
</body>
</html>