<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "admin") {
    header('Location: login.php');
    exit;
}
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: https://www.lockbox.hu"); 
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type");

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo json_encode(["status" => "OK"]);
?>