<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "admin") {
    header('Location: login.php');
    exit;
}


if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_news"])) {
    
}

// Hírek lekérdezése
$stmt = $pdo->query("SELECT * FROM sent_emails ORDER BY sent_at DESC");
$emails = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LockBox Admin</title>
    <link rel="stylesheet" href="css/admin_styles.css">
    <link rel="stylesheet" href="css/sidebar_styles.css">
    <script type="text/javascript" src="script/app.js" defer></script>

    <style>
        main{
            margin: 0 auto;
            max-width: 1920px;
            width: 100%;
        }
        main form{
            display: flex;
            flex-direction: column;
        }
        .submit-button{
            margin: 0 auto;
            width: 50%;
            padding: 15px;
            margin-bottom: 30px;
            margin-top: 30px;
            border: 1px solid white;
            border-radius: 5px;
            background: transparent;
            color: white;
            cursor: pointer;
            transition: all .3s;
        }
        .submit-button:hover{
            background: white;
            color: black;
        }
        form input{
            height: 30px;
        }
        form textarea{
            height: 300px;
        }
        form input, form textarea{
            margin-bottom: 40px;
            border-radius: 5px;
            font-size: 16px;
        }

        .email-card {
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 15px;
            transition: transform 0.2s ease-in-out;
        }
        .email-card:hover {
            transform: translateY(-5px);
        }
        .email-subject {
            font-size: 1.2rem;
            font-weight: bold;
            color: black;
        }
        .email-recipient {
            font-size: 0.9rem;
            color: black;
        }
        .email-time {
            font-size: 0.85rem;
            color: black;
            display: flex;
            align-items: center;
        }
        .email-time i {
            margin-right: 5px;
        }
        
    
        @media (max-width: 800px) {
            .submit-button{
                width: 100%;
                padding: 30px;
            }
        }

    </style>
</head>
<body>
<nav id="sidebar">
    <ul>
      <li>
        <span class="logo">LockBox</span>
        <button onclick=toggleSidebar() id="toggle-btn">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="m313-480 155 156q11 11 11.5 27.5T468-268q-11 11-28 11t-28-11L228-452q-6-6-8.5-13t-2.5-15q0-8 2.5-15t8.5-13l184-184q11-11 27.5-11.5T468-692q11 11 11 28t-11 28L313-480Zm264 0 155 156q11 11 11.5 27.5T732-268q-11 11-28 11t-28-11L492-452q-6-6-8.5-13t-2.5-15q0-8 2.5-15t8.5-13l184-184q11-11 27.5-11.5T732-692q11 11 11 28t-11 28L577-480Z"/></svg>
        </button>
      </li>
      <li>
        <a href="admin_dashboard.php">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M520-640v-160q0-17 11.5-28.5T560-840h240q17 0 28.5 11.5T840-800v160q0 17-11.5 28.5T800-600H560q-17 0-28.5-11.5T520-640ZM120-480v-320q0-17 11.5-28.5T160-840h240q17 0 28.5 11.5T440-800v320q0 17-11.5 28.5T400-440H160q-17 0-28.5-11.5T120-480Zm400 320v-320q0-17 11.5-28.5T560-520h240q17 0 28.5 11.5T840-480v320q0 17-11.5 28.5T800-120H560q-17 0-28.5-11.5T520-160Zm-400 0v-160q0-17 11.5-28.5T160-360h240q17 0 28.5 11.5T440-320v160q0 17-11.5 28.5T400-120H160q-17 0-28.5-11.5T120-160Zm80-360h160v-240H200v240Zm400 320h160v-240H600v240Zm0-480h160v-80H600v80ZM200-200h160v-80H200v80Zm160-320Zm240-160Zm0 240ZM360-280Z"/></svg>
          <span>Főoldal</span>
        </a>
      </li>
      <li>
        <button button onclick=toggleSubMenu(this) class="dropdown-btn">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M240-160q-33 0-56.5-23.5T160-240q0-33 23.5-56.5T240-320q33 0 56.5 23.5T320-240q0 33-23.5 56.5T240-160Zm240 0q-33 0-56.5-23.5T400-240q0-33 23.5-56.5T480-320q33 0 56.5 23.5T560-240q0 33-23.5 56.5T480-160Zm240 0q-33 0-56.5-23.5T640-240q0-33 23.5-56.5T720-320q33 0 56.5 23.5T800-240q0 33-23.5 56.5T720-160ZM240-400q-33 0-56.5-23.5T160-480q0-33 23.5-56.5T240-560q33 0 56.5 23.5T320-480q0 33-23.5 56.5T240-400Zm240 0q-33 0-56.5-23.5T400-480q0-33 23.5-56.5T480-560q33 0 56.5 23.5T560-480q0 33-23.5 56.5T480-400Zm240 0q-33 0-56.5-23.5T640-480q0-33 23.5-56.5T720-560q33 0 56.5 23.5T800-480q0 33-23.5 56.5T720-400ZM240-640q-33 0-56.5-23.5T160-720q0-33 23.5-56.5T240-800q33 0 56.5 23.5T320-720q0 33-23.5 56.5T240-640Zm240 0q-33 0-56.5-23.5T400-720q0-33 23.5-56.5T480-800q33 0 56.5 23.5T560-720q0 33-23.5 56.5T480-640Zm240 0q-33 0-56.5-23.5T640-720q0-33 23.5-56.5T720-800q33 0 56.5 23.5T800-720q0 33-23.5 56.5T720-640Z"/></svg>
          <span>Alkalmazások</span>
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M480-361q-8 0-15-2.5t-13-8.5L268-556q-11-11-11-28t11-28q11-11 28-11t28 11l156 156 156-156q11-11 28-11t28 11q11 11 11 28t-11 28L508-372q-6 6-13 8.5t-15 2.5Z"/></svg>
        </button>
        <ul class="sub-menu">
          <div>
            <li><a href="admin_application.php">Alkalmazások</a></li>
            <li><a href="admin_add_application.php">Hozzáadás</a></li>
          </div>
        </ul>
      </li>
      <li>
        <a href="admin_user.php">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M480-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM160-240v-32q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v32q0 33-23.5 56.5T720-160H240q-33 0-56.5-23.5T160-240Zm80 0h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm240-320q33 0 56.5-23.5T560-640q0-33-23.5-56.5T480-720q-33 0-56.5 23.5T400-640q0 33 23.5 56.5T480-560Zm0-80Zm0 400Z"/></svg>
        <span>Felhasználók</span>
        </a>
      </li>
      <li>
        <a href="admin_message.php">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#EA3323"><path d="M160-160q-33 0-56.5-23.5T80-240v-480q0-33 23.5-56.5T160-800h640q33 0 56.5 23.5T880-720v480q0 33-23.5 56.5T800-160H160Zm320-280L160-640v400h640v-400L480-440Zm0-80 320-200H160l320 200ZM160-640v-80 480-400Z"/></svg>
        <span>Üzenetek</span>
        </a>
      </li>
      <li>
        <a href="admin_email.php">
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#EA3323"><path d="m720-160-56-56 63-64H560v-80h167l-63-64 56-56 160 160-160 160ZM160-280q-33 0-56.5-23.5T80-360v-400q0-33 23.5-56.5T160-840h520q33 0 56.5 23.5T760-760v204q-10-2-20-3t-20-1q-10 0-20 .5t-20 2.5v-147L416-520 160-703v343h323q-2 10-2.5 20t-.5 20q0 10 1 20t3 20H160Zm58-480 198 142 204-142H218Zm-58 400v-400 400Z"/></svg>        
        <span><b>E-mail küldés</b></span>
        </a>
      </li>
      <li>
        <a href="admin_news.php">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#EA3323"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h440l200 200v440q0 33-23.5 56.5T760-120H200Zm0-80h560v-400H600v-160H200v560Zm80-80h400v-80H280v80Zm0-320h200v-80H280v80Zm0 160h400v-80H280v80Zm-80-320v160-160 560-560Z"/></svg>        
        <span>Hírek / Újdonságok</span>
        </a>
      </li>
      <li>
        <a href="logout.php">
            <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg>
          <span>Kijelentkezés</span>
        </a>
      </li>
    </ul>
  </nav>
  <main>
    <h1>E-mail küldés</h1>
    <form action="send_email.php" method="POST">
        <label for="email">Címzett e-mail:</label>
        <input type="email" name="email" id="email" required>

        <label for="subject">Tárgy:</label>
        <input type="text" name="subject" id="subject" required>

        <label for="message">Üzenet:</label>
        <textarea name="message" id="message" required></textarea>

        <button type="submit" name="add_news" class="submit-button">Küldés</button>
    </form>

    <h1>Elküldött E-mailek</h1>
    <?php if (count($emails) > 0){ ?>
    <?php foreach ($emails as $e): ?>
        <div class="email-card">
            <div class="email-subject"><?php echo htmlspecialchars($e['subject']); ?></div>
            <div class="email-recipient">Címzett: <strong><?php echo htmlspecialchars($e['recipient_email']); ?></strong></div>
            <div class="email-time">
                Elküldve: <?php echo $e['sent_at']; ?>
            </div>
        </div>
    <?php endforeach; } else{?>
        <h2 style="color: #aaa; text-align: center;">Nincsenek megjeleníthető elküldött e-mailek</h2>
    <?php } ?>
  </main>
</body>
</html>