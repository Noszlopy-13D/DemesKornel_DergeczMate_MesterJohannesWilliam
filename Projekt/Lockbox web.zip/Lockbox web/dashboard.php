<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require __DIR__ . '/composer/vendor/autoload.php';

use Dotenv\Dotenv;

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

$encryption_key = $_ENV['ENCRYPTION_KEY'];

$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM saved_passwords WHERE user_id = ?");
$stmt->execute([$user_id]);
$passwords = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT * FROM user WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$stmt = $pdo->prepare("SELECT * FROM news WHERE is_visible = 1 ORDER BY created_at DESC");
$stmt->execute();
$news = $stmt->fetchAll();

function getUserIpAndDeviceInfo() {
  $ip_address = $_SERVER['REMOTE_ADDR'];
  $user_agent = $_SERVER['HTTP_USER_AGENT'];

  // Eszköz információk egyszerűsített kinyerése
  if (strpos($user_agent, 'Mobile') !== false) {
      $device_type = 'Mobil eszköz';
  } else {
      $device_type = 'Asztali gép';
  }

  return array('ip' => $ip_address, 'device' => $device_type);
}

$user_ip_device = getUserIpAndDeviceInfo();

// 2FA státusz lekérdezése
function get2FAStatus($user_id, $pdo) {
  $stmt = $pdo->prepare("SELECT two_factor_enabled FROM user WHERE id = ?");
  $stmt->execute([$user_id]);
  $user = $stmt->fetch(PDO::FETCH_ASSOC);
  return $user['two_factor_enabled'] ? 'Bekapcsolva' : 'Kikapcsolva';
}

$two_factor_status = get2FAStatus($user_id, $pdo);


// Jelszó kiszivárgás ellenőrzés
function checkPasswordLeak($password)
{
    // SHA-1 hash generálása (ha a jelszavakat hash-ként tároljuk)
    $password_hash = strtoupper(sha1($password));
    $prefix = substr($password_hash, 0, 5);
    $suffix = substr($password_hash, 5);

    // API URL a hash első 5 karaktere alapján
    $url = "https://api.pwnedpasswords.com/range/$prefix";
    
    // API lekérdezés
    // cURL beállítások
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);  // SSL ellenőrzés letiltása (ha szükséges)
    $response = curl_exec($ch);
    curl_close($ch);
    
    if ($response === FALSE) {
        return false; 
    }

    // Ellenőrzés, hogy a hash található-e a válaszban
    $lines = explode("\n", $response);
    foreach ($lines as $line) {
        list($hash, $count) = explode(":", $line);
        if (strtoupper($hash) == $suffix) {
            return $count; // Ha találunk egyezést, visszaadjuk a találatok számát
        }
    }
    return false; // Ha nincs találat
}

// Felhasználói jelszavak lekérdezése és ellenőrzése
function getUserPasswordLeaks($user_id, $pdo, $encryption_key)
{
    $stmt = $pdo->prepare("SELECT app_name, username, password, iv_hex FROM saved_passwords WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $passwords = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($passwords)) {
        return "<p>Még nincsenek mentett jelszavak.</p>";
    }

    foreach ($passwords as $password) {
      $iv = hex2bin($password['iv_hex']);
      $decryptedPassword = openssl_decrypt($password['password'], 'AES-128-CTR', $encryption_key, 0, $iv);

      $password_status = checkPasswordLeak($decryptedPassword);

      if ($password_status) {
          $results[] = "<p style='color: red;'>⚠️ A(z) <b>{$password['app_name']}</b> ({$password['username']}) jelszava kiszivárgott, és <b>$password_status</b> alkalommal került kompromittálásra.</p>";
      }
    }

    if (empty($results)) {
        return "<p style='color: green;'>Minden jelszó biztonságban van, nincs kiszivárgott jelszó.</p>";
    } 

  return implode("<br>", $results);
}

$password_status = getUserPasswordLeaks($user_id, $pdo, $encryption_key);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <link rel="stylesheet" href="css/sidebar_styles.css">
    <script type="text/javascript" src="script/app.js" defer></script>
    <title>LockBox</title>
    <style>
      main{
          max-width: 1920px;
          margin: 0 auto;
      }
      .stats-grid {
          display: flex;
          flex-wrap: wrap;  
          gap: 20px;  
          justify-content: space-between;  
          margin-top: 20px;
      }

      .stat-box {
          flex: 1 1 calc(50% - 10px);
          color: white;
          padding: 20px;
          border-radius: 10px;
          width: 250px;
          min-width: 250px;
          text-align: center;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          border: 1px solid white;
          box-sizing: border-box;
      }

      .stat-box:nth-child(6),.stat-box:nth-child(7), .stat-box:nth-child(8) {
          flex: 1 1 100%;
      }

      .stat-box h3 {
          font-size: 18px;
          margin-bottom: 10px;
      }
      .stat-box p {
          font-size: 24px;
          font-weight: bold;
      }
      table{
          width: 100%;
      }
      .pwd-security-alert{
          line-height: 35px;
      }
      .switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: red;
            transition: .4s;
            border-radius: 50px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            border-radius: 50px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
        }

        input:checked + .slider {
            background-color: #4CAF50;
        }

        input:checked + .slider:before {
            transform: translateX(26px);
        }
        .privacy-tips-section h2 {
            color: #007BFF;
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        .tip-card {
            display: flex;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .tip-card:hover {
            transform: translateY(-5px);
        }

        .tip-icon {
            font-size: 2rem;
            color: #007BFF;
            margin-right: 15px;
            display: flex;
            align-items: center;
        }

        .tip-content {
            flex-grow: 1;
        }

        .tip-content strong {
            font-size: 1.4rem;
            color: white;
        }

        .tip-content p {
            font-size: 18px;
            margin-top: 5px;
        }

        .fas {
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
        }



        .news-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }

        .news-card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            width: 100%;
            padding: 15px;
            box-sizing: border-box;
            transition: transform 0.3s ease;
        }

        .news-card:hover {
            transform: scale(1.01);
        }

        .news-title {
            font-size: 1.5em;
            color: #333;
            margin: 0;
        }

        .news-date {
            font-size: 0.9em;
            color: #777;
        }

        .read-more {
            display: inline-block;
            margin-top: 10px;
            color: #007BFF;
            text-decoration: none;
        }
    </style>
</head>
<body>
<nav id="sidebar">
    <ul>
      <li>
        <span class="logo">LockBox</span>
        <button onclick=toggleSidebar() id="toggle-btn">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="m313-480 155 156q11 11 11.5 27.5T468-268q-11 11-28 11t-28-11L228-452q-6-6-8.5-13t-2.5-15q0-8 2.5-15t8.5-13l184-184q11-11 27.5-11.5T468-692q11 11 11 28t-11 28L313-480Zm264 0 155 156q11 11 11.5 27.5T732-268q-11 11-28 11t-28-11L492-452q-6-6-8.5-13t-2.5-15q0-8 2.5-15t8.5-13l184-184q11-11 27.5-11.5T732-692q11 11 11 28t-11 28L577-480Z"/></svg>
        </button>
      </li>
      <li id="active">
        <a href="dashboard.php">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M520-640v-160q0-17 11.5-28.5T560-840h240q17 0 28.5 11.5T840-800v160q0 17-11.5 28.5T800-600H560q-17 0-28.5-11.5T520-640ZM120-480v-320q0-17 11.5-28.5T160-840h240q17 0 28.5 11.5T440-800v320q0 17-11.5 28.5T400-440H160q-17 0-28.5-11.5T120-480Zm400 320v-320q0-17 11.5-28.5T560-520h240q17 0 28.5 11.5T840-480v320q0 17-11.5 28.5T800-120H560q-17 0-28.5-11.5T520-160Zm-400 0v-160q0-17 11.5-28.5T160-360h240q17 0 28.5 11.5T440-320v160q0 17-11.5 28.5T400-120H160q-17 0-28.5-11.5T120-160Zm80-360h160v-240H200v240Zm400 320h160v-240H600v240Zm0-480h160v-80H600v80ZM200-200h160v-80H200v80Zm160-320Zm240-160Zm0 240ZM360-280Z"/></svg>
          <span><b>Főoldal</b></span>
        </a>
      </li>
      <li>
        <a href="passwords.php">
        <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M420-680q0-33 23.5-56.5T500-760q33 0 56.5 23.5T580-680q0 33-23.5 56.5T500-600q-33 0-56.5-23.5T420-680ZM500 0 320-180l60-80-60-80 60-85v-47q-54-32-87-86.5T260-680q0-100 70-170t170-70q100 0 170 70t70 170q0 67-33 121.5T620-472v352L500 0ZM340-680q0 56 34 98.5t86 56.5v125l-41 58 61 82-55 71 75 75 40-40v-371q52-14 86-56.5t34-98.5q0-66-47-113t-113-47q-66 0-113 47t-47 113Z"/></svg>
          <span>Jelszavak</span>
        </a>
      </li>
      <li>
        <a href="profile.php">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M480-480q-66 0-113-47t-47-113q0-66 47-113t113-47q66 0 113 47t47 113q0 66-47 113t-113 47ZM160-240v-32q0-34 17.5-62.5T224-378q62-31 126-46.5T480-440q66 0 130 15.5T736-378q29 15 46.5 43.5T800-272v32q0 33-23.5 56.5T720-160H240q-33 0-56.5-23.5T160-240Zm80 0h480v-32q0-11-5.5-20T700-306q-54-27-109-40.5T480-360q-56 0-111 13.5T260-306q-9 5-14.5 14t-5.5 20v32Zm240-320q33 0 56.5-23.5T560-640q0-33-23.5-56.5T480-720q-33 0-56.5 23.5T400-640q0 33 23.5 56.5T480-560Zm0-80Zm0 400Z"/></svg>
          <span>Profil</span>
        </a>
      </li>
      <li>
        <a href="user_contact.php">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M798-120q-125 0-247-54.5T329-329Q229-429 174.5-551T120-798q0-18 12-30t30-12h162q14 0 25 9.5t13 22.5l26 140q2 16-1 27t-11 19l-97 98q20 37 47.5 71.5T387-386q31 31 65 57.5t72 48.5l94-94q9-9 23.5-13.5T670-390l138 28q14 4 23 14.5t9 23.5v162q0 18-12 30t-30 12ZM241-600l66-66-17-94h-89q5 41 14 81t26 79Zm358 358q39 17 79.5 27t81.5 13v-88l-94-19-67 67ZM241-600Zm358 358Z"/></svg>
          <span>Kapcsolat</span>
        </a>
      </li>
      <li>
        <a href="logout.php">
          <svg xmlns="http://www.w3.org/2000/svg" height="24px" viewBox="0 -960 960 960" width="24px" fill="#e8eaed"><path d="M200-120q-33 0-56.5-23.5T120-200v-560q0-33 23.5-56.5T200-840h280v80H200v560h280v80H200Zm440-160-55-58 102-102H360v-80h327L585-622l55-58 200 200-200 200Z"/></svg>
          <span>Kijelentkezés</span>
        </a>
      </li>
    </ul>
</nav>
<main>
    <div class="header">
      <h1>Felhasználói kezelőfelület</h1>
    </div>
    <div style="text-align:center; margin-bottom: 30px">
      <h2>Üdvözlünk <?php echo htmlspecialchars($user['username']); ?></h2>
    </div>
    <div class="stats-grid">
        <div class="stat-box">
            <h3>Mentett jelszavaid száma</h3>
            <p style="font-size: 42px; margin-top: 20px;"><?php echo htmlspecialchars(count($passwords)); ?></p>
        </div>

        <div class="stat-box">
            <h3>Kétfaktoros hitelesítés állapot</h3>
            <p id="statusMessage"><?php echo $two_factor_status ?></p>
            <label class="switch">
                <input type="checkbox" id="twoFactorToggle" <?php echo $two_factor_status == 'Bekapcsolva' ? 'checked' : ''; ?> onchange="toggle2FA()">
                <span class="slider"></span>
            </label>
        </div>

        <div class="stat-box">
            <h3>IP Cím</h3>
            <p><?php echo htmlspecialchars($user_ip_device['ip']); ?></p>
        </div>

        <div class="stat-box">
            <h3>Eszköz</h3>
            <p><?php echo htmlspecialchars($user_ip_device['device']); ?></p>
        </div>

        <div class="stat-box pwd-security-alert">
            <h3>Jelszó biztonság</h3>
            <?php echo $password_status; ?>
        </div>

        <div class="stat-box">
            <h3>Újdonságok / Hírek</h3>
            
            <div class="news-container">
            <?php if (count($news) > 0) {?>
            <?php foreach ($news as $news_item): ?>
                <div class="news-card">
                    <h2 class="news-title"><?php echo htmlspecialchars($news_item['title']); ?></h2>
                    <p class="news-date"><?php echo date('Y-m-d', strtotime($news_item['created_at'])); ?></p>
                    <a href="view_news.php?id=<?php echo $news_item['id']; ?>" class="read-more">Tovább olvasom</a>
                </div>
            <?php endforeach; } else{?>
                <h2 style="color: var(--secondary-text-clr); text-align: center; margin: auto;">Nincsenek aktuális hírek</h2>
            <?php } ?>
        </div>
        </div>

        <div class="stat-box privacy-tips-section">
            <h3>Adatvédelmi tippek</h3>
            <div class="tip-card">
              <div class="tip-content">
                  <strong>Ne használd ugyanazt a jelszót több helyen!</strong>
                  <p>Mindig válassz egyedi jelszót minden fiókhoz. Ha egy jelszó kiszivárog, a többi fiókod is veszélybe kerülhet.</p>
              </div>
          </div>
          <div class="tip-card">
              <div class="tip-content">
                  <strong>Használj erős, egyedi jelszavakat!</strong>
                  <p>Soha ne használj könnyen kitalálható jelszavakat, mint a „123456” vagy „password”. Az erős jelszavak tartalmaznak nagy- és kisbetűket, számokat és speciális karaktereket.</p>
              </div>
          </div>
          <div class="tip-card">
              <div class="tip-content">
                  <strong>Kapcsold be a kétfaktoros hitelesítést</strong>
                  <p>A kétfaktoros hitelesítés egy egyszerű, de hatékony módja annak, hogy megvédd fiókodat. Aktiváld most, hogy növeld a biztonságot!</p>
              </div>
          </div>
          <div class="tip-card">
              <div class="tip-content">
                  <strong>Frissítsd a jelszavaid rendszeresen!</strong>
                  <p>Rendszeres jelszófrissítés ajánlott. Legalább félévente változtasd meg a jelszavad, hogy elkerüld a lehetséges támadásokat.</p>
              </div>
          </div>
          <div class="tip-card">
              <div class="tip-content">
                  <strong>Ne oszd meg a jelszavaidat másokkal!</strong>
                  <p>Ne oszd meg a jelszavaidat másokkal, még akkor sem, ha úgy tűnik, hogy megbízhatóak. Használj jelszókezelőt a biztonság érdekében.</p>
              </div>
          </div>
          <div class="tip-card">
              <div class="tip-content">
                  <strong>Ne kattints gyanús e-mailekre vagy linkekre!</strong>
                  <p>A phishing támadások gyakoriak, amikor a támadók hamis e-maileket küldenek, hogy megszerezzék a felhasználói adatokat. Soha ne kattints olyan e-mail linkekre, amiket nem kértél vagy nem vársz.</p>
              </div>
          </div>
        </div>



    </div>
  </main>

  <script>
        window.onload = function() {
    fetch('get_2fa_status.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                console.error('Hiba:', data.error);
                alert('Hiba történt a 2FA állapot lekérésekor.');
                return;
            }
            const isChecked = data.enabled;
            document.getElementById('twoFactorToggle').checked = isChecked;
            updateStatusMessage(isChecked); 
        })
        .catch(error => {
            console.error('Hiba:', error);
            alert('Hiba történt a 2FA állapot lekérésekor.');
        });
};

    function updateStatusMessage(isEnabled) {
        const statusMessage = document.getElementById('statusMessage');
        statusMessage.textContent = isEnabled ? 'Bekapcsolva' : 'Kikapcsolva';
    }


        function toggle2FA() {
        const isChecked = document.getElementById('twoFactorToggle').checked;

        fetch('toggle_2fa.php', {
            method: 'POST',
            body: JSON.stringify({ enable: isChecked }),
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .catch(error => {
            console.error('Hiba:', error);
            alert('Hiba történt.');
        });
    }

    document.getElementById('twoFactorToggle').addEventListener('change', function() {
    const isChecked = this.checked;

    updateStatusMessage(isChecked);

    fetch('toggle_2fa.php', {
        method: 'POST',
        body: JSON.stringify({ enable: isChecked }),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .catch(error => {
        console.error('Hiba:', error);
        alert('Hiba történt.');
    });
});

  </script>
</body>
</html>