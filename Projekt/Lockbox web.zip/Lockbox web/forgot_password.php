<?php
session_start();
require 'db.php';


?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/styles.css">
    <script type="text/javascript" src="script/script.js" defer></script>
    <title>LockBox</title>
    <style>
        body{
            width: 100%;
            height: 100%;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            text-align: center;
            justify-content: center;
            align-items: center;
        }
        .button{
            width: 200px;
            margin-top: 10px;
            background-color: transparent;
            border: 1px solid white;
            border-radius: 5px;
            color: white;
            transition: all .3s;
            padding: 20px 0;
            margin-bottom: 20px;
        }
        .button:hover{
            background-color: white;
            color: black;
        }
        .msg{
            color: green;
        }
        .error{
            color: red;
        }
    </style>
</head>
<body>
    <main>
        <p style="margin-bottom: 20px">Kérjük, a fiókod megkereséséhez add meg az e-mail címedet.</p>
        <form action="process_forgot_password.php" method="POST">
            <label for="email">E-mail cím:</label>
            <input type="email" name="email" id="email" required>
            <button class="button" type="submit">Helyreállítási link küldése</button>
        </form>
        <?php
        if (isset($_GET['msg'])) {
            $message = htmlspecialchars($_GET['msg']);
            echo "<p class='msg'>$message</p>";
        } 
        else if (isset($_GET['error'])){
            $error = htmlspecialchars($_GET['error']);
            echo "<p class='error'>$error</p>";
        }
        ?>
    </main>
</body>
</html>